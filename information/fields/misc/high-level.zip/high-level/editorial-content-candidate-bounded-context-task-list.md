# Editorial Content Candidate Bounded Context Task List

## Purpose

This task list supports the decision on authored editorial content in EPR. It is based on the [current-state editorial analysis](analysis/editorial-content-candidate-bounded-context-analysis.md).

Secure Access announcements, provider-event triggers, outbound delivery, retries and publication/removal history are out of scope and must be handled as a separate operational communication concern.

## Definition Of Done

- Every editorial capability has an evidenced source of truth and target disposition.
- Actors, ownership, lifecycle, audience, audit and retention requirements are confirmed.
- Runtime-managed content is separated from content that can be source-controlled, externally published, archived or retired.
- Build, buy and delegate options are assessed.
- The DDD evidence, classification and context map consistently represent the editorial decision.
- An architecture decision approves, rejects or reshapes the candidate.

## Working Rules

- [ ] Exclude Secure Access announcements and operational message processing.
- [ ] Do not infer business use solely from table existence or code presence.
- [ ] Do not infer safe retirement from a short no-activity window.
- [ ] Analyse each use of `group` or `audience` according to its actual semantics.
- [ ] Record evidence and the person or role validating each decision.
- [ ] Treat publishing products as options until their suitability is confirmed.

## Phase 1: Establish The Editorial Baseline

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-01 | Maintain the scope boundary in the recommendation and analysis. | Editorial documents contain no Secure Access announcement or operational delivery design. | [ ] |
| EC-02 | Complete the inventory for news, banners, FAQs, documents, content pages and glossary. | Each capability has tables, code paths, routes, actors, lifecycle and consumers. | [ ] |
| EC-03 | Record evidence provenance and confidence. | Claims link to code, ERD, activity evidence or stakeholder confirmation. | [ ] |
| EC-04 | Extend activity evidence where retirement depends on it. | Review window and limitations are documented and combined with route/owner evidence. | [ ] |

## Phase 2: Confirm Current Use And Authority

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-05 | Observe current admin and reader journeys. | Screens, permissions, inputs, outputs and failure paths are recorded. | [ ] |
| EC-06 | Identify the source of truth for news, FAQs and glossary. | Content parity, write paths and owner confirmation resolve authority. | [ ] |
| EC-07 | Confirm whether legacy news remains visible or editable. | Evidence supports migrate, archive or retire. | [ ] |
| EC-08 | Confirm whether documents and content pages remain required. | Usage, retention, accessibility and archival decisions are recorded. | [ ] |
| EC-09 | Confirm frontend banner behaviour. | Authoring, approval, targeting, scheduling, expiry and removal rules are documented. | [ ] |

## Phase 3: Discover Editorial Users And Lifecycles

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-10 | Identify product, editorial, accessibility, security and data owners. | Named roles and decision responsibilities are agreed. | [ ] |
| EC-11 | Catalogue authors, reviewers, publishers and readers. | Actor-to-capability matrix includes permissions and audit needs. | [ ] |
| EC-12 | Model each editorial lifecycle. | Draft, review, publish, schedule, expire, archive and delete rules are recorded where applicable. | [ ] |
| EC-13 | Define editorial language. | Terms distinguish article, FAQ, banner, document, page, section, glossary entry, grouping and audience. | [ ] |

## Phase 4: Decide What EPR Must Own

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-14 | Identify invariants and transaction boundaries. | Facts that must change atomically are documented per capability. | [ ] |
| EC-15 | Decide which content needs runtime management. | Each family is marked runtime-managed, source-controlled, externally published, archived or retired. | [ ] |
| EC-16 | Test whether retained capabilities share ownership and lifecycle rules. | Evidence supports one Editorial Content context, multiple concerns or no custom context. | [ ] |
| EC-17 | Agree candidate purpose, name, owned data and non-ownership. | Candidate definition excludes announcements and provider facts. | [ ] |

## Phase 5: Assess Build, Buy And Delegate

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-18 | Define evaluation criteria. | Criteria include GOV.UK suitability, authenticated content, scheduling, approval, audit, accessibility, retention, APIs, cost and support. | [ ] |
| EC-19 | Assess source-controlled/static and approved publishing options. | Evidence identifies supported and unsupported content classes. | [ ] |
| EC-20 | Assess file/document storage options where documents remain required. | Security, access, retention, scanning and link stability are covered. | [ ] |
| EC-21 | Spike the preferred option with representative editorial journeys. | Demonstration covers authoring, review, publication, expiry and audit as required. | [ ] |
| EC-22 | Record total ownership and operating costs. | Comparison includes build, migration, editorial operations, support and product costs. | [ ] |

## Phase 6: Define Editorial Contracts And Quality Requirements

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-23 | Define authorisation and presentation-audience contracts. | Design references Access Control without copying permission authority. | [ ] |
| EC-24 | Define audit and retention requirements. | Author/reviewer history, deletion, archival and legal retention are agreed. | [ ] |
| EC-25 | Define accessibility and content-quality controls. | Responsibilities and checks cover WCAG, links, documents and publication review. | [ ] |
| EC-26 | Define content and file security. | HTML sanitisation, uploads, malware scanning and sensitive-content handling are covered. | [ ] |
| EC-27 | Define availability and caching needs. | Published editorial content remains appropriately available and refresh behaviour is known. | [ ] |

## Phase 7: Plan Migration And Retirement

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-28 | Assign a disposition to every editorial store. | Each is migrate, transform, archive, retain temporarily or retire, with owner approval. | [ ] |
| EC-29 | Reconcile duplicate-looking stores. | Plan covers content, links/files, publication state, grouping, audiences and audit history. | [ ] |
| EC-30 | Plan redirects and archival access. | Public links, accessibility, retention and discoverability remain valid. | [ ] |
| EC-31 | Define decommissioning evidence. | Exit criteria include no required consumers, retained records, owner sign-off and monitoring. | [ ] |

## Phase 8: Update The Architecture Baseline

| ID | Task | Output / acceptance evidence | Status |
|---|---|---|---|
| EC-32 | Add editorial evidence to Stage 1. | Capabilities, actors, data, dependencies and confidence are recorded. | [ ] |
| EC-33 | Add agreed editorial terms to Stage 2. | Language excludes operational announcement terminology. | [ ] |
| EC-34 | Update Stage 3 classification. | Classification reflects only the retained editorial capability. | [ ] |
| EC-35 | Update Stage 4 and its context map. | Purpose, owned data, dependencies and non-ownership match the decision. | [ ] |
| EC-36 | Add Stage 5 editorial boundary tests. | Representative authoring and publication scenarios test cohesion. | [ ] |
| EC-37 | Update the high-level architecture and migration roadmap. | Products, integrations, transition states and ownership are consistent. | [ ] |
| EC-38 | Create an architecture decision record. | ADR records options, evidence, decision, consequences, owner and review date. | [ ] |

## Immediate Next Tasks

Start with EC-02, EC-05, EC-06, EC-08 and EC-09. These establish what editorial content is actually in use before selecting a target approach.
