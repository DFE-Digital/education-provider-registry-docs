# DDD Service Composition Remediation Task List

## Purpose

This document turns the recommendations in `ddd-service-composition-validation.md` into a working remediation task list.

We should use this as the backlog for closing the design gaps before Stage 5 boundary testing. Each task has a status so we can work through the list over multiple sessions without losing where we are.

## Status Key

| Status | Meaning |
| --- | --- |
| Not started | No remediation work has been completed yet. |
| In progress | A remediation document or design change has been started but not completed. |
| Blocked | The task cannot progress without an external decision or missing input. |
| Complete | The recommendation has been satisfied and the relevant design artefacts have been updated. |

## Priority Key

| Priority | Meaning |
| --- | --- |
| P1 | Blocking for Stage 5 boundary testing. |
| P2 | Required before implementation design can begin with confidence. |
| P3 | Required before beta delivery or operational readiness decisions are locked. |

## Remediation Tasks

| ID | Status | Priority | Remediation task | Source recommendation | Expected output | Done when |
| --- | --- | --- | --- | --- | --- | --- |
| DDD-001 | In progress | P1 | Establish whether Reference Data forms a bounded context. | 4.1 and priority action 1 | DDD evidence and boundary-test results for Reference Data as a candidate bounded context. | Reference Data has passed through the same DDD stages as the other candidates, and its resulting boundary and relationships are documented in the context map. |
| DDD-002 | Not started | P1 | Resolve whether External Read API is a bounded context or product/API layer. | 4.2 and priority action 2 | A decision note updating the Stage 4 model and read-model ownership position. | The model states whether the External Read API owns projections or exposes domain-owned projections, and Stage 4 is updated accordingly. |
| DDD-003 | Not started | P1 | Define the PDP attribute supply model. | 4.4 and priority action 3 | Access-control scenario analysis for at least three complex decisions. | For each scenario, required attributes, owning context, supply method, caching position and failure mode are documented. |
| DDD-004 | Not started | P1 | Correct and extend the Stage 4 context map. | 4.11 and priority action 4 | Updated Stage 4 context map with integration styles. | The context map distinguishes synchronous/asynchronous interactions, domain event flows, downstream integration, and PDP attribute-supply direction. |
| DDD-005 | Not started | P2 | Define aggregate boundaries for Establishment Registry and Governance. | 4.9 and priority action 5 | Tactical DDD note covering principal aggregates. | Aggregate roots, consistency boundaries, invariants and emitted events are defined for the key Establishment Registry and Governance aggregates. |
| DDD-006 | Not started | P2 | Specify the workflow-to-domain apply protocol. | 4.3 and priority action 6 | Workflow integration protocol document. | The apply request, response, idempotency, retry, timeout, conflict detection and verification-failed behaviour are documented. |
| DDD-007 | Not started | P2 | Produce a strangler-sequence-to-bounded-context mapping. | 4.5 and priority action 7 | Mapping table linking delivery phases to bounded contexts and dependencies. | Each strangler step identifies extracted contexts, required dependencies, anti-corruption responsibilities and fallback position. |
| DDD-008 | Not started | P3 | Define the minimum access-control implementation for authenticated read. | 4.8 and priority action 8 | Public-beta authenticated-read access-control scope. | Public, authenticated, organisation-scoped and PDP-protected fields are classified, and the public-beta PDP scope is defined. |
| DDD-009 | Not started | P2 | Add Extracts and Outbound Integrations as a named capability or bounded-context candidate. | 4.6 | Outbound integrations capability note and context-map update. | Existing downstream consumers, extracts, GOV.UK Notify, UKRLP enrichment and migration paths are mapped to owning contexts and publication patterns. |
| DDD-010 | Not started | P2 | Define an audit event taxonomy. | 4.7 | Cross-context audit taxonomy. | Auditable event categories, emitting context, retention needs, correlation identifiers and support-history reconstruction are documented. |
| DDD-011 | Not started | P2 | Resolve GovernancePerson identity alignment. | 4.10 | Governance person, EDM Person/Role and Access Control Actor alignment note. | The design states whether governance people can be system actors and how GovernancePerson relates to identity-provider subjects and Access Control Actor. |
| DDD-012 | Not started | P2 | Clarify domain events versus event sourcing. | 4.12 | Integration assumptions update. | The design states that domain events are integration events, not event sourcing, and defines minimum event content. |
| DDD-013 | Not started | P3 | Define the beta-to-target architecture relationship. | Cross-cutting risk: beta bounded-context design does not match post-beta design | Transition note connecting beta read-model architecture to the target bounded-context model. | The beta architecture is explicitly described as an intermediate state, with risks and transition paths into target contexts. |
| DDD-014 | Not started | P3 | Decide whether a staleness indicator is mandatory during coexistence. | Cross-cutting risk: data freshness under coexistence | Coexistence data-freshness decision note. | Expected staleness window, user-facing wording, support handling and mandatory/optional staleness indicator decision are documented. |
| DDD-015 | Not started | P3 | Define the bounded-context operational ownership model. | Cross-cutting risk: no operational model | Operational model for proposed contexts. | Each context has a proposed owning team, SLA/SLO expectation, escalation route, backup/migration responsibility and support tooling implication. |

## Suggested Working Order

We should start with the P1 tasks because they block meaningful Stage 5 boundary testing:

1. DDD-001 Reference data ownership.
2. DDD-002 External Read API boundary.
3. DDD-003 PDP attribute supply.
4. DDD-004 Stage 4 context map correction.

Then we should close the implementation-design prerequisites:

1. DDD-005 Aggregate boundaries.
2. DDD-006 Workflow apply protocol.
3. DDD-007 Strangler-to-bounded-context mapping.
4. DDD-009 Extracts and outbound integrations.
5. DDD-010 Audit event taxonomy.
6. DDD-011 GovernancePerson identity alignment.
7. DDD-012 Domain events versus event sourcing.

The P3 tasks should be picked up before beta scope and operational readiness are treated as stable:

1. DDD-008 Minimum authenticated-read access control.
2. DDD-013 Beta-to-target architecture relationship.
3. DDD-014 Coexistence staleness indicator.
4. DDD-015 Operational ownership model.

## Task Update Rules

When we work a task, update this document in the same session:

- Change `Status` to `In progress` when a remediation artefact is started.
- Change `Status` to `Complete` only when the expected output exists and the relevant upstream design documents have been updated.
- Add short notes below the task list if a task is blocked or if the expected output changes.

## Notes

- 2026-07-03: The DDD stage documents were moved into `docs/transformation/high-level/domain-driven-design` so the DDD process artefacts have a clearer home. At the time this was a workspace-structure change only; `DDD-001` was completed later by the reference-data ownership analysis below.
- 2026-07-03: Added `docs/transformation/high-level/domain-driven-design/reference-data-ownership-analysis.md`. This is evidence for `DDD-001`, not a completed bounded-context decision.
- 2026-07-06: Reference Data was added to `high-level-design-development-process.md` as an undecided candidate bounded context on the same footing as Establishment and Establishment Group. The DDD process will determine the outcome.
