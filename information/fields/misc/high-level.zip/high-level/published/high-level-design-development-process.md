# High-Level Design Development Process

## Purpose

We need to produce a high-level design for the transformed Education Provider Registry.

Before we draw the high-level design, we should show that we have used domain-driven design principles to identify, test and explain the bounded contexts. This gives us a stronger foundation than starting with a component diagram or mapping the current database structure directly into new services.

The process below describes how we move from evidence, through domain language and bounded-context testing, towards a high-level design that is easier to explain, challenge and change.

## Outcomes

We are working towards two main outcomes.

| Outcome | Purpose | Format |
| --- | --- | --- |
| Bounded-context evidence | Shows that we have used domain-driven design principles to identify and test the main service boundaries. | Narrative evidence with candidate contexts, context map, boundary tests, assumptions, risks and open questions. |
| High-level design | Describes the agreed target architecture and how the major components work together. | High-level design with C4 diagrams, responsibilities, integration patterns, data ownership, access-control approach, workflow approach and key design decisions. |

## Design Approach

Domain-driven design does not start by drawing services. It starts by understanding the business domain and the language used inside it.

We should use domain-driven design to:

1. Identify the core business capabilities.
2. Build a shared language for each capability.
3. Separate concepts that look similar but have different business meaning.
4. Identify bounded contexts where a model, language and set of rules should be internally consistent.
5. Map how bounded contexts collaborate.
6. Test whether the proposed boundaries reduce coupling, protect ownership and support change.

For this work, domain-driven design helps us avoid turning database areas, UI tabs or legacy structures directly into services. We should use legacy evidence, but we should not let the legacy schema define the target architecture by accident.

## Candidate Responsibilities

These are the responsibilities we currently need to resolve.

| Responsibility | Initial interpretation |
| --- | --- |
| Establishment and Establishment Group transactional data | Owns the operational model for establishments and establishment groups, including lifecycle, identity, classification, status, relationships and business rules. |
| Governance transactional data | Owns governance people, roles, appointments, governance bodies and governance relationships. This has its own language and lifecycle and should not be folded into establishment details by default. |
| Access Control | Owns policy, authorisation decisions, permissions, scopes, protected resources and decision audit. This needs to work across all domain service boundaries. |
| Data Stewardship Workflows | Owns change requests, proposed values, workflow tasks, decisions, evidence and workflow history. This coordinates changes across domain service boundaries without owning the authoritative domain records. |
| External Read API | Owns stable read contracts for external consumers. It should expose governed data products and API resources without leaking internal transaction models or workflow implementation details. |

## Candidate Bounded Contexts

We should start with these candidate bounded contexts and test them before treating them as service boundaries.

| Candidate bounded context | Primary model | Owns | Does not own |
| --- | --- | --- | --- |
| Establishment and Establishment Group | Establishment, establishment group, identifiers, classification, status, lifecycle, membership and relationships. | Authoritative establishment and establishment group transactional records. | Governance appointments, access policy, workflow lifecycle or external API contract design. |
| Governance | Governance person, role, appointment, board, trustee, member, local governor and governance relationship. | Authoritative governance transactional records and governance-specific business rules. | Establishment lifecycle, establishment group lifecycle, access policy or workflow lifecycle. |
| Access Control | Actor, role, group, scope, protected resource, action, policy, policy version, decision and audit. | Authorisation policy, policy versions, access decisions and decision audit. | Domain records or change-request lifecycle. |
| Data Stewardship Workflow | Change request, change item, proposed value, task, decision, evidence, workflow state and workflow history. | Workflow lifecycle and the record of proposed, reviewed, approved and applied changes. | Authoritative establishment or governance records, access policy or external API contracts. |
| External Read API | API resource, representation, version, consumer, contract and read permission. | External consumer contract and read-facing resource model. | Domain transaction ownership, workflow ownership or internal persistence model. |

## Cross-Boundary Context Map

We should make the dependencies explicit before we draw the high-level design.

```mermaid
flowchart LR
    establishment["Establishment and Establishment Group\nbounded context"]
    governance["Governance\nbounded context"]
    workflow["Data Stewardship Workflow\nbounded context"]
    access["Access Control\nbounded context"]
    readapi["External Read API\nbounded context"]

    workflow -->|Requests validation and applies approved changes| establishment
    workflow -->|Requests validation and applies approved changes| governance
    workflow -->|Asks whether workflow action is allowed| access
    readapi -->|Reads governed establishment and group data| establishment
    readapi -->|Reads governed governance data| governance
    readapi -->|Asks whether read action is allowed| access
    establishment -->|Uses policy decision for protected actions| access
    governance -->|Uses policy decision for protected actions| access
```

This is a starting map. We should refine it as we test the bounded contexts.

## Boundary Tests

We should test each candidate bounded context before treating it as a service boundary.

| Test | Question we should ask | Evidence we should capture |
| --- | --- | --- |
| Language test | Does this context have its own business language, or is it just a technical grouping? | Vocabulary differences, terms with different meanings and business examples. |
| Ownership test | Is there a clear owner for the data and rules in this context? | Business ownership, data ownership, stewardship responsibility and decision authority. |
| Lifecycle test | Do the main entities in this context change together through a coherent lifecycle? | Lifecycle states, transitions, events and change triggers. |
| Rule consistency test | Are the rules internally consistent inside the context and different outside it? | Validation rules, policy rules, workflow rules and exception handling. |
| Transaction test | What must change atomically, and what can be eventually consistent? | Transaction boundaries, consistency needs and cross-context events. |
| Access-control test | Can Access Control make decisions across the boundary without owning domain data? | Protected resources, actions, scopes and policy attributes needed from the context. |
| Workflow test | Can Data Stewardship Workflow coordinate change without owning the domain model? | Validation commands, apply commands, proposed values, decision points and audit needs. |
| API contract test | Can the External Read API expose useful resources without leaking internal model details? | Consumer needs, resource shapes, versioning and anti-corruption requirements. |
| Change test | Would likely policy or organisational changes be contained mostly inside this boundary? | Change scenarios and likely blast radius. |
| Coupling test | Does the boundary reduce coupling, or does it introduce orchestration noise? | Dependency map, synchronous calls, event flows and known failure modes. |

## Staged Work Plan

### Stage 1: Gather And Normalise Evidence

We should collect the evidence already produced and normalise it into the language needed for bounded-context design.

Inputs should include:

- Establishment and establishment group analysis.
- Governance analysis.
- Domain model and ontology analysis.
- Access-control analysis, vocabulary and conceptual model.
- Data-stewardship workflow analysis and vocabulary.
- Existing service-boundary analysis.
- Read API and read-model assumptions.

Outputs:

- Evidence notes grouped by candidate bounded context.
- Glossary conflicts and terms that need resolving.
- Initial assumptions and open questions.

### Stage 2: Define The Ubiquitous Language

We should define the business language for each context before we decide whether it deserves a separate service.

For each candidate context, we should capture:

- Core nouns.
- Core verbs.
- Lifecycle states.
- Business events.
- Rules and invariants.
- Terms that should not be reused across contexts.

Outputs:

- Ubiquitous language by candidate context.
- Terms that need a decision because they are overloaded or legacy-specific.

### Stage 3: Identify And Classify Subdomains

We should classify the subdomains so we know where to spend design effort.

| Subdomain | Suggested classification | Rationale |
| --- | --- | --- |
| Establishment and Establishment Group | Core or supporting, to be confirmed | Central to the registry and public value of the service. Needs careful modelling because many other capabilities depend on it. |
| Governance | Supporting, with high business importance | Important, specialised and likely to have its own rules and lifecycle. |
| Access Control | Generic capability with EPR-specific policy | Authorisation is a solved architectural problem, but the protected resources, scopes and policy attributes are domain-specific. |
| Data Stewardship Workflow | Supporting capability with EPR-specific routes | Workflow engines are generic, but EPR change routes, evidence, stewardship and maker-checker rules are domain-specific. |
| External Read API | Supporting platform/product capability | Consumer contract and API product design are essential, but they should be derived from domain and consumer needs. |

Outputs:

- Subdomain classification with rationale.
- Areas that need deeper domain modelling before service decisions are locked.

### Stage 4: Propose Bounded Contexts

We should turn the candidate contexts into a proposed bounded-context model.

For each bounded context, we should define:

- Purpose.
- Business capability.
- Owned model.
- Owned data.
- Key rules.
- Public contracts.
- Events or commands offered to other contexts.
- Dependencies on other contexts.
- Things it explicitly does not own.

Outputs:

- Bounded-context catalogue.
- Context map showing dependencies and integration styles.

### Stage 5: Test The Boundaries

We should test the proposed boundaries against real scenarios.

Example scenarios:

- Update establishment details.
- Change an establishment group relationship.
- Add or end a governance role.
- Apply maker-checker approval to a sensitive change.
- Enforce field-level access control.
- Publish a changed record to external read consumers.
- Show public read data through the External Read API.
- Handle a rejected, returned or superseded change request.

For each scenario, we should ask:

- Which context owns the command?
- Which context owns the data?
- Which context validates the change?
- Which context decides access?
- Which context records workflow history?
- Which context publishes or exposes the result?
- What must be synchronous?
- What can be asynchronous?
- What would be difficult if the boundary is wrong?

Outputs:

- Scenario-based boundary test results.
- Boundary changes or open decisions.

### Stage 6: Produce The High-Level Design

After the bounded contexts are agreed, we should produce the high-level design.

The high-level design should include:

- Scope and design goals.
- Architecture principles.
- C4 system context diagram.
- C4 container diagram.
- Bounded-context diagram.
- Key runtime flows.
- Service responsibilities.
- Data ownership and persistence boundaries.
- Access-control approach.
- Data-stewardship workflow approach.
- External Read API approach.
- Integration patterns.
- Security and audit considerations.
- Operational considerations.
- Key decisions, assumptions, risks and open questions.

## C4 Diagrams

We should use C4 to describe the high-level design at the right level of abstraction.

| Diagram | Purpose | Notes |
| --- | --- | --- |
| System Context | Shows EPR, users, external systems and major external dependencies. | Good first diagram for senior stakeholders. |
| Container | Shows the main deployable or executable parts: frontend, backend APIs, domain services, workflow, access control, read API and data stores. | This should be the main high-level design diagram. |
| Component, selective only | Shows internals only where a boundary needs explanation. | We should avoid component diagrams for every service unless needed. |
| Dynamic diagrams | Shows important flows such as proposed data change, approval and read API consumption. | Use sparingly to explain cross-boundary behaviour. |

## Evidence We Need Before Drawing The High-Level Design

We should be able to answer these before the high-level design is treated as more than a sketch:

- Do Establishment and Establishment Group belong in the same bounded context, or should they split?
- Does Governance need to be its own bounded context and service from the start?
- What resource model does Access Control protect across Establishment, Group, Governance, Workflow and Read API?
- What workflow state does Access Control need as decision context?
- What commands does Workflow send to Establishment and Governance services?
- What data does the External Read API own, and what does it only expose?
- Which data stores are transactional stores, read models, audit stores or policy stores?
- Which flows must be synchronous, and which should use events?
- What is in scope for beta, and what is target architecture beyond beta?

## Working Rule

We should not draw the high-level design as the first design act.

We should first prove the bounded contexts using domain evidence and scenario tests. Once those boundaries are credible, the high-level design can show how the architecture supports them.
