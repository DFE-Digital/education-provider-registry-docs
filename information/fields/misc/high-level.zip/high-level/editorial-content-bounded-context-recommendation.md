# Editorial Content — Bounded Context Recommendation

## Purpose

This recommendation considers authored editorial content as a candidate bounded context for EPR.

It covers news, frontend editorial banners, FAQs, documents, content pages and glossary entries. It explicitly excludes Secure Access announcements, event triggers, outbound delivery, publication attempts and retry/removal processing. Those form a separate operational communication concern documented by the announcement-subdomain investigation.

## Current-State Basis

The [current-state analysis](analysis/editorial-content-candidate-bounded-context-analysis.md) identifies these editorial capabilities:

| Capability | Legacy tables | Frontend tables |
|---|---|---|
| News | `NewsStory`, `NewsStory_UserGroup` | `FrontEnd.NewsArticles` |
| Editorial banners | — | `FrontEnd.NotificationTemplates`, `FrontEnd.NotificationBanners` |
| FAQs | `FAQ`, `FAQSubject`, `FAQGroup`, `FAQ_FAQGroup` | `FrontEnd.FaqGroups`, `FrontEnd.FaqItems` |
| Documents | `Document`, `DocumentationSection`, `Document_UserGroup` | — |
| Glossary | `GlossaryItem` | `FrontEnd.GlossaryItems` |
| Content pages | `ContentDocument`, `Section` | — |

The implementations are uneven. Some capabilities have separate legacy and frontend shapes; others are legacy-only. Current authority and business use remain unresolved for several stores.

## Why This Is A Candidate

### Language

Editorial language includes article, banner, FAQ, glossary term, document, section, author, sign-off, effective date, publication and archive. This is distinct from provider registration and governance language.

### Lifecycle

Editorial content is authored, reviewed, published, scheduled, expired, archived or deleted. These states do not follow establishment or governance-record lifecycles.

### Ownership

Editorial quality and publication accountability are likely to require different responsibilities from provider-data stewardship. The current owner and operating model must still be confirmed.

### Data ownership

Editorial content may target or group readers, but it should not own establishment, group, governance, identity or permission-policy facts.

## Classification

Editorial publishing is a generic or supporting capability rather than a core provider-registry differentiator. This makes build, buy or delegate assessment essential. Runtime editing should not be assumed where source-controlled content or an approved publishing platform can meet the need.

## Recommendation

Treat **Editorial Content** as a candidate bounded context for discovery and boundary testing. Do not yet approve it as a separately deployed service.

Before confirming the context:

1. establish which editorial capabilities are still required
2. identify the source of truth for each content family
3. confirm actors, approval rules, audiences and audit needs
4. decide which content should be source-controlled, externally published, archived or runtime-managed
5. test whether the remaining runtime-managed editorial capabilities share ownership and consistency needs
6. assess build, buy and delegate options

## Provisional Shape If Retained

**Name:** Editorial Content

**Purpose:** Own runtime-managed editorial material presented by the service, including its authoring, publication, scheduling, audience presentation and archival lifecycle.

Potential owned concepts:

| Concept | Meaning |
|---|---|
| Editorial item | An authored article, FAQ, banner, document, glossary entry or page section. |
| Publication state | Draft, reviewed, published, expired, archived or deleted state. |
| Effective period | When content is eligible to be presented. |
| Editorial grouping | A subject, section or display group used to organise content. |
| Presentation audience | A reference to the audience for which content is shown, without owning identity or permission policy. |
| Editorial audit | Who authored, reviewed or changed content and when. |

Explicit non-ownership:

- Secure Access announcements and their templates
- provider-event trigger processing
- outbound message delivery, retries and publication history
- establishment, group and governance facts
- user identity and permission policy
- external publishing or file-storage products

## Candidate Relationship To Other Contexts

```mermaid
flowchart LR
    authors["Editorial administrators"] --> editorial["Editorial Content candidate"]
    access["Access Control"] -->|authorisation and audience policy| editorial
    editorial -->|published content| frontend["EPR frontend"]
    editorial -->|optional publication export| publishing["Approved publishing platform"]
```

This is a provisional relationship. It deliberately contains no provider-event or announcement-delivery flow.

## Open Questions

| Question | Why it matters |
|---|---|
| Which editorial stores are authoritative? | Determines migration scope and prevents duplicate content. |
| Which legacy capabilities still have live journeys? | Determines retirement and archival work. |
| Which material genuinely needs runtime administration? | Determines whether a custom persistence capability is needed. |
| Who authors, approves and owns each content family? | Tests whether the capabilities belong within one organisational boundary. |
| Are audience-specific news, documents or banners still required? | Determines integration with Access Control and presentation rules. |
| What audit, retention and accessibility rules apply? | Determines the required content lifecycle and product fit. |

## Separate Announcement Concern

Secure Access announcements must be assessed independently using:

- `docs/data/investigation/announcement/announcement-subdomain-analysis.md`
- `docs/data/investigation/announcement/announcement-subdomain-summary.md`

No conclusion about that operational capability should be inferred from this Editorial Content recommendation.
