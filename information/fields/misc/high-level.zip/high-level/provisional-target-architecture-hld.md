# Provisional Target Architecture — High-Level Design

**Status:** Provisional — for team orientation only. This is a directional view, not a committed design. Boundaries and interaction patterns are subject to change as the Domain Driven Design process progresses.


---

## Purpose

This document gives the development team an early picture of where the DDD work is heading architecturally. It is not a finalised service design. It is intended to signal the likely shape of the system so that early technical decisions do not close off the target architecture.


---

## Container Diagram

## Diagram Key

```mermaid
C4Container

    UpdateLayoutConfig($c4ShapeInRow="5", $c4BoundaryInRow="1")

    System_Boundary(key, "Diagram key") {
        Container(frontendKey, "Frontend component", "Web user interface", "")
        Container(apiKey, "API application", "Application/API service", "")
        ContainerDb(databaseKey, "Database", "")
    }

    UpdateElementStyle(frontendKey, $bgColor="#dcfce7", $fontColor="#000000", $borderColor="#15803d")
    UpdateElementStyle(apiKey, $bgColor="#dbeafe", $fontColor="#000000", $borderColor="#1d4ed8")
    UpdateElementStyle(databaseKey, $bgColor="#74b2fb", $fontColor="#000000", $borderColor="#1e3a8a")
```

```mermaid
C4Container
    UpdateLayoutConfig($c4ShapeInRow="6", $c4BoundaryInRow="1")

    title EPR Provisional Target Architecture — Container View

    System_Ext(identity, "DfE Sign-in", "Identity Provider<br> OIDC authentication")

    Person(user, "User", "DfE staff, Public Beta users")
    Person(public_consumer, "External Consumer", "Public internet / approved external API consumers")
    Person(internal_consumer, "Internal Consumer", "DfE internal systems")

    Boundary(frontend, "Presentation and Read Access") {

        Container(fe, "Web Frontend", "C# on .NET 10)", "Renders HTML pages using Gov.uk templates, manages session, coordinates reads from domain APIs")

        Container(read_api_public, "External Read API - Public", "REST API (outer trusted zone)", "Stable, versioned, anti-corruption layer exposed for public internet / approved external use.<br> Owns published representations of establishment, group and governance data.")

        Container(read_api_internal, "External Read API - Internal", "REST API (inner trusted zone)", "Same published read capability deployed for DfE internal systems with internal network exposure,<br> access policies, rate limits and operational controls.")

    }

    Boundary(domain, "Domain") {
        Container(estab_api, "Establishment and Groups API", "BE API", "Authoritative registry of establishments, groups, identifiers, classifications, locations and relationships.Validates and<br> applies approved changes from Data Stewardship.")

        Container(gov_api, "Governance API", "BE API", "Authoritative registry of governance appointments, roles, people and appointing bodies. Validates and applies approved<br> governance changes from Data Stewardship.")

        Container(ds_api, "Data Stewardship API", "Workflow engine", "Owns the controlled change process: change requests, proposed values, review tasks, approvals, rejections,<br> apply coordination. Does NOT own domain data — orchestrates validation and apply via domain APIs.")

        Container(ac_api, "Access Control API", "Policy engine", "Evaluates whether an actor can perform an action on a protected resource. Called by all APIs before any protected operation.<br> Owns policy, roles, assignments, decision audit.")
    }

    Boundary(databases, "Domain Databases — one per service") {
        ContainerDb(ds_db, "Data Stewardship DB", "PostgreSQL", "Change requests, proposed values,<br> workflow states, review tasks, decisions, workflow history")

        ContainerDb(estab_db, "Establishment DB", "PostgreSQL", "Establishments, groups, memberships, relationships, locations")

        ContainerDb(ac_db, "Access Control DB", "PostgreSQL", "Policy documents, roles, assignments, access decisions, decision audit")

        ContainerDb(gov_db, "Governance DB", "PostgreSQL", "Governance appointments, roles, people, appointing bodies")
    }

    Rel(user, identity, "Authenticates via", "OIDC")
    Rel(identity, fe, "Issues identity token to", "OIDC callback")
    Rel(user, fe, "Uses", "HTTPS")
    Rel(read_api_public, estab_api, "Read establishments and groups", "REST/JSON")
    Rel(read_api_public, gov_api, "Read governance data", "REST/JSON")
    Rel(read_api_internal, estab_api, "Read establishments and groups", "REST/JSON")
    Rel(read_api_internal, gov_api, "Read governance data", "REST/JSON")
    Rel(fe, ac_api, "Is this read action allowed?", "REST/JSON")
    Rel(fe, estab_api, "Read establishments and groups", "REST/JSON")
    Rel(fe, gov_api, "Read governance data", "REST/JSON")
    Rel(fe, ds_api, "Submit change request", "REST/JSON")
    Rel(estab_api, ac_api, "Is this establishment action allowed?", "REST/JSON")
    Rel(gov_api, ac_api, "Is this governance<br> action allowed?", "REST/JSON")
    Rel(ds_api, ac_api, "Is this workflow action allowed?", "REST/JSON")
    Rel(read_api_public, ac_api, "Is this read action allowed?", "REST/JSON")
    Rel(read_api_internal, ac_api, "Is this read action allowed?", "REST/JSON")
    Rel(ds_api, estab_api, "Validate proposed change /<br> Apply approved change", "REST/JSON")
    Rel(ds_api, gov_api, "Validate proposed change /<br> Apply approved change", "REST/JSON")
    Rel(public_consumer, read_api_public, "Reads establishment, group and governance data", "HTTPS / REST")
    Rel(internal_consumer, read_api_internal, "Reads establishment, group and governance data", "HTTPS / REST")
    Rel(estab_api, estab_db, "Reads / writes", "")
    Rel(gov_api, gov_db, "Reads / writes", "")
    Rel(ac_api, ac_db, "Reads / writes", "")
    Rel(ds_api, ds_db, "Reads / writes", "")

    UpdateRelStyle(user, identity, $offsetX="-50", $offsetY="30")
    UpdateRelStyle(identity, fe, $offsetX="-30", $offsetY="-20")
    UpdateRelStyle(read_api_public, estab_api, $offsetX="20", $offsetY="-70")
    UpdateRelStyle(read_api_public, gov_api, $offsetX="-30", $offsetY="-30")
    UpdateRelStyle(read_api_internal, estab_api, $offsetX="20", $offsetY="-70")
    UpdateRelStyle(read_api_internal, gov_api, $offsetX="-30", $offsetY="-30")
    UpdateRelStyle(fe, ac_api, $offsetX="-380", $offsetY="-170")
    UpdateRelStyle(fe, estab_api, $offsetX="-30", $offsetY="0")
    UpdateRelStyle(fe, gov_api, $offsetX="-230", $offsetY="-50")
    UpdateRelStyle(fe, ds_api, $offsetX="-90", $offsetY="-40")
    UpdateRelStyle(estab_api, ac_api, $offsetX="-180", $offsetY="-30")
    UpdateRelStyle(gov_api, ac_api, $offsetX="-100", $offsetY="-10")
    UpdateRelStyle(ds_api, ac_api, $offsetX="-40", $offsetY="30")
    UpdateRelStyle(ds_api, estab_api, $offsetX="-10", $offsetY="0")
    UpdateRelStyle(read_api_public, ac_api, $offsetX="-170", $offsetY="-130")
    UpdateRelStyle(read_api_internal, ac_api, $offsetX="-170", $offsetY="-130")
    UpdateRelStyle(ds_api, estab_api, $offsetX="-10", $offsetY="0")
    UpdateRelStyle(ds_api, gov_api,, $offsetX="-50", $offsetY="-20")
    UpdateRelStyle(public_consumer, read_api_public, $offsetX="-60", $offsetY="-50")
    UpdateRelStyle(internal_consumer, read_api_internal, $offsetX="-60", $offsetY="-50")
    UpdateRelStyle(estab_api, estab_db, $offsetX="0", $offsetY="70")
    UpdateRelStyle(gov_api, gov_db, $offsetX="0", $offsetY="80")
    UpdateRelStyle(ac_api, ac_db, $offsetX="-43", $offsetY="0")
    UpdateRelStyle(ds_api, ds_db, $offsetX="-20", $offsetY="0")
    UpdateRelStyle(x,y, $offsetX="0", $offsetY="0")


    UpdateElementStyle(fe, $bgColor="#dcfce7", $fontColor="#000000", $borderColor="#15803d")
    UpdateElementStyle(read_api_public, $bgColor="#dcfce7", $fontColor="#000000", $borderColor="#15803d")
    UpdateElementStyle(read_api_internal, $bgColor="#dcfce7", $fontColor="#000000", $borderColor="#15803d")
    UpdateElementStyle(estab_api, $bgColor="#dbeafe", $fontColor="#000000", $borderColor="#1d4ed8")
    UpdateElementStyle(gov_api, $bgColor="#dbeafe", $fontColor="#000000", $borderColor="#1d4ed8")
    UpdateElementStyle(ds_api, $bgColor="#dbeafe", $fontColor="#000000", $borderColor="#1d4ed8")
    UpdateElementStyle(ac_api, $bgColor="#dbeafe", $fontColor="#000000", $borderColor="#1d4ed8")

    UpdateElementStyle(ds_db, $bgColor="#74b2fb", $fontColor="#000000", $borderColor="#1e3a8a")
    UpdateElementStyle(estab_db, $bgColor="#74b2fb", $fontColor="#000000", $borderColor="#1e3a8a")
    UpdateElementStyle(ac_db, $bgColor="#74b2fb", $fontColor="#000000", $borderColor="#1e3a8a")
    UpdateElementStyle(gov_db, $bgColor="#74b2fb", $fontColor="#000000", $borderColor="#1e3a8a")

    
```

---

## What Each Component Owns

### Establishment and Groups API

The authoritative source of truth for all establishments and establishment groups.

- Establishments: identity (URN), type, status, identifiers, details, location, lifecycle links
- Establishment groups: trusts (MAT, SAT), federations, sponsors, children's centre groups; group identifiers (UID, Companies House, UKPRN)
- Group memberships and group-to-group relationships
- Field applicability rules driven by establishment type

This API validates and applies approved changes when instructed by the Data Stewardship API. It does not own the change workflow — it only accepts or rejects a change instruction.

### Governance API

The authoritative source of truth for governance data.

- Governance appointments (establishment-scoped via URN, group-scoped via UID)
- Governance roles: trustee, member, governor, local governor, chair, accounting officer, CFO, governance professional
- Governance people and identity data
- Appointing bodies and terms of office
- Privacy-sensitive: access to person data requires explicit access control

### Access Control API

A cross-cutting service that every other API calls before any protected operation.

- Policy documents and policy versions
- Actor roles, assignments and organisational scope
- Protected resource vocabulary and action vocabulary
- Access decisions and decision audit

**This is not a simple middleware layer.** It is a stateful policy engine with its own persistence. When it is unavailable, every protected operation across the entire system fails. Its availability is a system-wide dependency.

### Data Stewardship API

A cross-cutting workflow service. It owns the process of changing data — not the data itself.

- Change requests and their lifecycle (draft → submitted → reviewed → approved → applied → closed)
- Proposed values and current-value references
- Review tasks, decisions, evidence and comments
- Workflow history and process audit

**Critically:** when a change is approved, the Data Stewardship API calls the relevant domain API (Establishment or Governance) to apply it. The domain API remains authoritative — Data Stewardship only coordinates. 

### Web Frontend

A standards-aligned web frontend component. It renders the human-facing service and composes presentation data from the domain APIs without taking ownership of their domain data.

The frontend should follow GOV.UK frontend standards. The GOV.UK Service Manual says:

> "All government services must follow progressive enhancement, even if part of the service or a parent service needs JavaScript"

Source: <https://www.gov.uk/service-manual/technology/using-progressive-enhancement>

It also says:

> "Government services should be functional using only HTML."

Source: <https://www.gov.uk/service-manual/technology/using-progressive-enhancement>

For JavaScript frameworks, the same guidance says:

> "If your service is mostly built using components from the GOV.UK Design System and doesn't have a complex user interface, you do not need to use a client-side JavaScript framework."

Source: <https://www.gov.uk/service-manual/technology/using-progressive-enhancement>

And for single-page applications, it is explicit:

> "Do not build your service as a single-page application (SPA)."

Source: <https://www.gov.uk/service-manual/technology/using-progressive-enhancement>

In this architecture, the web frontend:

- Renders GovUK-styled HTML pages
- Manages user session after authentication via DfE Sign-in
- Reads establishment, group and governance data from the domain APIs
- Routes change submissions to Data Stewardship
- Checks access decisions before rendering protected data

The frontend is not the system. It is the surface.

### External Read API

The External Read API is a stable, versioned, anti-corruption layer for external consumers. It owns published representations of establishment, group and governance data, shielding consumers from internal model changes and from direct dependency on the transactional domain APIs.

- Versioned REST resources: establishment, establishment group, governance
- Denormalised read projections rebuilt from domain events published by Establishment and Governance APIs
- Its own read projection database, optimised for external read patterns
- Access-control checks before serving any protected read

**The External Read API is not a pass-through proxy.** It translates the internal domain model into stable external contracts. External consumers see the External Read API's representation, never the internal domain API directly. This is the anti-corruption layer that lets the internal model evolve without breaking downstream consumers.

The Read API may be deployed twice:

- **Public / outer trusted zone:** Exposed to the public internet or approved external consumers through the public API access route.
- **DfE internal / inner trusted zone:** Exposed to DfE internal systems through internal network controls and internal access policies.

This does not necessarily mean two different API products or two different data contracts. The design intent is that the same published read capability can be deployed in two trusted zones so that network exposure, authentication, authorisation, rate limits, monitoring, consumer onboarding and usage policies can be configured appropriately for each use case.

External consumers include: local authorities, Ofsted, UKRLP partners and extract subscribers. Internal consumers include DfE systems that consume establishment reference data.

The public and internal deployments should remain anti-corruption layers over the internal domain APIs. Neither deployment should expose the internal Establishment and Groups API or Governance API model directly.

---

## Key Architectural Principles

### Database per service

Each API has its own database. No cross-service database joins. No shared schema. If a service needs data from another service's domain, it calls that service's API — it does not read the database directly.

This is the critical constraint that makes the bounded contexts real. A shared database would mean the bounded context boundaries exist only on paper.

### Access control is called, not embedded

No domain API embeds access control logic. Every protected operation calls the Access Control API with the actor, action, resource and context attributes. The Access Control API returns allow or deny.

This means policy can change without deploying domain services. It also means every access decision is audited in one place.

### Data Stewardship orchestrates, does not own

The Data Stewardship API coordinates the change workflow. It never writes establishment, group or governance data directly. When a change is applied, the domain API writes it. This preserves domain ownership and keeps the audit trail in the right place: workflow history in Data Stewardship, domain change history in the domain service.

### Domain events for downstream consistency

The diagram shows Establishment and Governance APIs publishing domain events to downstream consumers. These are integration events — notifications that state has changed — not event sourcing. The domain APIs persist state conventionally (PostgreSQL) and publish an event after a successful state change. Downstream consumers, including the External Read API or a future extract service, subscribe to those events.

---

### Read API deployments by trusted zone

The Read API may have separate public and internal deployments. This allows the service to apply different trust-zone controls without duplicating domain ownership.

| Deployment | Primary audience | Control emphasis |
|---|---|---|
| Public / outer trusted zone Read API | Public internet and approved external consumers | Public API management, external consumer onboarding, internet-facing protection, throttling, published documentation and stricter exposure controls. |
| DfE internal / inner trusted zone Read API | DfE internal systems | Internal network access, internal identity and authorisation policies, service-to-service usage controls, operational monitoring and internal consumer management. |

Both deployments should read from the approved read projection / published representation, not directly from domain service databases. Policy differences belong in API management, access control, network controls and deployment configuration, not in divergent domain models.

## What Is Not In This Diagram

### External Read API read projection database

The External Read API deployments are included in the diagram, but the read projection database is not yet shown as a separate container. That database is implied by the External Read API responsibilities and should be added when the read model design is made explicit.

The read model design must decide whether the public and internal deployments share a single projection, use separate projections with the same contract, or use a controlled subset/superset pattern. That choice affects data minimisation, access-control enforcement, API management, operational support and reconciliation.

### Reference data

Establishment type codes, LA codes, phase codes, and other reference data appear as inputs to every context but no context owns them in the current design. This is an unresolved gap (see DDD validation document, blindspot 4.1). Likely owned by Establishment and Groups API or a small shared reference data service.

### Extract and notification infrastructure

Scheduled extract generation, push feeds to downstream DfE systems, GOV.UK Notify integration and legacy SOAP/REST compatibility interfaces are not shown. These will be needed before live and should be modelled as capabilities before Stage 5.

### Identity provider integration detail

DfE Sign-in is shown as an external system with two integration points: it issues identity tokens to the Web Frontend on successful OIDC authentication, and it provides user and organisation claims to the Access Control API (via JWKS endpoint or token introspection) so that the policy engine can resolve the authenticated actor's roles and organisation scope. The detail of claim mapping — which DfE Sign-in groups map to which EPR roles, and how organisation scope (LA, trust) is carried in claims — is not designed here but is a prerequisite for any authenticated journeys and for the Access Control API to function.

---

## Risks and Design Questions

| Area | Risk or question | Why it matters |
|---|---|---|
| Access Control availability | Every protected operation depends on the Access Control API being up. If it goes down, nothing works. | Needs an explicit availability contract, circuit-breaker strategy, or cached decision model for private beta. |
| Data Stewardship apply coupling | DS API makes synchronous calls to Establishment and Governance APIs on apply. If those APIs are slow or unavailable at apply time, the workflow stalls. | Consider a reliable async command pattern for the apply step, or define a clear retry and failure model. |
| Frontend calling two domain APIs | The FE currently reads directly from both Establishment and Governance APIs. For pages that combine data from both (e.g. a trust page showing group details plus governance appointments), the frontend must make two calls and join the results. | Consider a thin aggregation layer or BFF pass-through for combined read views. Not blocking for beta but worth designing. |
| Read API deployed in two trusted zones | Public/external consumers and DfE internal systems may need the same read capability but with different exposure, identity, access, rate limit and monitoring policies. | Consider public and internal Read API deployments sharing the same published contract while using separate API management, network and access-control configuration. Decide whether they share or separate the read projection. |
| No shared database, no shared schema | Enforcing database-per-service requires discipline across the team. The temptation to "just add a join" between the establishment DB and the governance DB will be real and should be explicitly ruled out in team conventions. | Add an ADR (Architecture Decision Record) banning cross-service database access. |
| Data Stewardship has no domain knowledge | DS API coordinates changes but cannot validate them — it delegates validation to the domain API. This means DS API is blind to whether a proposed change is semantically valid until it calls the domain API. | Stage 5 should define the validation protocol clearly: what DS API sends, what domain API returns, and what DS API does on validation failure. |

---

## Reading This With Stage 4

The five components in this diagram map directly to the Stage 4 bounded context proposal:

| Stage 4 bounded context | This diagram |
|---|---|
| Establishment Registry | Establishment and Groups API + Establishment DB |
| Governance | Governance API + Governance DB |
| Access Control | Access Control API + Access Control DB |
| Data Stewardship Workflow | Data Stewardship API + Data Stewardship DB |
| External Read API | Public and internal External Read API deployments + Read Projection DB |

This is a C4 container-level view. The next level of detail would be component diagrams within each container — which is Stage 5 work.
