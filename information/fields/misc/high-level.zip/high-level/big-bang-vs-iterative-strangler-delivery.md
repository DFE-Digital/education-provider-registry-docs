# Single Cutover Delivery Versus Iterative Strangler Delivery

## Purpose

This document explains why a single cutover delivery approach is a weaker fit for GIAS 2.0 than an iterative strangler approach.

In this context, single cutover delivery means building the replacement service as a large parallel system and switching users from the legacy service to the new service in one major transition. Iterative strangler delivery means replacing legacy capability in controlled slices, while the existing service continues to operate during the transition.

## Delivery Risk

Single cutover delivery concentrates delivery risk into one release event. For GIAS 2.0, that would mean establishment data, establishment groups, governance, location, access control, data stewardship workflows, integrations and public read access all need to work together before users receive meaningful value.

An iterative strangler approach spreads that risk across smaller releases. Each capability can be proven in production-like conditions before the next part of the service is moved. This gives us earlier evidence that the architecture, data model, operational model and user journeys are working.

## User Feedback

Single cutover delivery delays meaningful user feedback until late in the programme. Users may not be able to validate the new service properly until many assumptions have already been built into the product and data model.

Iterative delivery lets users validate specific capabilities as they are built. Search, establishment details, governance, location and change workflows can each be tested with real users before the full legacy service has been replaced.

## Data Migration Assurance

Single cutover delivery makes data migration harder to assure because all domains need to move together. Any weakness in one area can hold back the whole release.

A strangler approach allows data migration and reconciliation to happen in bounded slices. Establishments, establishment groups and governance can each be migrated, validated and reconciled against legacy data before the next domain is taken on.

## Dependency Discovery

Single cutover delivery increases the chance that hidden dependencies are discovered late. Integration issues, reporting dependencies, public data consumers and operational processes may only become visible near the end of the programme.

Incremental replacement exposes these dependencies earlier. We can test each slice against live operational constraints while the existing service remains available as a fallback.

## Business Value

Single cutover delivery requires the new system to match enough legacy behaviour before it can deliver visible value. This can create a long period where progress is real, but difficult for stakeholders to see or use.

Iterative strangler delivery creates visible progress through working capability. High-value or high-risk journeys can be replaced first, giving stakeholders regular evidence that GIAS 2.0 is becoming real rather than remaining a long-running technical replacement project.

## Operational Readiness

Single cutover delivery creates a difficult transition for users, support teams and operational teams. Training, service support, monitoring, runbooks and incident response all need to be ready for the same large launch.

Iterative delivery allows operational readiness to mature alongside the service. Support processes, user guidance and runbooks can be improved as each capability is released.

## Defect Diagnosis

Single cutover delivery makes defects more expensive to diagnose because many changes go live together. When a problem occurs, it can be difficult to tell whether the cause is data migration, integration, access control, workflow, UI behaviour or infrastructure.

Smaller releases make diagnosis easier. If one slice changes at a time, the team has a clearer understanding of which change introduced a defect and how to contain it.

## Design Quality

Single cutover delivery can force weak design decisions because every unresolved domain question becomes a blocker for the whole launch. There is pressure to make early decisions about bounded contexts, logical models, access control, workflows and integrations before enough evidence has been gathered.

A strangler approach lets the design improve as evidence improves. Bounded contexts and contracts can be stabilised through real implementation, not just analysis.

## Rollback And Fallback

Single cutover delivery makes rollback difficult because the whole service changes at once. If the release fails, the organisation may need to reverse a large migration and restore multiple operational processes at the same time.

Iterative strangler delivery gives safer fallback options. Legacy and new capabilities can run side by side during transition, allowing the team to pause, fix or roll back a smaller slice without reversing the whole programme.

## Recommendation

GIAS 2.0 should use an iterative strangler delivery approach rather than a single cutover delivery approach.

This gives us a better route to reduce delivery risk, validate the data model, test access control and data stewardship patterns, prove integrations, and release useful capability earlier.
