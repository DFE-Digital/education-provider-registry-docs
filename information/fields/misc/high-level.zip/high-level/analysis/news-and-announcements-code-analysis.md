# News And Announcements Code Analysis

## Purpose

We need to understand what the legacy estate means by `news`, `announcements` and `notifications`, because the terms sit close together but the implementations are not the same thing.

This note records what we can see in the Java backend, the C# frontend and the existing ERD/investigation evidence. It also answers the design question: are news and announcements a notification capability?

## What We Have Found

We have found three separate implementation areas:

| Area | Implemented In | Main Purpose | Is It A Notification Capability? |
| --- | --- | --- | --- |
| Legacy Java news stories | `gias-dd-backend` | Publish approved news content inside the legacy Java portal to selected user groups. | Mostly no. It is editorial/published content. It only touches notifications when a review email is sent for sign-off. |
| Legacy Java announcements | `gias-dd-backend` | Publish, unpublish and retry operational announcements to Secure Access using SOAP. | Partly, but not in the GOV.UK Notify email sense. It is an external publication/outbox capability. |
| C# frontend news and notification banners | `get-information-about-schools` | Manage public/frontend news articles and dated notification banners. | Mostly no. This is frontend editorial/presentation content, not outbound delivery. |

The important distinction is that these features display or publish content to an audience. They are not the same as the outbound email notification capability implemented by `NotificationSender` and GOV.UK Notify.

## Legacy Java News Stories

### Where The Code Lives

| Resource | What It Shows |
| --- | --- |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/news/NewsStory.java` | The Java domain entity for a news story. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/news/NewsStoryManagerImpl.java` | News story management, approval/sign-off rules and review email. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/dao/hibernate/NewsStoryDaoImpl.java` | Query logic for visible news stories by user group and effective date. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/web/news/DisplayNewsController.java` | Java portal routes for displaying one story or all stories. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/web/backoffice/NewsListController.java` | Back-office news management. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/validator/NewsStoryValidator.java` | Validation for Java news story editing. |
| `gias-dd-backend/src/main/webapp/WEB-INF/jsp/news/*.jspx` | Java JSP views for displaying news stories. |
| `gias-dd-backend/src/main/webapp/WEB-INF/jsp/backoffice/news.jspx` | Java back-office news screen. |

### What A Java News Story Is

`NewsStory` stores:

- Title.
- Summary.
- Body text.
- Effective date.
- Approval state.
- Target user groups.
- Creator.
- Required sign-off user.
- Actual sign-off user.
- Created and updated timestamps.

`NewsStoryDaoImpl` only returns news stories where:

- The current user's group is in the story's target groups.
- The story is approved.
- The effective date is on or before the current date.

The results are ordered by effective date and id descending.

This means Java news is audience-targeted editorial content. It is not an email or delivery attempt.

### Where It Touches Notifications

`NewsStoryManagerImpl.sendNotification(...)` can send a news-story review email to the sign-off user.

When `notify.enabled` is true, it calls:

`notificationSender.sendNewsStoryReviewEmail(...)`

When `notify.enabled` is false, it falls back to the older `newsStoryReviewEmail` template path.

This is the only part of the Java news flow that is a notification in the outbound email sense. The news story itself remains editorial content.

## Legacy Java Announcements

### Where The Code Lives

| Resource | What It Shows |
| --- | --- |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/dqp/AnnouncementTemplate.java` | Reusable announcement template, target groups, type, enabled flag and manual-send flag. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/dqp/AnnouncementCollection.java` | Publication outbox/history record for publish and unpublish attempts. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/ws/client/AnnouncementType.java` | Announcement type enum used in Java and stored in the database. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/ws/client/SafeSynchronizationService.java` | Publishes and unpublishes announcements to Secure Access through SOAP. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/dqp/AnnouncementTemplateManagerImpl.java` | Announcement template management. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/dqp/AnnouncementCollectionManagerImpl.java` | Announcement collection maintenance and reinitialisation operations. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/web/announcement/*.java` | Java back-office announcement configuration screens. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/ResyncAnnouncementJob.java` | Retry path for failed or incomplete publish/unpublish operations. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/staff/*Announcement*.java` | Scheduled governance/staff announcement producers. |
| `gias-dd-backend/src/main/webapp/integration/announcement/announcement.wsdl` | Secure Access announcement SOAP contract. |

### What A Java Announcement Is

Java announcements are not news stories.

An announcement starts from an `AnnouncementTemplate`. The template holds:

- Announcement type.
- Action/trigger classification.
- Title.
- Summary.
- Body.
- Expiry behaviour.
- Enabled state.
- Target user groups.
- Whether it can be sent manually.

When the system decides an announcement should be published, it creates an `AnnouncementCollection` record. Despite the name, this is not a simple content collection. It records operational publication state:

- Target Secure Access organisation id.
- Establishment URN or group UID where applicable.
- Announcement type.
- Whether the item should be published.
- Whether it has been published.
- Whether the item should be removed.
- Whether it has been removed.
- Publish and unpublish dates.
- Publish and unpublish attempt counts.
- Last error messages.
- Template values in `AnnouncementCollectionValues`.

`SafeSynchronizationService` then uses the Secure Access SOAP service to publish or unpublish the announcement.

The existing investigation in `docs/data/investigation/announcement/announcement-subdomain-analysis.md` describes `AnnouncementCollection` as an outbox, retry ledger and publication history. That interpretation matches the Java code.

### Announcement Types

The Java enum contains:

| Type | Meaning In The Code |
| --- | --- |
| `Standart` | Standard/manual announcement type. The spelling is as implemented. |
| `EDU_DQP_WARN` | Data-quality warning announcement. |
| `EDU_DQP_ISSUE` | Data-quality issue announcement. |
| `EDU_DQP_NO_RESTRICT` | Data-quality no-restriction announcement. |
| `EDU_GOV_PERIODIC` | Governance periodic reminder announcement. |
| `EDU_GOV_APPOINTMENT` | Governance appointment-related announcement. |

These are operational or workflow announcements, not general news.

## C# Frontend News

### Where The Code Lives

| Resource | What It Shows |
| --- | --- |
| `get-information-about-schools/Web/Edubase.Data/Entity/NewsArticle.cs` | C# frontend news article entity in Azure Table Storage style. |
| `get-information-about-schools/Web/Edubase.Data/Repositories/NewsArticleRepository.cs` | Repository for frontend news articles. |
| `get-information-about-schools/Web/Edubase.Web.UI/Controllers/NewsController.cs` | Public/admin routes for listing, viewing, editing, deleting and auditing news articles. |
| `get-information-about-schools/Web/Edubase.Web.UI/Views/News/*.cshtml` | Frontend news views. |

### What A C# News Article Is

The C# frontend has its own `NewsArticle` model. It stores:

- Title.
- Article date.
- Whether to show the date.
- Content.
- Version.
- Tracker.
- Audit user, event and timestamp.

The `NewsController` provides:

- Public news index.
- Public article view.
- Admin manage, preview and edit routes.
- Create, update and delete routes.
- Audit views.

This looks like the current public/frontend news publishing model. It is separate from the legacy Java `NewsStory` table and workflow.

## C# Frontend Notification Banners

### Where The Code Lives

| Resource | What It Shows |
| --- | --- |
| `get-information-about-schools/Web/Edubase.Data/Entity/NotificationBanner.cs` | Frontend notification banner entity. |
| `get-information-about-schools/Web/Edubase.Data/Entity/NotificationTemplate.cs` | Reusable banner template content. |
| `get-information-about-schools/Web/Edubase.Data/Repositories/NotificationBannerRepository.cs` | Repository for banners. |
| `get-information-about-schools/Web/Edubase.Data/Repositories/NotificationTemplateRepository.cs` | Repository for templates. |
| `get-information-about-schools/Web/Edubase.Web.UI/Controllers/NotificationsController.cs` | Admin routes for banners, templates and audit. |
| `get-information-about-schools/Web/Edubase.Web.UI/Views/Shared/_NotificationsBannersPartial.cshtml` | Shared view for rendering banners. |

### What A Frontend Notification Banner Is

The frontend `NotificationBanner` stores:

- Importance.
- Content.
- Start date/time.
- End date/time.
- Version.
- Tracker.
- Audit user, event and timestamp.
- Optional link URLs and link text.

Its `Visible` property is true only when the current date/time is within the banner's start/end window.

This is called a notification banner, but it is not an outbound notification. It is dated presentation content rendered by the frontend.

## Are News And Announcements A Notification Thing?

Our answer should be careful.

| Feature | Is It A Notification? | Why |
| --- | --- | --- |
| Java news stories | No, except the review email. | The story is editorial content shown inside the Java portal to approved user groups. The only outbound notification is the sign-off/review email. |
| Java Secure Access announcements | Partly, but it is better named publication or operational communication. | The system publishes messages to Secure Access and records publish/unpublish state. It is not GOV.UK Notify email and does not resolve individual email recipients. |
| C# frontend news articles | No. | They are public/frontend editorial articles with versioning and audit. |
| C# frontend notification banners | No, despite the name. | They are dated content displayed on pages, not sent to a recipient. |

So we should not collapse news, announcements and GOV.UK Notify emails into one `Notifications` model.

The better interpretation is:

- `News` belongs with Editorial Content.
- `Frontend notification banners` belong with Editorial Content or Frontend Presentation Content.
- `Secure Access announcements` belong with Operational Communication / External Publication.
- `GOV.UK Notify emails` belong with Outbound Communication / Notifications.
- `News story review email` is a notification triggered by an editorial workflow.

## Why This Matters For DDD

The word `notification` is overloaded in the legacy estate.

We should distinguish:

| Concept | Normalised Meaning |
| --- | --- |
| News article/story | Authored content displayed in the service, usually managed by an editor/admin. |
| Notification banner | Dated frontend content displayed while active. |
| Secure Access announcement | Message published to another system, with publish/unpublish lifecycle state. |
| Outbound notification | A message sent to a recipient through a delivery channel such as GOV.UK Notify email. |
| Review notification | An outbound notification generated by an editorial workflow, such as asking a sign-off user to review a news story. |

This means the DDD process should not treat all of these as one bounded context just because they sound similar.

## Recommended Treatment

We should carry this forward as separate capability evidence:

| Capability Area | Recommended Treatment |
| --- | --- |
| Editorial Content | Include news articles/stories and frontend notification banners. These are authored/published content. |
| Outbound Communication / Notifications | Include emails sent through GOV.UK Notify, including the news story review email. |
| Operational Communication / External Publication | Include Secure Access announcements, because they have templates, target groups, publish/unpublish state, retry and an external SOAP integration. |

We should also keep a clear caveat in the design work:

> A legacy feature may be called a notification, but that does not mean it is an outbound notification. Some "notifications" are frontend banners, some are Secure Access announcements, and some are GOV.UK Notify emails.

## Open Questions

| Question | Why We Need To Answer It |
| --- | --- |
| Is legacy Java `NewsStory` still user-facing or has C# `NewsArticle` replaced it? | This determines whether Java news needs migration or only archival/current-state documentation. |
| Are Secure Access announcements still required in the target service? | They are a distinct external publication integration and may not belong in the core registry. |
| Do we need editable frontend notification banners in beta? | If yes, this is editorial/frontend content scope, not email notification scope. |
| Do we need review/sign-off workflows for news or banners? | Review workflows can trigger outbound notifications even when the content itself is not a notification. |
| Should Secure Access announcement state be retained, migrated or retired? | `AnnouncementCollection` behaves like an outbox/history table and may contain operational state. |

## Conclusion

News and announcements are implemented, but not as one thing.

The Java backend implements legacy news stories and Secure Access announcements. The C# frontend implements public/frontend news articles and notification banners.

Only a small part of the news implementation is an outbound notification: the Java news review email. Secure Access announcements are closer to operational publication than email notification. Frontend notification banners are presentation content.

For target design, we should avoid using `Notifications` as a catch-all. We should separate editorial content, outbound email notification and external announcement publication.
