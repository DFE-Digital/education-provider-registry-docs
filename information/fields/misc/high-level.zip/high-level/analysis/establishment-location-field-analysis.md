# Establishment Location Field Analysis

## Purpose

We analysed the public Location tab to understand whether location data varies by establishment type.

This helps us decide whether location belongs inside the Establishment Registry context and whether location needs the same level of type-specific modelling as establishment details.

This analysis records the fields displayed on the public GIAS Location tab for one sampled establishment from each of the 41 establishment types present in the June 2026 extract analysis.

The page pattern tested was:

```text
https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/{urn}#school-location
```

Sample URNs come from `docs/data/extract-data/establishment-fields/establishment-type-analysis.md`, section `Sample Establishment Per Type`.

## Methodology

For each sampled URN, we fetched the public establishment details page and parsed the `school-location` tab content from the GOV.UK summary-list rows.

The URL fragment `#school-location` is a browser-side tab anchor. The server returns the full establishment details page, and the Location tab is extracted from the returned HTML.

## Common Location Field Set

The following 11 fields appeared for 40 of the 41 sampled establishment types:

1. Government office region (GOR)
2. District
3. Ward
4. Parliamentary constituency
5. Urban/rural description
6. Government Statistical Service (GSS) local authority code
7. Easting
8. Northing
9. Unique property reference number (UPRN)
10. Middle super output area (MSOA)
11. Lower super output area (LSOA)

## Summary

Location display is highly consistent across establishment types.

| Measure | Result |
| --- | ---: |
| Sampled establishment types | 41 |
| Types showing the common location field set | 40 |
| Types with no sampled Location tab fields | 1 |

The sampled British schools overseas page did not show Location tab summary fields. One sampled Other independent school also displayed additional `Other sites` address rows, which appears to be record-specific rather than type-wide.

## Location Fields Grouped By Establishment Type

| Type code | Establishment type | Sample URN | Location display fields |
| --- | --- | ---: | --- |
| `01` | Community school | [100008](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100008#school-location) | Common 11-field set |
| `02` | Voluntary aided school | [100000](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100000#school-location) | Common 11-field set |
| `03` | Voluntary controlled school | [100192](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100192#school-location) | Common 11-field set |
| `05` | Foundation school | [100188](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100188#school-location) | Common 11-field set |
| `06` | City technology college | [100759](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100759#school-location) | Common 11-field set |
| `07` | Community special school | [100091](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100091#school-location) | Common 11-field set |
| `08` | Non-maintained special school | [101696](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/101696#school-location) | Common 11-field set |
| `10` | Other independent special school | [101077](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/101077#school-location) | Common 11-field set |
| `11` | Other independent school | [100001](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100001#school-location) | Common 11-field set, plus two `Address` rows under `Other sites` |
| `12` | Foundation special school | [100060](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100060#school-location) | Common 11-field set |
| `14` | Pupil referral unit | [100006](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100006#school-location) | Common 11-field set |
| `15` | Local authority nursery school | [100004](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100004#school-location) | Common 11-field set |
| `18` | Further education | [127066](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/127066#school-location) | Common 11-field set |
| `24` | Secure units | [128604](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/128604#school-location) | Common 11-field set |
| `25` | Offshore schools | [132351](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/132351#school-location) | Common 11-field set |
| `26` | Service children's education | [132269](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/132269#school-location) | Common 11-field set |
| `27` | Miscellaneous | [104755](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/104755#school-location) | Common 11-field set |
| `28` | Academy sponsor led | [101857](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/101857#school-location) | Common 11-field set |
| `29` | Higher education institutions | [130545](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/130545#school-location) | Common 11-field set |
| `30` | Welsh establishment | [400000](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/400000#school-location) | Common 11-field set |
| `31` | Sixth form centres | [132838](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/132838#school-location) | Common 11-field set |
| `32` | Special post 16 institution | [121777](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/121777#school-location) | Common 11-field set |
| `33` | Academy special sponsor led | [138253](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138253#school-location) | Common 11-field set |
| `34` | Academy converter | [136266](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/136266#school-location) | Common 11-field set |
| `35` | Free schools | [136750](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/136750#school-location) | Common 11-field set |
| `36` | Free schools special | [138271](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138271#school-location) | Common 11-field set |
| `37` | British schools overseas | [130892](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/130892#school-location) | No location fields displayed in the sampled Location tab |
| `38` | Free schools alternative provision | [138262](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138262#school-location) | Common 11-field set |
| `39` | Free schools 16 to 19 | [138403](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138403#school-location) | Common 11-field set |
| `40` | University technical college | [136933](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/136933#school-location) | Common 11-field set |
| `41` | Studio schools | [137317](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/137317#school-location) | Common 11-field set |
| `42` | Academy alternative provision converter | [138967](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138967#school-location) | Common 11-field set |
| `43` | Academy alternative provision sponsor led | [137496](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/137496#school-location) | Common 11-field set |
| `44` | Academy special converter | [137286](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/137286#school-location) | Common 11-field set |
| `45` | Academy 16-19 converter | [138966](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138966#school-location) | Common 11-field set |
| `46` | Academy 16 to 19 sponsor led | [141491](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/141491#school-location) | Common 11-field set |
| `47` | Children's centre | [20001](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/20001#school-location) | Common 11-field set |
| `48` | Children's centre linked site | [20018](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/20018#school-location) | Common 11-field set |
| `49` | Online provider | [149905](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/149905#school-location) | Common 11-field set |
| `56` | Institution funded by other government department | [130784](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/130784#school-location) | Common 11-field set |
| `57` | Academy secure 16 to 19 | [150154](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/150154#school-location) | Common 11-field set |

## Observations

- The Location tab is highly consistent across sampled establishment types.
- 40 of the 41 sampled types displayed the common 11 location fields.
- The sampled `Other independent school` also displayed an `Other sites` section with two additional `Address` rows. This appears to be related to the sampled establishment having additional sites, not necessarily to every establishment of that type.
- The sampled `British schools overseas` page displayed no Location tab summary-list fields.
- The common field set aligns closely with the geography and administrative reference-data areas documented in `docs/data/erd/metadata/geography-and-administrative-classifications.md`.

## Follow-Up Questions

| Question | Why It Matters |
| --- | --- |
| Are `Other sites` address rows controlled by establishment type, or by whether an establishment has additional sites? | The sample suggests an instance-specific display rule rather than a type-level field rule. |
| Should British schools overseas suppress location fields by design? | The sampled page showed no location fields, but this should be validated against the application code or more samples. |
| Are Welsh, offshore and service children's education location values semantically comparable with English administrative geographies? | These types can display the same field labels, but values may represent pseudo or non-standard geography classifications. |

## Interpretation

Location behaves differently from the Details tab.

The Details tab varies strongly by establishment type. The Location tab is mostly common, with specific exceptions for overseas or record-specific site behaviour.

This suggests that location can be modelled as a common establishment capability, with exception handling for special cases.

## Design Implications

| Implication | What this means |
| --- | --- |
| Location is common establishment data. | Location should sit close to the establishment record rather than as an unrelated service. |
| Some location values are administrative classifications. | The model needs reference data for geography, local authority, ward, constituency, LSOA, MSOA and related classifications. |
| Other sites may be record-specific. | Additional-site data should not be assumed to apply to all establishments of a type. |
| Overseas and non-standard establishments need validation. | British overseas, Welsh, offshore and service children's education cases may need special semantic handling. |
