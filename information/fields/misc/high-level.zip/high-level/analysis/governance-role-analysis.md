# Governance Role Analysis

## Source

This analysis uses the governor and governance extracts in `docs/data/extract-data/governors`:

- `governancealldata20260623.csv`
- `governanceladata20260623.csv`
- `governanceacaddata20260623.csv`
- `governancematdata20260623.csv`

The extracts contain 270,736 governance rows in total. The split extracts partition the all-governance extract exactly by `GID`:

| Extract | Rows | Scope inferred from identifiers and roles |
| --- | ---: | --- |
| `governancealldata20260623.csv` | 270,736 | Combined LA, academy/free-school and MAT governance rows. |
| `governanceladata20260623.csv` | 117,975 | Local-authority maintained school and federation governance rows. |
| `governanceacaddata20260623.csv` | 124,069 | Academy/free-school establishment-level governance rows. |
| `governancematdata20260623.csv` | 28,692 | Multi-academy trust and group-level governance rows. |

No personal names are reproduced in this analysis. The extracts contain title, forename and surname fields, so this document uses aggregate counts only.

## Methodology

Validation was carried out on 23 June 2026.

The analysis was produced by:

1. Parsing all four CSV files.
2. Grouping rows by `Role`.
3. Counting role rows by extract.
4. Checking whether the split extracts are a complete, non-overlapping partition of `governancealldata20260623.csv` by `GID`.
5. Counting identifier population by extract.
6. Counting appointing-body values in the all-governance extract.

Important limitations:

- This is extract evidence, not a direct export of the underlying `StaffRecord`, `StaffRole`, `StaffType`, staff-field metadata or public governance pages.
- The analysis does not inspect or reproduce individual governor names.
- A row with no `Date term of office ends/ended` is treated as having no term-end value in the extract. That is useful evidence, but it should not be treated as a confirmed current appointment without business-rule validation.
- Counts reflect the supplied dated extracts, not a live database query.

## Extract Partition Check

| Check | Result |
| --- | ---: |
| Unique `GID` values in all-governance extract | 270,736 |
| Unique `GID` values across LA, academy and MAT split extracts | 270,736 |
| Total rows across split extracts | 270,736 |
| Rows in all-governance extract | 270,736 |
| `GID` values in all-governance but not in split extracts | 0 |
| `GID` values in split extracts but not in all-governance | 0 |
| `GID` overlap between LA and academy extracts | 0 |
| `GID` overlap between LA and MAT extracts | 0 |
| `GID` overlap between academy and MAT extracts | 0 |

This supports treating `governancealldata20260623.csv` as the union of the three scoped governance extracts.

## Role Counts By Extract

| Role | All rows | LA rows | Academy rows | MAT rows |
| --- | ---: | ---: | ---: | ---: |
| Governor | 104,691 | 104,691 | 0 | 0 |
| Local Governor | 88,315 | 0 | 88,315 | 0 |
| Trustee | 23,627 | 0 | 10,692 | 12,935 |
| Chair of Local Governing Body | 12,262 | 0 | 12,262 | 0 |
| Chair of Governors | 12,185 | 12,185 | 0 | 0 |
| Member | 11,589 | 0 | 3,995 | 7,594 |
| Shared Local Governor - Establishment | 3,255 | 0 | 3,255 | 0 |
| Chief Financial Officer | 2,934 | 0 | 988 | 1,946 |
| Chair of Trustees | 2,924 | 0 | 1,117 | 1,807 |
| Accounting Officer | 2,835 | 0 | 933 | 1,902 |
| Local Governance Professional - Individual Academy or Free School | 1,837 | 0 | 1,837 | 0 |
| Shared Local Governor - Group | 1,678 | 0 | 0 | 1,678 |
| Governance Professional - Local Authority Maintained School | 923 | 923 | 0 | 0 |
| Governance Professional - Multi-Academy Trust (MAT) | 571 | 0 | 0 | 571 |
| Shared Chair of Local Governing Body - Establishment | 312 | 0 | 312 | 0 |
| Governance Professional - Single-Academy Trust (SAT) | 226 | 0 | 226 | 0 |
| Shared Chair of Local Governing Body - Group | 208 | 0 | 0 | 208 |
| Governance Professional - Federation | 176 | 176 | 0 | 0 |
| Shared Governance Professional - Establishment | 137 | 0 | 137 | 0 |
| Shared Governance Professional - Group | 51 | 0 | 0 | 51 |

## Identifier Pattern By Extract

| Extract | Rows | URN populated | UID populated | Companies House number populated |
| --- | ---: | ---: | ---: | ---: |
| All governance | 270,736 | 242,044 | 28,692 | 28,548 |
| LA governance | 117,975 | 117,975 | 0 | 0 |
| Academy governance | 124,069 | 124,069 | 0 | 0 |
| MAT governance | 28,692 | 0 | 28,692 | 28,548 |

The identifier pattern is clear:

- LA and academy governance rows are establishment-scoped through `URN`.
- MAT governance rows are group-scoped through `UID`.
- Companies House number is almost entirely a MAT/group-level identifier in this extract.
- The all-governance extract combines establishment-scoped and group-scoped governance records.

## Appointing Body Counts

| Appointing body | Count |
| --- | ---: |
| Appointed by GB/board | 93,760 |
| Appointed by foundation/Trust | 39,757 |
| Elected by parents | 35,183 |
| Elected by school staff | 20,975 |
| Ex-officio by virtue of office as headteacher/principal | 18,354 |
| Appointed by academy members | 16,972 |
| N/A | 10,008 |
| Parent appointed by GB/board due to no election candidates | 6,368 |
| Foundation/sponsor members | 6,253 |
| Nominated by LA and appointed by GB | 4,787 |
| Ex-officio foundation governor (appointed by foundation by virtue of the office they hold) | 4,036 |
| Appointed by trustees | 4,015 |
| Appointed by LA | 3,578 |
| Persons who are appointed by the foundation body or sponsor (if applicable) | 2,287 |
| Original (signatory) members | 1,815 |
| Nominated by other body and appointed by GB | 1,567 |
| Any additional members appointed by the members of the academy trust | 598 |
| Interim Executive Board | 419 |
| Appointed by Regional Schools Commissioner (RSC) | 4 |

## Observations

- `Governor` is the dominant LA-maintained-school role, with 104,691 rows.
- `Local Governor` is the dominant academy establishment-level role, with 88,315 rows.
- `Trustee`, `Member`, `Chief Financial Officer`, `Chair of Trustees` and `Accounting Officer` appear in both academy and MAT extracts. This suggests the academy extract includes some trust-related roles for individual academy/free-school records, while the MAT extract represents group-level governance.
- Shared governance is explicitly represented through separate role labels, split between establishment-level and group-level roles.
- Governance professional roles are separated by context: local-authority maintained school, federation, individual academy/free school, SAT and MAT.
- The extracts mix establishment-scoped governance and group-scoped governance. Future modelling should not force all governance records to attach only to establishments.
- `Original signatory member` and `Original chair of trustees` are present as columns but are empty in all four extracts. The related business meaning appears to be represented through `Appointing body` values such as `Original (signatory) members`.

## Modelling Implications

- Governance should be modelled as a person-role relationship against either an establishment or a group/trust, depending on the governance context.
- `URN` and `UID` must both be supported as governance subject identifiers.
- Role labels carry important context and should not be collapsed into a single generic governor role without preserving the role type.
- Shared governance needs explicit modelling because the extract distinguishes shared roles at establishment level and group level.
- The model needs to support appointment dates, term-end dates and appointing-body classifications.
- Personal-name fields make this a privacy-sensitive domain. Any future extract, test data or modelling example should avoid reproducing row-level personal data unless there is a clear and approved reason.

## Design Implications

| Implication | What this means |
| --- | --- |
| Governance is a candidate bounded context. | It has its own people, roles, appointments, appointing bodies and identifiers. |
| Governance subject can be establishment or group. | The model must support both URN-scoped and UID-scoped governance. |
| Role type is business-significant. | Trustee, member, governor and local governor should not be collapsed into one generic role. |
| Shared governance needs explicit representation. | The extract distinguishes shared establishment roles from shared group roles. |
| Governance is privacy-sensitive. | Personal data should be protected, audited and omitted from public analysis unless there is an approved reason. |
