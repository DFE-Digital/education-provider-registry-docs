# Establishment Type Population Analysis

## Purpose

We analysed the current establishment extracts to understand the real population of establishment types that the new registry model must support.

This analysis helps us avoid designing from a theoretical list only. We need to know which establishment types are actually present, which are defined but unused, and which types need representative examples when we test fields, governance, location and relationship behaviour.

## What We Analysed

This analysis uses `edubasealldata20260616.csv`, `edubaseallchildrencentre20260616.csv` and the `EstablishmentType` rows in the database.

The main all-data extract contains 52,397 establishment rows. The separate children's centre extract contains 2,846 rows. Combined, these extracts cover 55,243 establishment rows. Counts are grouped by `TypeOfEstablishment (code)` and `TypeOfEstablishment (name)`. Sample rows use the lowest `URN` found for each establishment type in the relevant extract.

| Measure | Result |
| --- | ---: |
| Main establishment rows | 52,397 |
| Children's centre rows | 2,846 |
| Combined establishment rows | 55,243 |
| Establishment types defined in the reference model | 46 |
| Establishment types observed in the combined extracts | 41 |
| Defined types with no rows in the extracts | 5 |

## What We Found

The combined extracts contain a broad and active establishment population. The most common type is Community school, followed by Academy converter.

## Establishment Counts By Type

| Type code | Establishment type | ERD group code | Archived in ERD | Count in extract |
| --- | --- | --- | --- | ---: |
| `01` | Community school | `4` | No | 16,430 |
| `02` | Voluntary aided school | `4` | No | 5,140 |
| `03` | Voluntary controlled school | `4` | No | 3,131 |
| `05` | Foundation school | `4` | No | 2,183 |
| `06` | City technology college | `3` | No | 15 |
| `07` | Community special school | `5` | No | 1,603 |
| `08` | Non-maintained special school | `5` | No | 94 |
| `09` | Independent school approved for SEN pupils | `5` | Yes | 0 |
| `10` | Other independent special school | `5` | No | 1,461 |
| `11` | Other independent school | `3` | No | 3,843 |
| `12` | Foundation special school | `5` | No | 129 |
| `14` | Pupil referral unit | `4` | No | 869 |
| `15` | Local authority nursery school | `4` | No | 619 |
| `17` | European schools | `9` | Yes | 0 |
| `18` | Further education | `1` | No | 489 |
| `22` | Early years setting | `9` | Yes | 0 |
| `23` | Playing for success centres | `9` | Yes | 0 |
| `24` | Secure units | `9` | No | 48 |
| `25` | Offshore schools | `9` | No | 157 |
| `26` | Service children's education | `9` | No | 83 |
| `27` | Miscellaneous | `9` | No | 230 |
| `28` | Academy sponsor led | `10` | No | 2,923 |
| `29` | Higher education institutions | `2` | No | 138 |
| `30` | Welsh establishment | `6` | No | 2,488 |
| `31` | Sixth form centres | `1` | No | 61 |
| `32` | Special post 16 institution | `9` | No | 167 |
| `33` | Academy special sponsor led | `10` | No | 112 |
| `34` | Academy converter | `10` | No | 8,152 |
| `35` | Free schools | `11` | No | 586 |
| `36` | Free schools special | `11` | No | 139 |
| `37` | British schools overseas | `9` | No | 315 |
| `38` | Free schools alternative provision | `11` | No | 61 |
| `39` | Free schools 16 to 19 | `11` | No | 39 |
| `40` | University technical college | `11` | No | 67 |
| `41` | Studio schools | `11` | No | 48 |
| `42` | Academy alternative provision converter | `10` | No | 109 |
| `43` | Academy alternative provision sponsor led | `10` | No | 47 |
| `44` | Academy special converter | `10` | No | 359 |
| `45` | Academy 16-19 converter | `10` | No | 42 |
| `46` | Academy 16 to 19 sponsor led | `10` | No | 2 |
| `47` | Children's centre | `12` | No | 2,166 |
| `48` | Children's centre linked site | `12` | No | 680 |
| `49` | Online provider | `13` | No | 16 |
| `56` | Institution funded by other government department | `9` | No | 1 |
| `57` | Academy secure 16 to 19 | `10` | No | 1 |
| `98` | Legacy types | `9` | Yes | 0 |

## Sample Establishment Per Type

| Type code | Establishment type | URN | LA code | Establishment number | UKPRN | Establishment name | Status | Town | Postcode |
| --- | --- | ---: | --- | ---: | ---: | --- | --- | --- | --- |
| `01` | Community school | 100008 | `202` | 2019 | 10078065 | Argyle Primary School | Open | London | WC1H 9EG |
| `02` | Voluntary aided school | 100000 | `201` | 3614 | 10079319 | The Aldgate School | Open | London | EC3A 5DE |
| `03` | Voluntary controlled school | 100192 | `203` | 4508 | 10006718 | The John Roan School | Closed | London | SE3 7QR |
| `05` | Foundation school | 100188 | `203` | 4257 | 10015721 | The Eltham Foundation School | Closed | London | SE9 5EQ |
| `06` | City technology college | 100759 | `209` | 6900 |  | Haberdashers' Aske's Hatcham College | Closed | London | SE14 5SF |
| `07` | Community special school | 100091 | `202` | 7008 | 10077052 | Frank Barnes School for Deaf Children | Open | London | N1C 4BT |
| `08` | Non-maintained special school | 101696 | `305` | 7003 |  | Coney Hill School | Closed | Bromley | BR2 7JZ |
| `09` | Independent school approved for SEN pupils |  |  |  |  | No sample in extract |  |  |  |
| `10` | Other independent special school | 101077 | `212` | 6368 | 10018542 | The Dominie School Limited | Closed | London | SW11 4DX |
| `11` | Other independent school | 100001 | `201` | 6005 | 10013279 | City of London School for Girls | Open | London | EC2Y 8BB |
| `12` | Foundation special school | 100060 | `202` | 5950 | 10015430 | Children's Hospital School at Gt Ormond Street and UCH | Open | London | WC1N 3JH |
| `14` | Pupil referral unit | 100006 | `202` | 1100 | 10016665 | Heath School | Open | London | NW3 2NY |
| `15` | Local authority nursery school | 100004 | `202` | 1045 |  | Sherborne Nursery School | Closed | London | NW5 4LP |
| `17` | European schools |  |  |  |  | No sample in extract |  |  |  |
| `18` | Further education | 127066 | `330` | 8603 |  | St Philip's RC Sixth Form College | Closed | Birmingham | B16 8UF |
| `22` | Early years setting |  |  |  |  | No sample in extract |  |  |  |
| `23` | Playing for success centres |  |  |  |  | No sample in extract |  |  |  |
| `24` | Secure units | 128604 | `355` | 0611 | 10045140 | Barton Moss Education Centre | Open | Swinton | M27 5AW |
| `25` | Offshore schools | 132351 | `708` | 6001 |  | Bayside School | Open | Gibraltar |  |
| `26` | Service children's education | 132269 | `702` | 2008 |  | Bielefeld Primary School | Closed | Bielefeld |  |
| `27` | Miscellaneous | 104755 | `341` | 7750 |  | Acorn Nursery School | Closed | Liverpool | L11 8LW |
| `28` | Academy sponsor led | 101857 | `341` | 6905 | 10017852 | The Academy of St Francis of Assisi | Closed | Liverpool | L6 7UR |
| `29` | Higher education institutions | 130545 | `383` | 8011 | 10034449 | Leeds College of Music | Open | Leeds | LS2 7PD |
| `30` | Welsh establishment | 400000 | `664` | 1003 |  | The Croft Nursery School | Closed | Flintshire | CH5 1NF |
| `31` | Sixth form centres | 132838 | `202` | 4952 | 10029079 | LaSWAP Sixth Form | Open | London | NW5 1RN |
| `32` | Special post 16 institution | 121777 | `815` | 8223 | 10012814 | Henshaws College | Open | Harrogate | HG1 4ED |
| `33` | Academy special sponsor led | 138253 | `826` | 7043 | 10037667 | Stephenson Academy | Open | Milton Keynes | MK14 6AX |
| `34` | Academy converter | 136266 | `874` | 5417 | 10031362 | Arthur Mellows Village College | Open | Peterborough | PE6 7JX |
| `35` | Free schools | 136750 | `205` | 4000 | 10035246 | West London Free School | Open | London | W6 9LP |
| `36` | Free schools special | 138271 | `874` | 7000 | 10038722 | Medeshamstede Academy | Open | Peterborough | PE1 5LQ |
| `37` | British schools overseas | 130892 | `000` | 6503 |  | Dubai British School | Open | Dubai |  |
| `38` | Free schools alternative provision | 138262 | `211` | 1101 | 10037669 | South Quay College | Closed | London | E14 9UB |
| `39` | Free schools 16 to 19 | 138403 | `316` | 4000 | 10037983 | London Academy of Excellence | Open | London | E15 1AJ |
| `40` | University technical college | 136933 | `335` | 4000 | 10034943 | Black Country UTC | Closed | Walsall | WS3 2PA |
| `41` | Studio schools | 137317 | `855` | 4004 | 10035290 | Stephenson Studio School | Closed | Coalville | LE67 3TN |
| `42` | Academy alternative provision converter | 138967 | `941` | 1100 | 10039422 | The CE Academy | Closed | Northampton | NN1 3EX |
| `43` | Academy alternative provision sponsor led | 137496 | `352` | 4000 | 10035295 | Manchester Alternative Provision Academy | Closed | Manchester | M9 8AE |
| `44` | Academy special converter | 137286 | `839` | 5951 | 10035068 | Montacute School | Open | Poole | BH17 9NG |
| `45` | Academy 16-19 converter | 138966 | `203` | 4717 | 10039420 | Shooters Hill Sixth Form College | Open | London | SE18 4LD |
| `46` | Academy 16 to 19 sponsor led | 141491 | `860` | 4011 | 10044606 | Landau Forte Academy Tamworth Sixth Form | Open | Tamworth | B79 8AA |
| `47` | Children's centre | 20001 | `873` |  |  | The Starship Children's Centre | Open | Bar Hill | CB23 8DY |
| `48` | Children's centre linked site | 20018 | `315` |  |  | Abbey Children's Centre | Open | Merton | SW19 2JY |
| `49` | Online provider | 149905 | `000` | 1000 | 10087150 | Sophia High School | Open | London | SW11 8BZ |
| `56` | Institution funded by other government department | 130784 | `855` | 8301 | 10010497 | Welbeck, the Defence Sixth Form College | Closed | Loughborough | LE12 8WD |
| `57` | Academy secure 16 to 19 | 150154 | `887` | 4007 | 10094342 | Oasis Restore | Open | London | SE1 7QP |
| `98` | Legacy types |  |  |  |  | No sample in extract |  |  |  |

Five defined establishment types were not observed in the supplied extracts:

| Type code | Establishment type |
| --- | --- |
| `09` | Independent school approved for SEN pupils |
| `17` | European schools |
| `22` | Early years setting |
| `23` | Playing for success centres |
| `98` | Legacy types |

## Observations

- The most common type in the combined extracts is `01` Community school, with 16,430 rows.
- Academy converter, code `34`, is the second largest type with 8,152 rows.
- The main all-data extract includes 39 of the 46 establishment types held in the database.
- The combined all-data and children's centre extracts include 41 of the 46 establishment types documented in the ERD.
- Five Establishment types have no rows in either `edubasealldata20260616.csv` or `edubaseallchildrencentre20260616.csv`: `09`, `17`, `22`, `23` and `98`.
- Children's centre types `47` and `48` are absent from the all-data extract, but are present in `edubaseallchildrencentre20260616.csv`.

## Interpretation

We should treat the 41 observed establishment types as the practical baseline for current modelling and public-page validation.

The five unobserved types still matter because they are part of the defined reference model, but we should not let them drive the first version of the design unless there is a clear business reason.

Children's centres need explicit treatment because they are not present in the main establishment extract but are present in the children's centre extract.

## Design Implications

| Implication | What this means |
| --- | --- |
| Establishment type is a first-class classification. | Field behaviour, governance behaviour, links and display rules depend on establishment type. |
| Observed types and defined types are not the same thing. | We should distinguish active population evidence from reference-data completeness. |
| Children's centres are in scope but have a different extract route. | The model must not assume all establishment types arrive through one homogeneous extract. |
| Samples are valuable but not exhaustive. | One sample per type is good enough for evidence gathering, but not enough to prove every type-wide rule. |
