# Outbound Notification Code Analysis

## Purpose

We need a publishable view of what the legacy Java backend actually does for outbound email notifications.

This note focuses on the source resources listed below. We are using them as implementation evidence for the wider DDD work around Outbound Communication / Notifications, reminders and data-freshness policy.

This is not a target design. It is a code-led analysis of the current-state behaviours we should carry into later design decisions.

## Resources Reviewed

| Resource | Why We Reviewed It |
| --- | --- |
| `gias-dd-backend/src/main/resources/applicationContext-email-notify.xml` | Shows how GOV.UK Notify clients, the central sender and Notify template IDs are wired. |
| `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSender.java` | Defines the notification operations exposed to the rest of the Java backend. |
| `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSenderImpl.java` | Implements template selection, personalisation and GOV.UK Notify email delivery. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/ChangeRequestMailManager.java` | Coordinates change-request and data-owner workflow email behaviour. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/notification/DataOwnerNotificationManagerImpl.java` | Groups applied override change requests by data owner and sends data-owner notifications. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/tasks/ReminderManagerImpl.java` | Sends general reminder notifications for incomplete reminder instances. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/SixtyDayNotUpdatedReminder.java` | Records the last 60-day data-freshness reminder sent for an establishment and addressee type. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/SixtyDayNotUpdatedReminderFlag.java` | Stores whether the 60-day data-freshness reminder is enabled. |
| `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` | Shows the reviewed environment's notification switch, Notify client mode, helpdesk addresses and relevant schedules. |

## What We Have Found

We have clear evidence that the legacy Java backend has a central GOV.UK Notify delivery adapter, but the notification capability is broader than email transmission.

The reviewed code shows that the legacy service also owns:

- Notification intent, expressed as many named send methods and Notify template keys.
- Recipient resolution, including users, data owners, establishment contacts, helpdesk addresses and operational distribution lists.
- Workflow-triggered notifications, especially for change requests and data owners.
- Reminder-triggered notifications, including a general reminder model.
- Data-freshness policy, especially the 60-day not-updated establishment reminder.
- Suppression and fallback behaviour, particularly the 8-day repeat suppression and helpdesk fallback in the 60-day reminder flow.

For target design, we should treat GOV.UK Notify as a delivery service. We should not treat it as the owner of the EPR notification model.

## What The Notify Configuration Shows

`applicationContext-email-notify.xml` wires a central `notificationSender` bean backed by a `NotificationClientFactoryBean`.

The factory is configured with three GOV.UK Notify client options:

- Production.
- Whitelist.
- Test.

The active client is selected using the `notify.mail.sender` property. In the reviewed `dev-azure-backend-server.properties`, this is set to `mailSenderWhiteList`.

The same properties file also sets:

- `notify.enabled=true`.
- `notify.test.emails=true`.
- `notify.whitelist.email=dfedataoperations.platformsupport@education.gov.uk`.
- `notify.helpdesk=EDD.Helpdesk@education.gov.uk`.

This gives us two useful pieces of evidence:

1. The legacy backend can switch between Notify client modes by configuration.
2. The application has an explicit feature switch for whether Notify is used.

The XML file also defines a large `notifyTemplateIds` map. That map is important because it is effectively a catalogue of notification intent. It includes account emails, feedback emails, bulk update emails, content-review emails, reminder emails, federation emails, pending establishment workflow emails, data-owner emails, governance user-request emails, the 60-day reminder emails and scheduled extract failure emails.

## Notification Sender Shape

`NotificationSender.java` exposes a large application-facing interface. The methods are not generic `sendEmail` calls. They are business-named operations such as:

- `sendWelcomeEmail`.
- `sendResetPasswordEmail`.
- `sendScheduleExtractFailure`.
- `sendReminderNotificationEmail`.
- `sendFederationUpdateEmail`.
- `sendNewPendingFreeSchool`.
- `sendApproveOrRejectPendingAcademySponsorLed`.
- `sendDataOwnerNotification`.
- `sendAskDOForAction`.
- `sendRequestApproved`.
- `sendRequestRejected`.
- `sendGovernorUserRequestNotification`.
- `sendSixtyDayNotUpdatedReminderEmail`.
- `sendSixtyDayNotUpdatedReminderSupportEmail`.

That shape matters. The interface is not just a technical wrapper around GOV.UK Notify. It exposes notification types that are meaningful to the GIAS domain and legacy workflows.

`NotificationSenderImpl.java` then maps those operations to Notify template keys, builds personalisation values and calls `notificationClient.sendEmail(...)`.

The implementation also catches `NotificationClientException` and returns `null` from the shared `sendEmailResponse(...)` helper when Notify delivery fails. Several caller methods log the returned Notify notification ID when one is available.

## Capability Groups Evidenced By The Sender

| Capability Group | Evidence In The Sender |
| --- | --- |
| Account and access lifecycle | Welcome, activation, username reminder, password reset, web-service password reset, agreement approval/rejection, user account expiry and agreement expiry warnings. |
| Operational notifications | Exception/server notification emails, sanity check failure emails and scheduled extract failure emails. |
| Feedback handling | General feedback, unknown feedback, Secure Access PIN feedback and establishment-details feedback. |
| Bulk update processing | Bulk update success, failure and error emails. |
| Content review | FAQ review, news story review and automated email template review emails. |
| General reminders | Reminder notification emails. |
| Establishment and group workflow | Federation update, new federation, new IEBT/SOOT establishment, SPI changes, user migration rejection, multiple UAMS accounts and free-school-related notifications. |
| Pending establishment approval | New pending free school, approve/reject pending free school and approve/reject pending academy sponsor-led emails. |
| Data-owner workflow | Data-owner notification, ask data owner for action, delay, reminder to approve/reject, request approved and request rejected emails. |
| Governance access workflow | Governor user request notification and rejection emails. |
| Data freshness | 60-day not-updated reminder to establishment contacts and 60-day support email to helpdesk. |

We should use these groups as evidence of legacy notification capability areas, not as a commitment to rebuild every template or method in the target service.

## Change Request And Data Owner Workflow Notifications

`ChangeRequestMailManager.java` shows that change-request email is part of the data-stewardship workflow.

The manager is configured with:

- A helpdesk staff email property.
- A `notify.enabled` switch.
- The central `NotificationSender`.
- Legacy automated email template support.

The code can send several workflow emails through Notify when `notify.enabled` is true:

- Ask data owner for action.
- Reminder to approve or reject.
- Delay.
- Request rejected.
- Request approved.

Where Notify is not enabled, the code falls back to legacy email-template paths.

The same class also contains fallback behaviour for missing recipient data. The comments show that if a person's mail address is undefined, the message can be sent to helpdesk instead. Where the person has an email address, helpdesk can be used as a copy route.

This gives us evidence that recipient resolution is part of the workflow behaviour. It is not just "send this template to this address".

## Data Owner Notification Behaviour

`DataOwnerNotificationManagerImpl.java` gives us a more specific data-owner notification flow.

It:

- Accepts a collection of change requests.
- Divides those requests by data-owner user group.
- Only includes override change requests that have been applied and meet the ownership criteria in `isOverrideCr(...)`.
- Caps each data-owner email at `MAX_REQUESTS_PER_EMAIL = 300`.
- Formats values and loads establishment details before sending.
- Sorts requests by establishment name.
- Filters requests per user using `changeRequestMailManager.isIncludeOwnerForRequest(...)`.
- Skips sending where a user has no included requests.
- Sends by GOV.UK Notify when `notify.enabled` is true.
- Falls back to the legacy `dataOwnerNotification` MIME template when Notify is not enabled.

This is important DDD evidence because the notification is assembled from workflow state, user-group ownership, establishment data and field/value formatting. The notification capability depends on several domains, but it does not necessarily own those domains.

## General Reminder Notifications

`ReminderManagerImpl.java` shows a separate reminder model.

The manager:

- Loads and saves `Reminder` records.
- Deletes obsolete reminders.
- Counts current-user reminders.
- Finds reminders eligible for email notification.
- Iterates over reminder instances.
- Sends only for incomplete reminder instances.
- Skips users where there is no email address.
- Uses GOV.UK Notify when `notify.enabled` is true.
- Falls back to the older email template path when Notify is not enabled.

The reviewed environment schedules reminder processing with:

`reminders.processing-schedule=0 15 6 * * ?`

We should treat this as evidence that reminders have their own lifecycle. The reminder exists before the email is sent, and an incomplete reminder instance is the reason an email becomes eligible.

## 60-Day Data Freshness Reminder

The 60-day reminder code is the strongest evidence that the legacy system contains a data-freshness notification policy.

`SixtyDayNotUpdatedReminderManagerImpl.java` runs this behaviour:

1. Check whether the 60-day reminder flag is enabled.
2. Find establishments with emails not updated for 60 or more days.
3. Find reminders sent in the previous 8 days.
4. Exclude establishments that have already had a recent reminder.
5. Resolve establishment recipient emails from:
   - Official email.
   - Contact email.
   - SCU alternative email.
   - User emails associated with the establishment.
6. De-duplicate recipient emails.
7. Send the establishment reminder email where at least one recipient email exists.
8. Record or update reminder history with addressee `establishment`.
9. For establishments with no recipient emails, send a support email to the configured helpdesk address.
10. Record or update reminder history with addressee `helpdesk`.

The suppression rule is explicit in the code comments. The system should repeat the reminder only on day 8 after the previous reminder was sent.

The reviewed environment schedules this job as:

`sixty.day.not.updated.reminder = 0 5 19 ? * MON,TUE,WED,THU,FRI *`

That means the reviewed configuration attempts this reminder at 19:05 on weekdays.

## 60-Day Reminder State

`SixtyDayNotUpdatedReminder.java` stores:

- The establishment URN relationship.
- The sending date.
- The addressee type.

The addressee is written as either:

- `establishment`.
- `helpdesk`.

`SixtyDayNotUpdatedReminderFlag.java` stores:

- Whether the reminder is enabled.
- When the flag was updated.
- Who updated it.

This gives us evidence that the 60-day reminder has both operational state and an administrative enable/disable control. It is not just a scheduled email.

## Environment Configuration Evidence

The reviewed `dev-azure-backend-server.properties` file contains several relevant notification settings:

| Setting | Observed Value | Interpretation |
| --- | --- | --- |
| `notify.mail.sender` | `mailSenderWhiteList` | The reviewed environment uses the whitelist Notify client mode. |
| `notify.enabled` | `true` | Notify delivery is enabled in the reviewed environment. |
| `notify.test.emails` | `true` | Test email handling is enabled. |
| `notify.whitelist.email` | `dfedataoperations.platformsupport@education.gov.uk` | Whitelist email target for the reviewed environment. |
| `notify.helpdesk` | `EDD.Helpdesk@education.gov.uk` | Helpdesk fallback for the 60-day reminder support email. |
| `failedExtractsEmailList` | `dfedataoperations.platformsupport@education.gov.uk;gias.helpdesk@education.gov.uk` | Operational recipient list for failed scheduled extracts. |
| `reminders.processing-schedule` | `0 15 6 * * ?` | General reminder processing schedule. |
| `change.request.email-schedule` | `0 0 23 * * ?` | Change request email processing schedule. |
| `sixty.day.not.updated.reminder` | `0 5 19 ? * MON,TUE,WED,THU,FRI *` | 60-day not-updated reminder schedule. |

We should be careful not to treat the `dev-azure` values as production truth. They are still useful evidence for which switches, schedules and recipient settings the application expects.

## What This Means For DDD

This code supports the case for carrying Outbound Communication / Notifications into the DDD process as a candidate capability.

However, we should separate four things that the legacy code currently brings together:

| Concern | What The Legacy Code Shows | Target Design Question |
| --- | --- | --- |
| Notification delivery | GOV.UK Notify client selection, template IDs and `sendEmail(...)` calls. | Can we delegate delivery to GOV.UK Notify without building our own delivery platform? |
| Notification intent | Business-named sender methods and template keys. | Which notification intents are still required for beta and live? |
| Recipient resolution | Data-owner users, establishment emails, user emails, helpdesk fallback and operational email lists. | Which bounded context owns recipient eligibility and fallback rules? |
| Notification state and audit | 60-day reminder history, Notify response logging and workflow email behaviour. | What proof do we need that a notification was generated, sent, skipped, suppressed or failed? |

## Recommended Interpretation

We should not model GOV.UK Notify as a bounded context. It is an external delivery service.

We should model or at least name an EPR responsibility for Outbound Communication / Notifications, because the code shows EPR-specific rules around:

- Why a notification should be sent.
- Which template or notification intent applies.
- Who should receive it.
- Which fallback recipient applies.
- When a notification should be suppressed.
- What state needs to be recorded.

We should also avoid creating a generic Scheduling bounded context from this evidence alone. The schedules in the reviewed properties file tell us when legacy jobs run. They do not own the meaning of reminders, change requests or data-freshness policy.

## Questions To Carry Forward

| Question | Why We Need To Answer It |
| --- | --- |
| Which of the legacy notification intents are required for beta? | The sender interface contains many historical email types, and we should avoid migrating all of them by default. |
| Do we need notification history beyond GOV.UK Notify delivery records? | The 60-day reminder has explicit service-side history and suppression state. Other flows may need similar audit. |
| Who owns recipient resolution for data-owner notifications? | The current flow depends on user groups, change requests, establishment data and data-owner filtering. |
| Should the 60-day data-freshness policy be owned by Establishment Registry or Data Stewardship Workflow? | The trigger is establishment data freshness, but the outcome is a reminder to maintain or verify data. |
| Do we still need helpdesk fallback behaviour? | Both change-request and 60-day reminder flows include helpdesk fallback or copy behaviour. |
| Should general reminders remain in scope? | `ReminderManagerImpl` shows a broader reminder model, not just email delivery. |
| What is the target operational alert route? | Failed extracts and server/sanity-check emails may be better handled through monitoring and incident tooling. |

## Conclusion

We have enough evidence to say that the legacy Java backend has a real outbound notification capability, not just scattered email calls.

GOV.UK Notify is the delivery mechanism for many messages. The GIAS application still owns the business-specific notification intent, recipient resolution, workflow triggers, reminder state and some suppression/fallback rules.

For the transformed service, we should carry this forward as a candidate Outbound Communication / Notifications capability. We can then decide in later DDD stages whether it becomes a supporting bounded context, a thin application service around GOV.UK Notify, or a set of domain-owned notification rules with a shared delivery adapter.
