# Governance Tab Validation

## Purpose

This document validates what the public GIAS establishment governance tab render for the sample establishment types listed in `docs/data/extract-data/establishment-fields/establishment-type-analysis.md`.

It complements:

- `governance-role-analysis.md`, which analyses the governor extract rows.
- `governance-fields-by-role.md`, which analyses extract field population by governance role.

This page-rendering analysis is useful because the public establishment page does not expose the extract exactly as a flat CSV. It presents governance information through establishment-specific tabs, role sections and public field labels.

No personal governor names are reproduced in this document.

## Methodology

Validation was carried out on 23 June 2026.

The analysis used the sample establishment table in `docs/data/extract-data/establishment-fields/establishment-type-analysis.md`. The public page was fetched for each sample using:

`https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/{URN}#school-governance`

The run covered 41 sample establishment types:

- The 39 sample establishment types already present in the establishment-type sample analysis.
- Type `47` Children's centre.
- Type `48` Children's centre linked site.

Types with no sample establishment in the establishment-type analysis were not fetched: `09`, `17`, `22`, `23` and `98`.

For each page, the scraper recorded:

- HTTP status.
- Whether the page exposed a governance tab or governance section.
- Public governance section headings.
- Public table field labels.
- Approximate count of visible governance table rows.
- Notes such as no-data wording.

The scraper did not store or reproduce personal names. The raw evidence file is `governance-live-page-validation-raw.csv`.

Important limitations:

- This is one sample establishment per type, so it validates observed rendering for the sample page, not every establishment of that type.
- Several samples are closed establishments. Closed pages can still expose the legal-duty governance section but no role tables.
- The `#school-governance` fragment identifies the target tab or section in the rendered page; the server response is still the establishment details page HTML.
- The visible row count is a presentation-level count, not an authoritative governance-row count.
- Governance can be establishment-scoped or group-scoped. MAT and group-level governance should also be validated against group pages if the target model needs complete group governance coverage.

## Summary

| Check | Result |
| --- | ---: |
| Sample establishment pages fetched | 41 |
| HTTP 200 responses | 41 |
| Pages with governance section observed | 23 |
| Pages without governance section observed | 18 |
| Open samples with governance section observed | 13 |
| Open samples without governance section observed | 11 |
| Closed samples with governance section observed | 10 |
| Closed samples without governance section observed | 7 |

The public governance table labels observed across populated pages were:

- `Name`
- `Shared with`
- `Governance role identifier (GID)`
- `Date of appointment`
- `Date appointment ended`
- `Appointed by`
- `From`
- `To`
- `GID`

The repeated `GID` label appears because the page uses both table headers and responsive row labels in the HTML. Treat this as a rendered-page observation, not a separate business field.

## Role Section Patterns Observed

| Pattern | Section headings observed | Sample types |
| --- | --- | --- |
| Maintained school local governance | Legal duty to provide governance information; Chair of governors; Governors; Governance professional - local authority maintained school; sometimes Historic | Community school; Voluntary aided school; Community special school; Foundation special school; Pupil referral unit |
| Academy local governing body | Legal duty to provide governance information; Local governance professional - individual academy or free school; Chair of local governing body; Local governors; sometimes Historic | Academy special sponsor led; Academy converter; Free schools; Academy 16 to 19 sponsor led |
| Single-academy trust governance | Legal duty to provide governance information; Governance professional - single-academy trust (SAT); Chair of trustees; Trustees; Members; Accounting officer; Chief financial officer; Historic | Free schools 16 to 19; Academy special converter; Academy 16-19 converter |
| Legal-duty-only public section | Legal duty to provide governance information only | Several closed samples, plus Free schools special in this sample run |
| No establishment governance section | No `school-governance` section observed on the sample establishment page | Independent schools, FE/HE, secure units, offshore schools, service children's education, miscellaneous, Welsh establishment, sixth form centres, special post-16 institution, British schools overseas, children's centres, online provider, institution funded by other government department and academy secure 16 to 19 samples |

## Type-By-Type Results

| Type | Sample URN | Status | Governance section | Public headings observed | Field labels observed | Visible rows | Notes |
| --- | ---: | --- | --- | --- | --- | ---: | --- |
| 01 Community school | 100008 | Open | Yes | Legal duty to provide governance information; Chair of governors; Governors; Governance professional - local authority maintained school | Name; Governance role identifier (GID); Appointed by; From; To | 2 | Contains no-data wording |
| 02 Voluntary aided school | 100000 | Open | Yes | Legal duty to provide governance information; Chair of governors; Governors; Governance professional - local authority maintained school; Historic (left within last 12 months) | Name; Governance role identifier (GID); Appointed by; From; To; GID | 2 |  |
| 03 Voluntary controlled school | 100192 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 05 Foundation school | 100188 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 06 City technology college | 100759 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 07 Community special school | 100091 | Open | Yes | Legal duty to provide governance information; Chair of governors; Governors; Governance professional - local authority maintained school; Historic (left within last 12 months) | Name; Governance role identifier (GID); Appointed by; From; To; GID | 3 | Contains no-data wording |
| 08 Non-maintained special school | 101696 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 10 Other independent special school | 101077 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 11 Other independent school | 100001 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 12 Foundation special school | 100060 | Open | Yes | Legal duty to provide governance information; Chair of governors; Governors; Governance professional - local authority maintained school; Historic (left within last 12 months) | Name; Governance role identifier (GID); Appointed by; From; To; Date of appointment; Date appointment ended; GID | 4 | Contains no-data wording |
| 14 Pupil referral unit | 100006 | Open | Yes | Legal duty to provide governance information; Chair of governors; Governors; Governance professional - local authority maintained school; Historic (left within last 12 months) | Name; Governance role identifier (GID); Appointed by; From; To; GID | 3 |  |
| 15 Local authority nursery school | 100004 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 18 Further education | 127066 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 24 Secure units | 128604 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 25 Offshore schools | 132351 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 26 Service children's education | 132269 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 27 Miscellaneous | 104755 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 28 Academy sponsor led | 101857 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 29 Higher education institutions | 130545 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 30 Welsh establishment | 400000 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 31 Sixth form centres | 132838 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 32 Special post 16 institution | 121777 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 33 Academy special sponsor led | 138253 | Open | Yes | Legal duty to provide governance information; Local governance professional - individual academy or free school; Chair of local governing body; Local governors; Historic (left within last 12 months) | Name; Shared with; Governance role identifier (GID); Appointed by; From; To; GID | 3 | Contains no-data wording |
| 34 Academy converter | 136266 | Open | Yes | Legal duty to provide governance information; Local governance professional - individual academy or free school; Chair of local governing body; Local governors | Name; Shared with; Governance role identifier (GID); Appointed by; From; To | 2 |  |
| 35 Free schools | 136750 | Open | Yes | Legal duty to provide governance information; Local governance professional - individual academy or free school; Chair of local governing body; Local governors; Historic (left within last 12 months) | Name; Shared with; Governance role identifier (GID); Appointed by; From; To; GID | 3 |  |
| 36 Free schools special | 138271 | Open | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 37 British schools overseas | 130892 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 38 Free schools alternative provision | 138262 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 39 Free schools 16 to 19 | 138403 | Open | Yes | Legal duty to provide governance information; Governance professional - single-academy trust (SAT); Chair of trustees; Trustees; Members; Accounting officer; Chief financial officer; Historic (left within last 12 months) | Name; Governance role identifier (GID); Appointed by; From; To; GID | 6 |  |
| 40 University technical college | 136933 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 41 Studio schools | 137317 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 42 Academy alternative provision converter | 138967 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 43 Academy alternative provision sponsor led | 137496 | Closed | Yes | Legal duty to provide governance information | Not observed |  | Contains no-data wording |
| 44 Academy special converter | 137286 | Open | Yes | Legal duty to provide governance information; Governance professional - single-academy trust (SAT); Chair of trustees; Trustees; Members; Accounting officer; Chief financial officer; Historic (left within last 12 months) | Name; Governance role identifier (GID); Appointed by; From; To; GID | 6 |  |
| 45 Academy 16-19 converter | 138966 | Open | Yes | Legal duty to provide governance information; Governance professional - single-academy trust (SAT); Chair of trustees; Trustees; Members; Accounting officer; Chief financial officer; Historic (left within last 12 months) | Name; Governance role identifier (GID); Date of appointment; Date appointment ended; Appointed by; From; To; GID | 7 |  |
| 46 Academy 16 to 19 sponsor led | 141491 | Open | Yes | Legal duty to provide governance information; Local governance professional - individual academy or free school; Chair of local governing body; Local governors; Historic (left within last 12 months) | Name; Shared with; Governance role identifier (GID); Appointed by; From; To; GID | 3 |  |
| 47 Children's centre | 20001 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 48 Children's centre linked site | 20018 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 49 Online provider | 149905 | Open | No | Not observed | Not observed |  | No school-governance div found |
| 56 Institution funded by other government department | 130784 | Closed | No | Not observed | Not observed |  | No school-governance div found |
| 57 Academy secure 16 to 19 | 150154 | Open | No | Not observed | Not observed |  | No school-governance div found |

## Findings

The live establishment pages confirm that public governance rendering is type-sensitive and context-sensitive. The establishment page can show maintained-school governance roles, academy local-governing-body roles, SAT trustee roles, a legal-duty-only section, or no governance section for the sample page.

The public page field labels do not align one-to-one with the extract columns in `governance-fields-by-role.md`. The extracts contain separate person-name fields, establishment or group identifiers, role, appointment date, term-end date, appointing body and original signatory/chair flags. The public page presents these through display labels such as `Name`, `Governance role identifier (GID)`, `Appointed by`, `From` and `To`, and sometimes `Shared with`, `Date of appointment` and `Date appointment ended`.

The public establishment page does not display every extract field. For example, `URN`, `UID` and `Companies House Number` are part of extract scoping evidence but are not displayed as row-level governance fields on these establishment pages. That is expected because the establishment page itself supplies the establishment context, while group-level governance requires separate group evidence.

Children's centre samples were included in this run. Both `47` Children's centre and `48` Children's centre linked site returned HTTP 200 and did not expose a `school-governance` section on the sampled establishment pages.

The academy secure 16 to 19 sample also did not expose a governance section on the sampled establishment page. Because it is academy-like in policy terms but absent from this rendered sample, this should be treated as a follow-up validation point rather than a settled type-wide rule.

## Modelling Implications

The logical model should distinguish:

- Governance roles as data, aligned to extract role evidence.
- Governance presentation applicability, which depends on establishment type, status and whether the governance subject is an establishment or a group.
- Establishment-scoped identifiers such as `URN`.
- Group-scoped identifiers such as `UID` and Companies House number.
- Public display labels, which are not the same thing as extract column names or canonical logical attributes.

This supports modelling governance as a relationship between a person and a governance body, establishment, or group, with role, appointment and term metadata. The public page rendering should be treated as a presentation of that model, not the whole model.

## Recommended Follow-Up

1. Repeat the live-page validation with open samples for types where the current sample is closed, where suitable open samples exist.
2. Validate MAT, SAT and federation group pages so group-scoped governance is covered alongside establishment-scoped governance.
3. Compare public page role-section headings against extract role populations by establishment or group.
4. Confirm whether academy secure 16 to 19 governance is intentionally not displayed on the establishment page or is available through a related group page.

## Design Implications

| Implication | What this means |
| --- | --- |
| Governance data and governance presentation are different concerns. | The logical model should not be derived only from public page labels. |
| Presentation applicability is type-sensitive. | Establishment type and status affect whether governance appears and how it is grouped. |
| Group governance needs separate validation. | MAT, SAT and federation group pages need to be considered alongside establishment pages. |
| Public display needs privacy controls. | Governance names and identifiers require careful access and audit treatment. |
