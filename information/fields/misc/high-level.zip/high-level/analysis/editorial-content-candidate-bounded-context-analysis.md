# Editorial Content Current-State Analysis

## Purpose

This document records raw analysis of editorial content in the current GIAS service. It describes what exists, how it behaves, where it is stored and what remains uncertain.

It does not cover Secure Access announcements, event-triggered communication, message delivery, outbox/retry processing or the announcement investigation. Those are separate operational communication concerns.

It does not apply the domain-driven design process, recommend a bounded context or propose a target architecture.

## Methodology

The analysis was completed on 8 July 2026 using:

- code-traced publication ERDs for news, frontend notification banners, FAQs, documents, content pages and glossary entries
- database table-activity evidence
- current Java and C# implementation evidence recorded in the supporting documents

Database-activity snapshots show observed technical activity during a limited period. They do not, by themselves, prove business use or prove that an inactive capability can be retired. No stakeholder interviews, live journey observation or content-parity comparison was completed.

## Scope

Included:

- news stories and articles
- frontend editorial notification banners and templates
- FAQs
- uploaded documents
- database-managed content pages
- glossary entries

Excluded:

- Secure Access announcements and templates
- provider-event triggers
- external message publication and removal
- delivery attempts, retry state and publication history
- email and other outbound notification channels

## Summary Of Findings

- News, FAQs and glossary entries each have distinct legacy and frontend storage shapes.
- Documents and database-managed content pages have legacy implementations with no evidenced frontend equivalent.
- Frontend notification banners are runtime-managed editorial content presented inside the service.
- Some legacy content tables have little or no activity in the reviewed window, but this is not sufficient evidence for retirement.
- Source-of-truth questions remain for news, FAQs and glossary content.
- Audience concepts differ between news, documents, FAQs and banners; a shared word such as `group` does not prove shared semantics.

## Capability Inventory

| Capability | Legacy implementation | Frontend implementation | Current interpretation |
|---|---|---|---|
| News | `NewsStory`, `NewsStory_UserGroup` | `FrontEnd.NewsArticles` | Separate content models exist. The frontend model is used by current C# administration; continued use of legacy news is unconfirmed. |
| Notification banners | None equivalent evidenced | `FrontEnd.NotificationTemplates`, `FrontEnd.NotificationBanners` | Runtime-managed editorial content rendered within the frontend. |
| FAQs | `FAQ`, `FAQSubject`, `FAQGroup`, `FAQ_FAQGroup` | `FrontEnd.FaqGroups`, `FrontEnd.FaqItems` | A legacy governed workflow and simpler frontend publishing model coexist in the estate. |
| Documents | `Document`, `DocumentationSection`, `Document_UserGroup` | None evidenced | Legacy secure document library with taxonomy, lifecycle and selected-audience rules. Current operational use is unconfirmed. |
| Content pages | `ContentDocument`, `Section` | None evidenced | Legacy database-managed page and ordered-section model. No direct current C# use was found. |
| Glossary | `GlossaryItem` | `FrontEnd.GlossaryItems` | Separate SQL and frontend table-storage shapes exist with no physical relationship. Authority is unresolved. |

## News

### Legacy model

`NewsStory` stores title, content, effective and expiry dates, approval/publication state, creator and sign-off users. `NewsStory_UserGroup` records selected audiences.

This is a workflow-bearing editorial model rather than a simple article store.

### Frontend model

`FrontEnd.NewsArticles` is used by the C# frontend for public display, admin preview, creation, editing, deletion and audit views. It uses a frontend/table-storage-style key and application audit fields. It is structurally separate from `NewsStory`.

### Unresolved points

- Whether legacy news remains visible in a live journey.
- Whether content is duplicated between stores.
- Which store is authoritative.
- Whether legacy approval and audience rules remain required.

## Frontend Notification Banners

The C# frontend uses `FrontEnd.NotificationTemplates` and `FrontEnd.NotificationBanners` for reusable banner content and runtime-managed items rendered by the shared frontend banner component. Application-level audit and version fields are present.

These banners are treated here as editorial content because they are authored and presented inside the service. This analysis does not infer outbound delivery, provider-event processing or per-recipient delivery history from them.

### Unresolved points

- Who can create, approve and remove banners.
- Whether banners are public, authenticated, role-targeted or globally displayed in each journey.
- Whether templates are actively reused.
- Required expiry, audit and incident-handling behaviour.

## FAQs

The legacy Java FAQ model contains question and answer content, subject classification, group relationships, creator and sign-off users, and publication state. `FAQ_FAQGroup` links FAQs to legacy groups.

`FrontEnd.FaqGroups` and `FrontEnd.FaqItems` provide a simpler display-group and item structure used by C# administration. The frontend model does not evidence the same sign-off workflow.

The legacy family is marked as a candidate assumed no longer used in the supporting usage analysis. This supports further investigation but does not prove retirement is safe.

### Unresolved points

- Whether a legacy FAQ route remains visible.
- Whether legacy and frontend content match.
- Whether sign-off, subjects or audience-specific FAQs remain required.
- Whether `group` has the same meaning in both models.

## Documents

The legacy document library uses `Document` for file metadata and publication state, `DocumentationSection` for taxonomy, and `Document_UserGroup` for selected audiences. It includes file pointers, categorisation, access mode, effective dates and archival or expiry behaviour.

No direct C# use of these SQL tables was found. Usage evidence recorded a read before the no-observed-activity period, so the library cannot be described as definitively unused.

### Unresolved points

- Whether users can still reach or administer the library.
- Where files are stored and whether pointers remain valid.
- Whether documents contain sensitive or audience-restricted material.
- Retention, accessibility, archival and external-link requirements.

## Content Pages

`ContentDocument` and `Section` represent database-managed content composed of ordered text sections. No direct C# use was found. Java/controller imports exist, but reviewed evidence did not establish an active end-to-end journey.

### Unresolved points

- Which routes still render this content.
- Whether it is duplicated in source-controlled pages or another store.
- Whether ordering, versioning or runtime editing remains required.
- Whether records must be retained or archived.

## Glossary

There are two separate storage patterns: legacy SQL `dbo.GlossaryItem` and frontend/table-storage-style `FrontEnd.GlossaryItems`.

The C# frontend includes create, edit and delete behaviour against the frontend shape. Java has a SQL entity. No physical relationship links the stores. June 2026 evidence includes SQL reads, while current C# code points to the frontend store.

### Unresolved points

- Whether both stores contain the same entries and text.
- Which journeys read each store.
- Which store receives current edits.
- Who owns terminology quality and approval.
- Whether deleted or historic terms must be retained.

## Cross-Capability Analysis

### Authoring and approval

Legacy models commonly contain creator, sign-off, approval or publication fields. Frontend models are generally simpler and use application audit fields. The evidence does not establish whether this reflects changed business processes or only different implementations.

### Audience and grouping

Audience concepts are not uniform:

- news uses user-group relationships
- documents use selected user groups and access modes
- legacy FAQ groups combine grouping and audience behaviour
- frontend FAQ groups are primarily display groupings
- frontend banners have their own presentation rules

These values must be analysed separately rather than normalised by name alone.

### Audit and history

The estate contains creator/sign-off references, Envers-style Java audit tables and application audit/version fields in frontend entities. Their completeness and retention have not been compared.

### Storage

Editorial content spans relational SQL tables, bridge tables, frontend/Azure Table Storage-style entities and file pointers. There is no single current storage pattern representing all editorial content.

## Assumption And Evidence Register

| ID | Current assumption | Confidence | Evidence needed |
|---|---|---:|---|
| ASIS-01 | Frontend news is the primary current news implementation. | Medium | Live journey, write-path evidence and owner confirmation. |
| ASIS-02 | Legacy news may be historical or superseded. | Low | Route tracing, content comparison and usage evidence. |
| ASIS-03 | Frontend banners are managed editorial content. | High | Confirm author, approval, targeting and display rules. |
| ASIS-04 | Frontend FAQs are the current public FAQ implementation. | Medium | Live public/admin journey and content parity check. |
| ASIS-05 | Legacy documents and content pages have low current use. | Medium | Longer activity window, route tracing and owner interviews. |
| ASIS-06 | The frontend glossary receives current edits. | Medium | Observe write paths and compare last-modified data in both stores. |
| ASIS-07 | Group identifiers have different semantics across content families. | High | Map each code set and resolving table/service. |

## Required Follow-Up Analysis

- Build a record-level inventory for every editorial store.
- Trace read and write paths from routes/controllers to persistence.
- Observe admin and end-user journeys.
- Compare duplicate-looking stores for parity and last-modified history.
- Extend activity evidence for uncertain legacy tables.
- Identify business, editorial and technical owners.
- Map every editorial audience/group identifier to its source and meaning.
- Locate uploaded document binaries and test pointer integrity.
- Record retention, privacy, accessibility and archival requirements.

## Supporting Evidence

- `docs/data/erd/publication/news-announcements-and-notifications.md` — use only its news and frontend banner sections
- `docs/data/erd/publication/faqs-and-feedback.md` — use only its FAQ sections
- `docs/data/erd/publication/documents-and-content.md`
- `docs/data/erd/permissions/announcements-news-visibility.md` — use only its news-visibility evidence

## Current-State Conclusion

The as-is estate contains several editorial capabilities with different storage models, workflows, audiences and evidence of use. Some appear duplicated and some appear legacy-only. The main evidence gaps are ownership, live journeys, content authority, store parity and the business need for low-activity legacy capabilities.
