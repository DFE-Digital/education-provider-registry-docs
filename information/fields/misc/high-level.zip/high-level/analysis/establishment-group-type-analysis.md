﻿# Establishment Group Type Analysis

## Source

This analysis uses:

- `docs/data/extract-data/groups/allgroupsdata20260622.csv`
- `docs/data/extract-data/groups/grouplinks_edubaseallacademiesandfree20260622.csv`
- The `EstablishmentGroupType` definitions documented in `docs/data/erd/core/groups-trusts-federations-local-authority-erd.md`

The all-groups extract contains 7,172 group rows. The academy/free-school group-link extract contains 21,189 establishment-to-group link rows. We use the academy/free-school link extract as scoped evidence for academy trust, single-academy trust and sponsor relationships, not as a complete view of all establishment-to-group relationships.

The all-groups extract uses 9 group types out of the 11 group types defined in the ERD evidence. The academy/free-school group-link extract uses 3 group types: school sponsor, multi-academy trust and single-academy trust. It does not cover federation, children's-centre group or children's-centre collaboration links.

## Methodology

Validation was carried out on 22 June 2026.

The group count analysis was produced by grouping `allgroupsdata20260622.csv` by `Group Type (code)` and `Group Type`. Sample rows use the lowest numeric `Group UID` found for each group type in the extract.

The link count analysis was produced by grouping `grouplinks_edubaseallacademiesandfree20260622.csv` by `Group Type (code)`, `Group Type`, `TypeOfEstablishment (code)` and `TypeOfEstablishment (name)`.

Important limitations:

- The group-link extract is scoped to academies and free schools. It should not be read as a full population of all group memberships.
- The group-link extract does not include federation, children's-centre group or children's-centre collaboration links.
- Group names are organisation names and are retained as evidence. Person-name fields are not reproduced in samples.
- Counts reflect the supplied dated extracts, not a live database query.

## Group Counts By Type

| Group type code | Group type | Archived in ERD | Count in group extract | Link rows in academies/free extract |
| --- | --- | --- | ---: | ---: |
| `01` | Federation | No | 1,108 | 0 |
| `02` | Trust | No | 475 | 0 |
| `03` | Collegiate | Yes | 0 | 0 |
| `04` | Partnership | Yes | 0 | 0 |
| `05` | School sponsor | No | 1,236 | 9,204 |
| `06` | Multi-academy trust | No | 1,762 | 11,165 |
| `07` | Umbrella trust | Yes | 20 | 0 |
| `08` | Children's Centres Group | No | 579 | 0 |
| `09` | Children's Centres Collaboration | No | 74 | 0 |
| `10` | Single-academy trust | No | 1,917 | 820 |
| `11` | Secure single-academy trust | No | 1 | 0 |

## Sample Group Per Type

| Group type code | Group type | Group UID | Group ID | Group name | Companies House number | Status | Open date | Closed date | UKPRN |
| --- | --- | ---: | --- | --- | --- | --- | --- | --- | --- |
| `01` | Federation | 1000 |  | Federated Governing Body of Egerton Park Arts College and Two Trees Sports College |  | Closed | 06/01/2009 | 31/08/2010 |  |
| `02` | Trust | 1028 |  | The Pioneer Co-Operative Trust | `06893415` | Open | 01/05/2009 |  |  |
| `03` | Collegiate |  |  | No sample in extract |  |  |  |  |  |
| `04` | Partnership |  |  | No sample in extract |  |  |  |  |  |
| `05` | School sponsor | 2043 | `SP01153` | Abbey Multi Academy Trust |  | Open | 20/11/2013 |  |  |
| `06` | Multi-academy trust | 2044 | `TR00261` | ABBEY ACADEMIES TRUST | `07318714` | Open |  |  | `10058308` |
| `07` | Umbrella trust | 2185 | `UT00012` | Askel Veur (Diocese of Truro Academies Umbrella Trust) |  | Open | 01/01/1902 |  |  |
| `08` | Children's Centres Group | 80000 |  | South Warwickshire Group |  | Open | 01/01/1902 |  |  |
| `09` | Children's Centres Collaboration | 85901 |  | The Dean's/Roundabout |  | Open | 01/01/1902 |  |  |
| `10` | Single-academy trust | 1128 | `TR02582` | THE HERMITAGE SCHOOL | `08811135` | Closed |  | 05/10/2021 | `10060695` |
| `11` | Secure single-academy trust | 17690 |  | OASIS RESTORE TRUST | `14489313` | Open | 16/11/2022 |  | `10094332` |

## Group Status Counts

| Group status code | Group status | Count |
| --- | --- | ---: |
| `CLOSED` | Closed | 2,164 |
| `OPEN` | Open | 5,006 |
| `PROPOSED_TO_CLOSE` | Proposed to close | 1 |
| `PROPOSED_TO_OPEN` | Proposed to open | 1 |

## Academy And Free-School Group Links

This section is relevant because academy trust, single-academy trust and sponsor relationships are major establishment-group patterns. However, the evidence is deliberately scoped: the extract covers academy and free-school establishment types only.

It contains links to school sponsors, multi-academy trusts and single-academy trusts. It should not be read as evidence for every group-link pattern, because federation, children's-centre group, children's-centre collaboration and other non-academy relationships are outside this extract.

| Establishment type code | Establishment type | School sponsor links | MAT links | SAT links | Total links |
| --- | --- | ---: | ---: | ---: | ---: |
| `28` | Academy sponsor led | 2,607 | 2,649 | 28 | 5,284 |
| `33` | Academy special sponsor led | 92 | 98 | 0 | 190 |
| `34` | Academy converter | 5,565 | 7,190 | 671 | 13,426 |
| `35` | Free schools | 400 | 495 | 50 | 945 |
| `36` | Free schools special | 98 | 129 | 5 | 232 |
| `38` | Free schools alternative provision | 33 | 40 | 14 | 87 |
| `39` | Free schools 16 to 19 | 22 | 28 | 8 | 58 |
| `40` | University technical college | 29 | 34 | 10 | 73 |
| `41` | Studio schools | 13 | 18 | 1 | 32 |
| `42` | Academy alternative provision converter | 70 | 95 | 0 | 165 |
| `43` | Academy alternative provision sponsor led | 31 | 36 | 0 | 67 |
| `44` | Academy special converter | 227 | 314 | 28 | 569 |
| `45` | Academy 16-19 converter | 15 | 37 | 5 | 57 |
| `46` | Academy 16 to 19 sponsor led | 2 | 2 | 0 | 4 |

## Sample Academy And Free-School Group Links

| Group type code | Group type | Linked UID | Group name | Sample URN | Establishment name | Establishment type code | Establishment type | Joined date |
| --- | --- | ---: | --- | ---: | --- | --- | --- | --- |
| `05` | School sponsor | 2043 | Abbey Multi Academy Trust | 137036 | Lightcliffe Academy | `28` | Academy sponsor led | 01-03-2015 |
| `06` | Multi-academy trust | 2044 | ABBEY ACADEMIES TRUST | 136354 | Bourne Abbey Church of England Primary Academy | `34` | Academy converter | 01-12-2010 |
| `10` | Single-academy trust | 2048 | ABBOTS HALL PRIMARY ACADEMY | 139605 | Abbots Hall Primary School | `34` | Academy converter | 01-05-2013 |

## Observations

- The most common group type in the all-groups extract is `10` Single-academy trust, with 1,917 rows.
- Multi-academy trust is the second largest group type, with 1,762 rows.
- School sponsor has 1,236 group rows but 9,204 academy/free-school link rows, showing that sponsor links are relationship-heavy in the scoped link extract.
- Multi-academy trust has the largest number of academy/free-school link rows, with 11,165.
- The archived `07` Umbrella trust type still appears in the group extract, with 20 rows.
- The archived `03` Collegiate and `04` Partnership group types are defined in the ERD evidence but have no rows in the supplied all-groups extract.
- Federation, children's-centre group and children's-centre collaboration groups are present in `allgroupsdata20260622.csv`, but not in the academy/free-school group-link extract. This means the academy/free-school link evidence is useful for trust and sponsor modelling, but should not be treated as the complete establishment-group relationship model.

## Interpretation

Establishment groups are not just labels on establishments. They are separate business structures with their own identifiers, types, status, dates and relationships.

Academy and free-school group links are dominated by multi-academy trust and school sponsor relationships. That is important evidence for trust and sponsor modelling. It is not the whole group-link picture: federation and children's-centre group structures exist in the wider group extract, but are outside the academy/free-school link extract.

## Design Implications

| Implication | What this means |
| --- | --- |
| Establishment groups need first-class modelling. | Trusts, sponsors, federations and children's-centre groups should not be treated as simple text fields. |
| Group type and group status are core attributes. | These attributes affect display, governance and relationship behaviour. |
| Extract scope matters. | A link extract focused on academies and free schools does not describe every group relationship. |
| Archived or rarely used group types still need a decision. | We should distinguish active support from retained reference-data completeness. |




