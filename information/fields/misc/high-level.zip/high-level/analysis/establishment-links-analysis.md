# Establishment Links Analysis

## Purpose

This analysis investigates the **Links** tab on public establishment pages, using the URL pattern:

```text
https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/{urn}#school-links
```

The aim was to find examples where the Links tab is more complex than a single predecessor or successor row, and to explain how links are represented in the current data model and application code.

## Important Distinction

There are two different kinds of "links" in the evidence:

| Link concept | What it links | Main evidence |
| --- | --- | --- |
| Establishment links | One establishment to another establishment | Public Links tab, `EstablishmentLink`, `LinkType`, C# `linked-establishments` API calls |
| Group links | An establishment to an organisation group, such as a trust, federation or children's centre group | `alllinksdata20260630.csv`, `grouplinks_edubaseallacademiesandfree20260630.csv`, `GroupLink` |

The public Links tab is about **establishment-to-establishment relationships**. It is not the same thing as establishment-to-group membership.

## Methodology

1. Reviewed the local files in `docs\data\extract-data\links`.
2. Profiled the two local links extracts to understand what they contain.
3. Built a candidate list of URNs from:
   - the sample establishment per type in `docs\data\extract-data\establishment-fields\establishment-type-analysis.md`;
   - establishments appearing most often in the local group-link extracts;
   - the user-supplied examples `137131`, `136570`, `136290` and `101358`.
4. Called the public GIAS Links tab for 220 candidate URNs.
5. Parsed the Links tab table for linked URN, linked establishment name, type of link and date linked.
6. De-duplicated observations where the same URN appeared in the candidate list from more than one evidence source.
7. Reviewed the ERD, Java and C# code to describe how links are modelled and implemented.

Generated evidence files:

| File | Purpose |
| --- | --- |
| `links-tab-candidate-urns.csv` | Candidate URNs used for the public Links tab scrape. |
| `links-tab-scrape-summary.csv` | Raw scrape summary, including duplicate candidate observations. |
| `links-tab-scrape-detail.csv` | Raw linked-establishment rows from the scrape. |
| `links-tab-scrape-detail-deduplicated.csv` | De-duplicated linked-establishment rows. |
| `links-tab-linked-establishments-deduplicated-summary.csv` | De-duplicated summary by source establishment. |

## Local Extract Findings

The files in `docs\data\extract-data\links` are primarily about group membership links, not the public Links tab.

| File | Rows | Distinct URNs | Maximum rows for one URN | Interpretation |
| --- | ---: | ---: | ---: | --- |
| `alllinksdata20260630.csv` | 24,369 | 15,134 | 2 | Establishment-to-group link extract. |
| `grouplinks_edubaseallacademiesandfree20260630.csv` | 21,189 | 11,985 | 2 | Academy/free-school group link extract. |

Top establishment types in `alllinksdata20260630.csv`:

| Establishment type | Rows |
| --- | ---: |
| Academy converter | 13,437 |
| Academy sponsor led | 5,287 |
| Children's centre | 1,535 |
| Free schools | 947 |
| Academy special converter | 569 |
| Community school | 562 |
| Foundation school | 471 |
| Free schools special | 233 |
| Voluntary controlled school | 220 |
| Academy special sponsor led | 190 |
| Academy alternative provision converter | 165 |
| Voluntary aided school | 164 |
| Local authority nursery school | 111 |
| Free schools alternative provision | 87 |
| University technical college | 76 |

These extracts are still useful because they help identify establishments that participate in group structures, but they are not enough to discover complex predecessor/successor-style Links tab behaviour.

## Public Links Tab Findings

The public scrape called 220 candidate establishment pages. After de-duplicating repeated candidate observations:

| Measure | Result |
| --- | ---: |
| Candidate establishment pages called | 220 |
| Source establishments with at least one Links tab row | 52 |
| De-duplicated Links tab rows found | 59 |
| Maximum Links tab rows found for one establishment | 4 |

The most complex example found was a sixth form centre with four linked schools.

### Complex Examples

| URN | Establishment | Type | Link count | Link types | Why it is useful |
| ---: | --- | --- | ---: | --- | --- |
| [132838](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/132838#school-links) | LaSWAP Sixth Form | Sixth form centres | 4 | Sixth Form Centre School | Shows one establishment linked to multiple establishments of the same relationship type. |
| [101857](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/101857#school-links) | The Academy of St Francis of Assisi | Academy sponsor led | 2 | Predecessor; Successor | Shows the same establishment sitting between an earlier and later record. |
| [138967](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/138967#school-links) | The CE Academy | Academy alternative provision converter | 2 | Predecessor; Successor | Shows an academy alternative provision record with both predecessor and successor relationships. |
| [139509](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/139509#school-links) | Ormiston Bridge Academy | Academy alternative provision converter | 2 | Predecessor; Predecessor - merged | Shows multiple predecessor-style relationships with different link types. |
| [141116](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/141116#school-links) | Bromley Trust Alternative Provision Academy | Academy alternative provision sponsor led | 2 | Predecessor | Shows more than one predecessor relationship. |
| [20018](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/20018#school-links) | Abbey Children's Centre | Children's centre linked site | 1 | Children's Centre Link | Shows the children's-centre-specific link type. |
| [100006](https://www.get-information-schools.service.gov.uk/Establishments/Establishment/Details/100006#school-links) | Heath School | Pupil referral unit | 1 | Predecessor - merged | Shows a PRU with a merged predecessor relationship. |

### Detailed Complex Examples

#### LaSWAP Sixth Form, URN 132838

| Linked URN | Linked establishment | Type of link | Date linked |
| ---: | --- | --- | --- |
| 100050 | Parliament Hill School | Sixth Form Centre School | None recorded |
| 100053 | Acland Burghley School | Sixth Form Centre School | None recorded |
| 100056 | William Ellis School | Sixth Form Centre School | None recorded |
| 100059 | La Sainte Union Catholic Secondary School | Sixth Form Centre School | None recorded |

This is the clearest example of a Links tab that is materially more complex than the single-link examples in the screenshot.

#### The Academy of St Francis of Assisi, URN 101857

| Linked URN | Linked establishment | Type of link | Date linked |
| ---: | --- | --- | --- |
| 104719 | Our Lady's Catholic High School | Predecessor | None recorded |
| 144493 | The Academy of St Francis of Assisi | Successor | 1 January 2016 |

This is useful because it shows that a single establishment can be modelled as part of a lifecycle chain, with a predecessor and a successor.

#### The CE Academy, URN 138967

| Linked URN | Linked establishment | Type of link | Date linked |
| ---: | --- | --- | --- |
| 121789 | Complementary Education | Predecessor | 1 November 2012 |
| 149432 | The CE Academy | Successor | 1 September 2022 |

This is another lifecycle-chain example, but for an alternative provision academy.

#### Ormiston Bridge Academy, URN 139509

| Linked URN | Linked establishment | Type of link | Date linked |
| ---: | --- | --- | --- |
| 100320 | The Bridge Academy | Predecessor | 1 April 2013 |
| 139541 | Ormiston Courtyard Academy | Predecessor - merged | 1 September 2023 |

This example shows that multiple predecessor-style relationships can exist, and that the link type carries important lifecycle meaning.

#### Bromley Trust Alternative Provision Academy, URN 141116

| Linked URN | Linked establishment | Type of link | Date linked |
| ---: | --- | --- | --- |
| 101584 | Bromley Pupil Referral Service | Predecessor | 15 July 2014 |
| 143931 | Nightingale | Predecessor | 31 August 2018 |

This example shows multiple predecessor relationships of the same type.

## Establishment Types Where Links Were Observed

The scrape found Links tab rows across the following candidate establishment types:

| Establishment type | Source establishments with links |
| --- | ---: |
| Academy alternative provision converter | 6 |
| Academy special converter | 6 |
| Academy 16-19 converter | 6 |
| Academy converter | 5 |
| Academy special sponsor led | 5 |
| Academy sponsor led | 5 |
| Academy alternative provision sponsor led | 5 |
| Academy 16 to 19 sponsor led | 2 |
| Children's centre linked site | 1 |
| University technical college | 1 |
| Community school | 1 |
| Pupil referral unit | 1 |
| Sixth form centres | 1 |
| City technology college | 1 |
| Voluntary controlled school | 1 |
| Foundation school | 1 |

Four linked rows were also found for the user-supplied examples where the candidate source did not carry an establishment type.

## What Establishment Links Are

An establishment link is a typed relationship from one establishment record to another establishment record.

In the ERD, this is represented by:

| Table | Meaning |
| --- | --- |
| `EstablishmentLink` | The relationship row between a source establishment and a linked establishment. |
| `LinkType` | The reference data that classifies the relationship. |
| `Establishment` | The source and target establishment records. |

The important columns are:

| Column | Meaning |
| --- | --- |
| `EstablishmentLink.URN` | Source establishment. This is the establishment whose Links tab contains the row. |
| `EstablishmentLink.linkURN` | Target or linked establishment. |
| `EstablishmentLink.type_code` | Link classification, such as predecessor, successor, merged or sixth form centre school. |
| `EstablishmentLink.establishedDate` | Business date displayed as Date linked. |
| `EstablishmentLink.systemLinkDate` | System-created date for the link row. |

The reference vocabulary is richer than just predecessor and successor. It includes:

| Link family | Examples |
| --- | --- |
| Predecessor-style links | Predecessor, Predecessor - Split School, Predecessor - merged, Predecessor - amalgamated |
| Successor-style links | Successor, Successor - Split School, Successor - merged, Successor - amalgamated |
| Lifecycle or structural change links | Closure, Expansion, Result of Amalgamation |
| Specific service links | Sixth Form Centre Link, Sixth Form Centre School, Children's Centre Link |
| Fallback link | Other |

## Establishment Link Types

The current ERD documents this reference data as `dbo.LinkType`, but in this context it should be read as **EstablishmentLinkType** because it classifies `EstablishmentLink` rows. This naming distinction matters because group links also have link terminology, but group links use a different relationship model.

Known establishment link type values:

| Code | Name | Archived | Id |
| --- | --- | --- | ---: |
| `0` | Not applicable | `0` | 1 |
| `1` | Predecessor | `NULL` | 2 |
| `1A` | Contraction | `1` | 3 |
| `1B` | Change of age range | `1` | 4 |
| `1C` | Change of age range + contraction | `1` | 5 |
| `1D` | Remove 6th Form | `1` | 6 |
| `1E` | Remove Nursery | `1` | 7 |
| `1F` | Predecessor - Split School | `NULL` | 8 |
| `1G` | Predecessor - Rejoin Departments | `1` | 9 |
| `1H` | Change Religious Character | `1` | 10 |
| `1I` | Closure | `NULL` | 11 |
| `1J` | De-registered | `1` | 12 |
| `1K` | Does not meet criteria for registration | `1` | 13 |
| `1L` | Predecessor - merged | `NULL` | 14 |
| `2` | Successor | `NULL` | 15 |
| `2A` | Expansion | `NULL` | 16 |
| `2B` | Change of age range | `1` | 17 |
| `2C` | Change of age range + expansion | `1` | 18 |
| `2D` | Add 6th Form | `1` | 19 |
| `2E` | Add Nursery | `1` | 20 |
| `2F` | Successor - Split School | `NULL` | 21 |
| `2G` | Successor - Rejoin Departments | `1` | 22 |
| `2H` | Change Religious Character | `1` | 23 |
| `2I` | For Academy | `1` | 24 |
| `2J` | Fresh Start | `1` | 25 |
| `2K` | Result of Amalgamation | `NULL` | 26 |
| `2L` | De-registered | `1` | 27 |
| `2M` | Former Independent | `1` | 28 |
| `2N` | New Provision | `1` | 29 |
| `2O` | Merged - change in age range | `NULL` | 30 |
| `2P` | Merged - expansion of school capacity | `NULL` | 31 |
| `2Q` | Merged - expansion in school capacity and changer in age range | `NULL` | 32 |
| `3` | Education by other | `1` | 33 |
| `4` | Sixth Form Centre Link | `NULL` | 34 |
| `5` | Sixth Form Centre School | `NULL` | 35 |
| `9` | Other | `NULL` | 36 |
| `CC` | Children's Centre Link | `NULL` | 37 |
| `6` | Successor - merged | `NULL` | 38 |
| `6.1` | Predecessor - amalgamated | `NULL` | 39 |
| `6.2` | Successor - amalgamated | `NULL` | 40 |

Interpretation:

| Pattern | Meaning |
| --- | --- |
| `1*` values | Mainly predecessor, closure or contraction-side relationship types. |
| `2*` values | Mainly successor, expansion or resulting-provision relationship types. |
| `4` and `5` | Sixth-form-centre-specific relationship types. |
| `CC` | Children's-centre-specific relationship type. |
| Archived values | Legacy values that may still be present historically but should not automatically be treated as current design options. |

## How Links Are Displayed

The C# frontend renders the Links tab from `Model.LinkedEstablishments`.

If links exist, the public page displays:

| Display field | Source model field |
| --- | --- |
| URN | linked establishment URN |
| Establishment name | linked establishment name |
| Type of link | link type display name |
| Date linked | link date, or `None recorded` |

If no links exist, the page displays:

```text
There are no linked establishments
```

The tab text explains that linked establishments may be predecessor or successor establishments, but the data model supports a wider range of link types.

## How Links Are Implemented In C#

The C# application treats links as a linked-establishment collection for an establishment.

Key behaviour:

| Behaviour | Implementation evidence |
| --- | --- |
| Read links | `EstablishmentReadApiService.GetLinkedEstablishmentsAsync` calls `GET establishment/{urn}/linked-establishments`. |
| Display links | `TabLinks.cshtml` renders the linked-establishment table. |
| Edit links | `EstablishmentController.AddEditLinkAsync` loads link types and saves link changes. |
| Save links | `EstablishmentWriteApiService.SaveLinkedEstablishmentsAsync` calls `PUT establishment/{urn}/linked-establishments`. |
| Create reverse links | The edit flow can add a reverse relationship to the linked establishment with its own reverse link type and date. |
| Delete links | The delete flow removes a selected link and can remove the reverse link when present. |

This matters for modelling because the relationship may be directional, but the UI can help maintain paired source and reverse links.

## How Links Are Implemented In Java

The Java backend maps establishment links as a domain entity.

Key behaviour:

| Behaviour | Implementation evidence |
| --- | --- |
| Relationship entity | `com.texunatech.edubase.domain.EstablishmentLink` maps table `EstablishmentLink`. |
| Source establishment ownership | `Establishment` owns a `Set<EstablishmentLink>`. |
| Linked establishment | `EstablishmentLink.link` is a mandatory `ManyToOne` reference to another `Establishment` through `linkURN`. |
| Link classification | `EstablishmentLink.type` is a mandatory `LinkType`, defaulting to `Other`. |
| Link dates | `establishedDate` is the business/effective date and `systemLinkDate` is the system-created date. |
| Audit | `EstablishmentLink` is audited through Hibernate Envers. |
| REST exposure | `LinkedEstablishmentModel` exposes link id, linked URN, link type id, link date and linked establishment name. |

Java also contains change-request classes for link changes, which confirms that establishment links are not just display metadata; they are governed application data.

## Interpretation For Future Modelling

We should model public Links tab data as **typed establishment-to-establishment relationships**.

Important modelling points:

| Point | Reason |
| --- | --- |
| Do not collapse links into simple text fields | Link rows point to another establishment and have typed lifecycle meaning. |
| Keep direction explicit | Predecessor and successor semantics depend on source and target direction. |
| Allow multiple links per establishment | LaSWAP Sixth Form has four linked schools; alternative provision examples have multiple predecessor/successor links. |
| Keep the link type as reference data | The type drives business meaning and is broader than predecessor/successor. |
| Preserve effective date separately from system-created date | The current model distinguishes business date from creation date. |
| Treat group links separately | Establishment-to-group membership is a different relationship pattern and should not be merged with establishment-to-establishment links. |
| Support reciprocal link creation carefully | Current UI supports reverse links, but the model should not assume every link is automatically reciprocal unless the business rule says so. |

## Recommended Next Checks

1. Validate the full `LinkType` reference data against the current database extract.
2. Confirm which link types are still active and which are archived.
3. Test whether every link type should be visible publicly or whether some are only operational/internal.
4. Confirm whether reciprocal links should be mandatory for specific link type pairs.
5. Confirm whether establishment links need their own data stewardship workflow in the new model.

## Design Implications

| Implication | What this means |
| --- | --- |
| Establishment links need explicit modelling. | We should model source establishment, linked establishment, link type and relevant business dates. |
| Link type is controlled reference data. | Lifecycle semantics should not be hidden in free text. |
| Establishment links and group links are separate models. | A generic `Link` concept would lose important business meaning. |
| Links support history and public explanation. | The model must support predecessor, successor, merged and related public display. |
