# Group Fields By Type

## Source

This document lists the group fields observed in `docs/data/extract-data/groups/allgroupsdata20260622.csv`, grouped by establishment group type.

The extract contains 7,172 group rows and 21 columns. The columns are treated as the available group extract fields. A field is counted as populated for a group type when at least one group of that type has a non-empty value other than `Not recorded`.

This is the group-side equivalent of the establishment field analysis in `docs/data/extract-data/establishment-fields/establishment-details-tab-fields-by-type.md`, but the evidence is different: this document is based on extract columns and populated values, not rendered public Details-tab HTML.

## Methodology

Validation was carried out on 22 June 2026.

The analysis was produced as follows:

1. `allgroupsdata20260622.csv` was loaded with `Import-Csv`.
2. Rows were grouped by `Group Type (code)` and `Group Type`.
3. Each CSV column was tested within each group type.
4. A field was marked as populated for that group type if at least one row had a non-empty value other than `Not recorded`.
5. The sample group UID is the lowest numeric `Group UID` for that group type.

Important limitations:

- This is extract evidence, not a direct export of `GroupField`, `GroupFieldPosition`, `GroupFieldPermission` or rendered group pages.
- A field can be a valid group field even when it is not populated in this extract.
- Head-of-group person-name columns are listed as field labels only; personal values are not reproduced.
- Children's-centre-specific labels from `GroupField.childrenCentreDisplayName` are not visible in this extract.

## Extract Fields

The all-groups extract contains these fields:

- `Group UID`
- `Group ID`
- `Group Name`
- `Companies House Number`
- `Group Type (code)`
- `Group Type`
- `Closed Date`
- `Open date`
- `Incorporated on (open date)`
- `Group Status (code)`
- `Group Status`
- `Group Street`
- `Group Locality`
- `Group Address 3`
- `Group Town`
- `Group County`
- `Group Postcode`
- `Head of Group Title`
- `Head of Group First Name`
- `Head of Group Last Name`
- `UKPRN`

## Populated Fields By Group Type

| Group type code | Group type | Sample group UID | Populated field count | Populated fields observed |
| --- | --- | ---: | ---: | --- |
| `01` | Federation | 1000 | 18 | Group UID; Group ID; Group Name; Group Type (code); Group Type; Closed Date; Open date; Group Status (code); Group Status; Group Street; Group Locality; Group Address 3; Group Town; Group County; Group Postcode; Head of Group Title; Head of Group First Name; Head of Group Last Name |
| `02` | Trust | 1028 | 15 | Group UID; Group Name; Companies House Number; Group Type (code); Group Type; Closed Date; Open date; Group Status (code); Group Status; Group Street; Group Town; Group Postcode; Head of Group Title; Head of Group First Name; Head of Group Last Name |
| `03` | Collegiate |  |  | Not observed in the available group extract. |
| `04` | Partnership |  |  | Not observed in the available group extract. |
| `05` | School sponsor | 2043 | 9 | Group UID; Group ID; Group Name; Group Type (code); Group Type; Closed Date; Open date; Group Status (code); Group Status |
| `06` | Multi-academy trust | 2044 | 19 | Group UID; Group ID; Group Name; Companies House Number; Group Type (code); Group Type; Closed Date; Incorporated on (open date); Group Status (code); Group Status; Group Street; Group Locality; Group Address 3; Group Town; Group Postcode; Head of Group Title; Head of Group First Name; Head of Group Last Name; UKPRN |
| `07` | Umbrella trust | 2185 | 8 | Group UID; Group ID; Group Name; Group Type (code); Group Type; Open date; Group Status (code); Group Status |
| `08` | Children's Centres Group | 80000 | 8 | Group UID; Group Name; Group Type (code); Group Type; Closed Date; Open date; Group Status (code); Group Status |
| `09` | Children's Centres Collaboration | 85901 | 8 | Group UID; Group Name; Group Type (code); Group Type; Closed Date; Open date; Group Status (code); Group Status |
| `10` | Single-academy trust | 1128 | 16 | Group UID; Group ID; Group Name; Companies House Number; Group Type (code); Group Type; Closed Date; Incorporated on (open date); Group Status (code); Group Status; Group Street; Group Locality; Group Town; Group Postcode; Head of Group Title; UKPRN |
| `11` | Secure single-academy trust | 17690 | 13 | Group UID; Group Name; Companies House Number; Group Type (code); Group Type; Open date; Group Status (code); Group Status; Group Street; Group Locality; Group Town; Group Postcode; UKPRN |

## Field Population Across All Groups

| Field | Populated rows | Populated percentage |
| --- | ---: | ---: |
| Group UID | 7,172 | 100.0% |
| Group ID | 4,942 | 68.9% |
| Group Name | 7,172 | 100.0% |
| Companies House Number | 3,491 | 48.7% |
| Group Type (code) | 7,172 | 100.0% |
| Group Type | 7,172 | 100.0% |
| Closed Date | 2,165 | 30.2% |
| Open date | 3,493 | 48.7% |
| Incorporated on (open date) | 3,679 | 51.3% |
| Group Status (code) | 7,172 | 100.0% |
| Group Status | 7,172 | 100.0% |
| Group Street | 3,624 | 50.5% |
| Group Locality | 3,430 | 47.8% |
| Group Address 3 | 2 | 0.0% |
| Group Town | 3,682 | 51.3% |
| Group County | 3 | 0.0% |
| Group Postcode | 3,678 | 51.3% |
| Head of Group Title | 226 | 3.2% |
| Head of Group First Name | 230 | 3.2% |
| Head of Group Last Name | 230 | 3.2% |
| UKPRN | 3,093 | 43.1% |

## Interpretation

- The extract fields are shared across group types, but population varies strongly by group type.
- `Group UID`, `Group Name`, `Group Type`, `Group Type (code)`, `Group Status` and `Group Status (code)` are populated for every row.
- `Group ID` is populated for 68.9% of group rows. It is not the same as `Group UID`.
- Companies House number and UKPRN are heavily associated with trust-style group organisations, especially multi-academy trusts, single-academy trusts and secure single-academy trusts.
- Address fields are populated for roughly half of group rows overall.
- `Group Address 3` and `Group County` are rarely populated.
- Head-of-group fields are sparsely populated in the extract and should be handled carefully because they can contain personal data.
- Group types `03` Collegiate and `04` Partnership are defined in the ERD evidence but are not present in the supplied all-groups extract.
- Group type `07` Umbrella trust is marked archived in the ERD evidence but still appears in the extract, with 20 rows.

## Design Implications

| Implication | What this means |
| --- | --- |
| Group identity is multi-identifier. | The logical model should keep Group UID, Group ID, Companies House number and UKPRN distinct. |
| Group field applicability varies by type. | Group type should drive field expectations and validation. |
| Personal fields need care. | Head-of-group fields should not be casually reproduced in public or test artefacts. |
| Extract population is not the same as field validity. | A field can be valid for a group type even if it is sparsely populated in the extract. |
