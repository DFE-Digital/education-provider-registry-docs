﻿# Production Table Usage 30-Day Analysis

## Purpose

We analysed 30 days of observed production table activity to understand which parts of the current GIAS database are being read or written, and which tables are candidates for further rationalisation.

This analysis is intended for high-level design evidence. It helps us avoid treating the whole legacy schema as equally active, while also avoiding the unsafe assumption that no observed activity means a table can be deleted.

## What We Analysed

| Item | Value |
| --- | --- |
| Baseline snapshot | 20 May 2026 |
| Latest snapshot | 19 June 2026 |
| Measurement window | 30 days |
| Environment | Production |
| Source method | SQL Server dynamic management view counters exported to CSV and compared offline |

The source counters record observed database activity. Write evidence comes from approximate index-update counters. Read evidence comes from latest observed seek, scan or lookup timestamps.

## Headline Findings

| Measure | Count |
| --- | ---: |
| Tables in latest snapshot | 416 |
| Tables with observed read or write activity | 284 |
| Tables with observed write activity | 122 |
| Tables with read-only observed activity | 162 |
| Tables with no observed read or write activity | 132 |

## Schema-Level View

| Schema | Observed activity in period | No observed activity in period | Total in snapshot |
| --- | ---: | ---: | ---: |
| `DataOpsJobs` | 17 | 13 | 30 |
| `dbo` | 258 | 116 | 374 |
| `gias_sharing` | 7 | 3 | 10 |
| `MasterProvider` | 2 | 0 | 2 |

## Interpretation

| Finding | What this means for design |
| --- | --- |
| Most tables had observed activity | We should not approach migration as if the legacy database is mostly dormant. A large part of the schema is still read or written. |
| Write-active tables need migration or replacement analysis first | Tables with writes are stronger evidence of live business or operational behaviour. These should be prioritised when identifying bounded contexts, migration slices and coexistence needs. |
| Read-only activity still matters | Read-only tables may be reference data, reporting inputs, cache inputs, operational metadata or legacy data still used by the application. They should not be dismissed simply because no writes were observed. |
| No-observed-activity tables are rationalisation candidates | Tables with no observed reads or writes should be investigated against code references, operational jobs, retention needs and business ownership before being treated as unused. |
| Caches and reference data need special care | Some values may be cached by the application, loaded indirectly, or read only during low-frequency jobs. Usage evidence should be combined with code and ERD evidence. |

## How We Should Use This Evidence

We should use the 30-day usage evidence as a triage signal, not as a deletion decision.

| Use | Position |
| --- | --- |
| HLD bounded-context evidence | Use write-active and read-active table families to test whether proposed service boundaries cover real current behaviour. |
| Migration sequencing | Prioritise write-active and high-read operational tables before dormant or candidate-retirement tables. |
| Reference-data analysis | Treat read-only lookup tables as potentially important. Reference data often changes rarely but can still be essential. |
| Table rationalisation | Use the no-observed-activity list to form a follow-up backlog, not an automatic retirement list. |
| Risk management | Combine usage evidence with ERD documentation, C# and Java code traces, extract usage and business-owner confirmation. |

## Tables With No Observed Activity

These tables had no observed reads or writes in the 30-day production measurement window. We should treat them as investigation candidates.

### DataOpsJobs

| Table | Latest update | Latest read |
| --- | --- | --- |
| `DataOpsJobs.CCP data dump dupe` | NULL | NULL |
| `DataOpsJobs.GIAS_IEBTSchoolCensus` | NULL | NULL |
| `DataOpsJobs.GIAS_IEBTSchoolCensus_Updates` | NULL | NULL |
| `DataOpsJobs.GIAS_SchoolCensus` | NULL | NULL |
| `DataOpsJobs.GIAS_SchoolCensus_Updates` | NULL | NULL |
| `DataOpsJobs.GIAS_UpdatedExclusionList_2024_Nov` | NULL | NULL |
| `DataOpsJobs.HE_to_add_to_GIAS` | NULL | NULL |
| `DataOpsJobs.NullCodeFieldEstablishments` | NULL | NULL |
| `DataOpsJobs.Ofsted_FurtherEducation` | NULL | NULL |
| `DataOpsJobs.Ofsted_GIASProdExtract` | NULL | NULL |
| `DataOpsJobs.Ofsted_IndependentSchools` | NULL | NULL |
| `DataOpsJobs.Ofsted_StateFunded` | NULL | NULL |
| `DataOpsJobs.pcd_pcon_uk_Import` | NULL | NULL |

### dbo

| Table | Latest update | Latest read |
| --- | --- | --- |
| `dbo.$__schema_journal` | NULL | NULL |
| `dbo.AdditionalDatasetOrder` | NULL | NULL |
| `dbo.AnalysisCriterionValue` | NULL | NULL |
| `dbo.AnalysisReportToMeasureType` | NULL | NULL |
| `dbo.AnnouncementTemplate_AUD` | NULL | NULL |
| `dbo.AnnouncementTemplate_UserGroup_AUD` | NULL | NULL |
| `dbo.ApplicationHistory` | NULL | NULL |
| `dbo.AutomatedEmailTemplate_AUD` | NULL | NULL |
| `dbo.ChangeHistoryNewValuesArchive1` | NULL | NULL |
| `dbo.ChangeHistoryOldValuesArchive1` | NULL | NULL |
| `dbo.ChangeRequestMailingHistoryArchive1` | NULL | NULL |
| `dbo.ChangeRequestProposer_AUD` | NULL | NULL |
| `dbo.ContentDocument` | NULL | NULL |
| `dbo.ContentDocument_AUD` | NULL | NULL |
| `dbo.DataDictionary_aud` | NULL | NULL |
| `dbo.DataDictionary_EstablishmentField_aud` | NULL | NULL |
| `dbo.DatasetName` | NULL | NULL |
| `dbo.DistrictAdministrative_AUD` | NULL | NULL |
| `dbo.Document` | NULL | 2026-05-19 07:51:43.377 |
| `dbo.Document_AUD` | NULL | NULL |
| `dbo.Document_UserGroup` | NULL | NULL |
| `dbo.Document_UserGroup_AUD` | NULL | NULL |
| `dbo.DocumentationSection` | NULL | 2026-05-19 07:51:43.377 |
| `dbo.DocumentationSection_AUD` | NULL | NULL |
| `dbo.EdubaseNote_AUD` | NULL | NULL |
| `dbo.EdubaseTriggerSettings_AUD` | NULL | NULL |
| `dbo.EmailAttachment` | NULL | NULL |
| `dbo.Establishment_AdditionalAddress_AUD` | NULL | NULL |
| `dbo.EstablishmentChangeHistory_AUDArchive1` | NULL | NULL |
| `dbo.EstablishmentChangeHistoryArchive1` | NULL | NULL |
| `dbo.EstablishmentField_AUD` | NULL | NULL |
| `dbo.EstablishmentFieldBase_ByTypeFieldPermission_AUD` | NULL | NULL |
| `dbo.EstablishmentFieldBase_EstablishmentFieldToTypeMapping_AUD` | NULL | NULL |
| `dbo.EstablishmentFieldBase_FieldPosition_AUD` | NULL | NULL |
| `dbo.EstablishmentGroupType_AUD` | NULL | NULL |
| `dbo.EstablishmentPartnership_AUD` | NULL | NULL |
| `dbo.EstablishmentSixthFormSchool_AUD` | NULL | NULL |
| `dbo.EstablishmentStatus_AUD` | NULL | NULL |
| `dbo.EstablishmentToFederation_AUD` | NULL | NULL |
| `dbo.EstablishmentToSen2_AUD` | NULL | NULL |
| `dbo.EstablishmentToSen3_AUD` | NULL | NULL |
| `dbo.EstablishmentToSen4_AUD` | NULL | NULL |
| `dbo.EstablishmentType_AUD` | NULL | NULL |
| `dbo.ExtractionLog` | NULL | NULL |
| `dbo.FAQ` | NULL | NULL |
| `dbo.FAQ_FAQGroup` | NULL | NULL |
| `dbo.FAQGroup` | NULL | NULL |
| `dbo.FAQSubject` | NULL | NULL |
| `dbo.FederationFlag` | NULL | NULL |
| `dbo.FederationType` | NULL | NULL |
| `dbo.Feedback` | NULL | NULL |
| `dbo.FieldPosition_AUD` | NULL | NULL |
| `dbo.FyiStakeholder` | NULL | NULL |
| `dbo.GeoData_AUD` | NULL | NULL |
| `dbo.GeoLocationAverages` | NULL | NULL |
| `dbo.GeoPostcodeAverages` | NULL | NULL |
| `dbo.GovUserRequest` | NULL | 2026-05-18 11:54:15.147 |
| `dbo.GroupField_AUD` | NULL | NULL |
| `dbo.GroupField_GroupFieldPosition_AUD` | NULL | NULL |
| `dbo.GroupFieldPermission_AUD` | NULL | NULL |
| `dbo.GroupFieldPosition_AUD` | NULL | NULL |
| `dbo.GroupFieldTab_AUD` | NULL | NULL |
| `dbo.GroupFieldValidation` | NULL | NULL |
| `dbo.GroupRelationsLink_AUD` | NULL | NULL |
| `dbo.HighPerformanceOption_AUD` | NULL | NULL |
| `dbo.InboxMessage` | NULL | 2026-05-17 00:33:49.127 |
| `dbo.IndependentSchools_EstablishmentProprietor_AUD` | NULL | NULL |
| `dbo.InspectionArchive1` | NULL | NULL |
| `dbo.InspectionUpdates` | NULL | NULL |
| `dbo.InvoiceDocument` | NULL | NULL |
| `dbo.LdapProfile` | NULL | NULL |
| `dbo.LegacyData_AUD` | NULL | NULL |
| `dbo.LlscLookup` | NULL | NULL |
| `dbo.LocalAuthority_AUD` | NULL | NULL |
| `dbo.LocalAuthorityContactDetails` | NULL | NULL |
| `dbo.MarketingOptOut_AUD` | NULL | NULL |
| `dbo.MeasureType` | NULL | NULL |
| `dbo.OlapTable` | NULL | NULL |
| `dbo.OldDictionary` | NULL | NULL |
| `dbo.OwningRule_aud` | NULL | NULL |
| `dbo.PaymentTerm` | NULL | NULL |
| `dbo.PersonalSettings_DefaultExtractFields` | NULL | NULL |
| `dbo.postcodes` | NULL | NULL |
| `dbo.postcodes_import` | NULL | NULL |
| `dbo.PredefinedReportCategory` | NULL | NULL |
| `dbo.QRTZ_BLOB_TRIGGERS` | NULL | NULL |
| `dbo.QRTZ_CALENDARS` | NULL | NULL |
| `dbo.ReasonEstablishmentClosed_AUD` | NULL | NULL |
| `dbo.ReasonEstablishmentOpened_AUD` | NULL | NULL |
| `dbo.Recipient` | NULL | NULL |
| `dbo.ReligiousCharacter_AUD` | NULL | NULL |
| `dbo.SchoolSponsorFlag` | NULL | NULL |
| `dbo.SchoolUser` | NULL | NULL |
| `dbo.SchoolUser_AUD` | NULL | NULL |
| `dbo.Section` | NULL | NULL |
| `dbo.Section_AUD` | NULL | NULL |
| `dbo.Sen_AUD` | NULL | NULL |
| `dbo.SingleClickQuery_AUD` | NULL | NULL |
| `dbo.SnacLocalAuthority` | NULL | NULL |
| `dbo.StaffField_AUD` | NULL | NULL |
| `dbo.StaffField_StaffFieldPosition_AUD` | NULL | NULL |
| `dbo.StaffFieldPermission_AUD` | NULL | NULL |
| `dbo.StaffFieldPosition_AUD` | NULL | NULL |
| `dbo.StaffFieldValidation` | NULL | NULL |
| `dbo.SubscriptionInfo_aud` | NULL | NULL |
| `dbo.SubscriptionInvoice` | NULL | NULL |
| `dbo.SubscriptionOrder` | NULL | 2026-05-18 11:57:27.393 |
| `dbo.SubscriptionPackage` | NULL | NULL |
| `dbo.SubscriptionSchedule` | NULL | NULL |
| `dbo.TestEncTable` | NULL | NULL |
| `dbo.TrueFalse` | NULL | NULL |
| `dbo.TrustedSource_AUD` | NULL | NULL |
| `dbo.TypeOfSite` | NULL | NULL |
| `dbo.UserGroup_aud` | NULL | NULL |
| `dbo.UserGroupPermission_aud` | NULL | NULL |
| `dbo.UserRole_AUD` | NULL | NULL |

### gias_sharing

| Table | Latest update | Latest read |
| --- | --- | --- |
| `gias_sharing.establishment_group_change_history_cache` | NULL | NULL |
| `gias_sharing.public_columns` | NULL | NULL |
| `gias_sharing.staff_record_change_history_cache` | NULL | NULL |

## Caveats

This analysis does not prove that a table is permanently used or unused.

- SQL Server dynamic management view counters can reset after restart, failover or database detach events.
- Write counts are approximate index-update counters, not counts of business transactions or changed rows.
- Read evidence is based on latest observed seek, scan or lookup timestamps.
- Some tables may be used by low-frequency jobs outside the measurement window.
- Some reference data may be cached by the application, reducing direct database read evidence.
- Some tables may need retention even if no current application path reads them.

## Recommended Follow-Up

1. Check the no-observed-activity list against C# and Java code references.
2. Mark each candidate table as active, legacy-retain, archive-retain, migrate, replace or retire.
3. Review write-active tables by proposed bounded context before finalising the high-level design.
4. Repeat the measurement if there is a major release, database failover, job schedule change or new migration decision.
