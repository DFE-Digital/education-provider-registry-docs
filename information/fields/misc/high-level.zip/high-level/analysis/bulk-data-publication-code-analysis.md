# Bulk Data Publication Code Analysis

## Purpose

We need a publishable view of what the legacy estate actually does for bulk data publication.

This note supports the DDD work for the `Bulk Data Publication` candidate in `docs/transformation/high-level/domain-driven-design/supporting-docs/additional-bounded-context-candidates.md`. It is code-led current-state analysis, not a target design.

We are using this evidence so that Bulk Data Publication can be put through:

- analysis
- DDD Stage 1: gather and normalise evidence
- DDD Stage 2: define ubiquitous language
- DDD Stage 3: identify and classify subdomains

## Working Finding

We have enough evidence to treat Bulk Data Publication as a real candidate capability.

It is not the same thing as the External Read API. The External Read API is about on-demand, versioned API contracts. Bulk Data Publication is about producing, storing, listing, securing, downloading and evidencing file-based data products.

However, we should be careful not to carry the whole legacy scheduled-extract solution forward by default. Scheduled extracts, Quartz jobs, callback records, Azure Blob storage and download polling are implementation evidence. The target capability we need to reason about is the governed publication of bulk data products.

## Resources Reviewed

| Resource | What We Used It For |
| --- | --- |
| `docs/transformation/high-level/domain-driven-design/supporting-docs/additional-bounded-context-candidates.md` | Existing candidate framing for Bulk Data Publication and the initial capability vocabulary. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/extracts/ScheduledExtract.java` | Scheduled extract definition: owner, run-as identity, filter, schedule, selected fields, output type, links/group-links flags, masking and public access. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/extracts/ScheduledExtractLog.java` | Download and generation log shape for scheduled extracts. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/extracts/ScheduledExtractsManagerImpl.java` | Extract creation, run-as behaviour, permission checks, download logging, ready-extract selection and failed-extract notification. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/extracts/ScheduledExtractRunnerManagerImpl.java` | Nightly generation, priority ordering, callback creation, blob upload, public extract exposure and callback history. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/ScheduledExtractJob.java` | Quartz entry point for nightly scheduled extract generation. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/web/rest/impl/DownloadsApiController.java` | REST API for listing available downloads, historical downloads, generated extract progress and download availability. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/web/rest/impl/ScheduledExtractsApiController.java` | REST API for listing scheduled extracts, generating a scheduled extract on demand, copying callback state and polling progress. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/web/rest/impl/RestExtractsDownloadController.java` | Public and non-public download mappings, extract tags, resource access checks and download endpoints. |
| `gias-dd-backend/src/main/resources/applicationContext-rest.xml` | Configured public download catalogue and extract manager mapping. |
| `gias-dd-backend/src/main/resources/applicationContext-extracts.xml` | Extract output paths, blob configuration and scheduled extract manager wiring. |
| `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` | Scheduled extract and failed-extract-checkout job schedules. |
| `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` | Example environment configuration for extract catalogue path, callback persistence, failed-extract recipients and cron schedules. |
| `get-information-about-schools/Web/Edubase.Web.UI/Controllers/DownloadsController.cs` | Frontend/BFF behaviour for listing downloads, collating selected downloads, requesting generation and polling progress. |
| `get-information-about-schools/Web/Edubase.Services.Texuna/Downloads/DownloadsApiService.cs` | C# service wrapper around the Java REST download and scheduled-extract endpoints. |
| `docs/data/erd/operations/scheduled-extracts-and-callbacks.md` | Existing ERD evidence for scheduled extract definitions, callback state, callback history and logs. |
| `docs/data/erd/publication/sharing-and-public-cache.md` | Existing ERD evidence for `gias_sharing` as a denormalised publication/read projection. |

## What The Legacy System Does

The legacy system supports several related bulk-publication behaviours.

It has a public downloads catalogue. The Java backend exposes named public data products such as:

- `All EduBase data`
- `All EduBase data links`
- `All open state-funded schools`
- `All open state-funded school links`
- `All open academies and free schools`
- `All open academies and free school links`
- `Academy sponsor and trust links`
- `All open children's centres`
- `All governance records`
- `All MAT governance records`
- `All academy governance records`
- `All LA maintained governance records`
- `Academies MAT membership history report`
- `All group records`
- `All group links records`
- `All group records with links`

It also has non-public and operational downloads, including SCDB extracts, non-public group data, governance completeness, user access, tools access, validation rules, data owners, lookup fields and ESFA CRM governance data.

The C# frontend lists these downloads, lets users select multiple files, requests collation or generation, polls progress and then presents the completed file. The Java backend owns the actual download catalogue, generation state, resource mappings and access checks.

## Scheduled Extracts

`ScheduledExtract` is the central legacy definition for a scheduled file-based output.

It records:

- creator username and creator group
- optional run-as username and run-as group
- extract name
- output type
- establishment filter
- callback
- embedded schedule
- priority flag
- last extraction date
- selected fields with parameters
- whether links, group links and groups feeds are included
- whether numeric values are masked
- whether the extract is publicly accessible

This is important because the legacy model combines several concerns in one object:

- product definition
- access context
- schedule
- field selection
- output shape
- execution state
- publication eligibility

For target design, we should not assume these concerns all belong in one model.

## Generation And Publication

The nightly scheduled-extract job is a Quartz job:

`ScheduledExtractJob` calls `ScheduledExtractRunnerManager.generateExtractsNightly()`.

The runner:

- asks `ScheduledExtractsManagerImpl` for ready extracts
- separates priority and non-priority extracts
- runs generation in parallel using the configured thread count
- creates or reuses callback state
- runs extraction under the creator or run-as user
- writes generated files
- uploads successful files to Azure Blob storage
- exposes public extract component files where needed
- writes callback history for historical public downloads

For public all-data style extracts, the system can expose separate output files for establishment data, links and group links. `AbstractPublicExtractDataManagerImpl` also caches public extract files locally, derives generated-date filenames and logs public download attempts.

This gives us strong evidence that publication is more than a query. It has publication artefacts, generated dates, storage keys, history and failure handling.

## Download Listing And History

`DownloadsApiController.downloadsGet` lists available downloads for a date.

For today's date, it returns the current configured downloads and adds custom extracts. For historical dates, it checks `CallbackHistory` and only includes products that have evidence for that date.

The controller also rewrites download URLs for several legacy/historical mappings. This matters because the stable public download catalogue is not just a static list of files. It is assembled from:

- configured public download details
- callback history
- historical tag-to-UID mappings
- file naming conventions
- access rules
- date filtering

## Access And Eligibility

Bulk Data Publication has visible access rules.

The code distinguishes:

- public downloads
- private resources mapped to allowed user groups
- scheduled extracts that are public accessible
- scheduled extracts available to their creator, run-as user, creator group, run-as group or service-desk group
- non-public extracts such as SCDB and all-groups-with-links outputs

`ScheduledExtractsManagerImpl.hasReadPermission` allows public extracts for everyone, establishment-user extracts only for the matching creator/run-as username, and other extracts for service desk or the owning group.

`RestExtractsDownloadController` also defines private resource mappings and checks current user group before reporting availability or serving generated downloads.

This is an important Stage 2 language point: extract access is not the same as API read permission. It is product-level eligibility for a file artefact, often tied to the user/group context under which the extract was generated.

## Field Selection And Format Stability

Scheduled extracts use selected `ExtractFieldWithParams` records and ordered `EstablishmentField` metadata. Public extract managers and `applicationContext-rest.xml` define specific named output products.

This means the capability includes field inclusion and format stability concerns:

- which records are selected
- which fields are included
- whether lookup names are shown
- whether numeric values are masked
- whether link and group-link feeds are included
- what filename and tag identify the extract
- whether consumers depend on CSV or ZIP output

These rules are not owned by GOV.UK-style API representation code. They are bulk data product rules.

## Failure Handling And Operational Evidence

The legacy implementation records and monitors failure.

`ScheduledExtractLog` records the scheduled extract, user, requested time, whether generation happened on the fly, filter, start time, finish time and success flag.

Callbacks record generation state, status, progress, storage location, failure cause and parent/temporary callback relationships.

`ScheduledExtractsManagerImpl.checkOutFailedExtractsWithEmail()` finds failed legacy extracts and sends scheduled-extract failure emails to configured operational recipients. The reviewed environment configuration includes:

- an extract catalogue path
- callback persistence enabled
- failed-extract email recipients
- a nightly scheduled-extract cron schedule
- a failed-callback cleanup/check schedule

For DDD, this tells us failure handling is part of the as-is capability. It does not mean the target service must use the same email, callback or Quartz design.

## Relationship To Sharing And Public Cache

The `gias_sharing` schema is adjacent evidence, but it is not the same thing as scheduled extracts.

The existing `sharing-and-public-cache` ERD describes `gias_sharing` as a denormalised public/read projection. It has cache tables and public views for establishments, groups, group links, staff/governance records and change history. The cache is refreshed by a stored procedure and appears to support a public/read API or downstream sharing contract.

Bulk Data Publication should therefore be considered alongside, but not collapsed into, the read model:

- `gias_sharing` is a projected read shape.
- scheduled/public extracts are file-based data products.
- the External Read API is an on-demand contract.

These may share source data and field rules, but they have different consumer interaction models and operational lifecycles.

## Normalised Capability Inventory

| Capability | As-Is Evidence | Why It Matters For DDD |
| --- | --- | --- |
| Download catalogue | `publicDownloadDetails`, `RestExtractsDownloadController` mappings, C# `DownloadsController` | Shows named bulk data products with tags, filenames, descriptions and access expectations. |
| Scheduled extract definition | `ScheduledExtract`, `ExtractFieldWithParams`, `Schedule`, `EstablishmentFilter` | Shows field selection, filters, schedule, run-as context and public accessibility. |
| Extract generation | `ScheduledExtractRunnerManagerImpl`, `ScheduledExtractJob`, `ScheduledExtractsManagerImpl` | Shows generation is a lifecycle with priority, execution, callback state and storage. |
| Public extract exposure | `AbstractPublicExtractDataManagerImpl`, public all-data managers, callback history | Shows generated products are exposed as dated artefacts and may be split into schools, links and group-links files. |
| Historical download access | `DownloadsApiController`, `CallbackHistory` | Shows consumers can ask for downloads by date where generation history exists. |
| Access control for extracts | `hasReadPermission`, private resource mappings, C# user-principal calls | Shows extract eligibility is product/user/group specific. |
| Download progress | temporary callbacks, progress endpoints, C# polling views | Shows large file generation is asynchronous and user-visible. |
| Download audit | `ScheduledExtractLog`, callback state and callback history | Shows the system records requested, started, finished and success/failure evidence. |
| Failure notification | `checkOutFailedExtractsWithEmail`, `failedExtractsEmailList`, `scheduleExtractFailure` notification intent | Shows missed/failed extract publication is operationally important. |
| Read projection adjacency | `gias_sharing` cache tables and public views | Shows another publication/read-model path that must be boundary-tested against file publication and API reads. |

## Candidate Stage 1 Evidence

For Stage 1, we should add Bulk Data Publication as a candidate evidence area.

The normalised Stage 1 evidence should include:

- named public and non-public download products
- scheduled extract definitions
- extract field and filter configuration
- public/private access rules
- callback and callback-history records
- download and generation logs
- file storage and generated-date naming
- failure notification evidence
- `gias_sharing` as adjacent publication/read-projection evidence

We should also capture a caution: scheduled extracts are a legacy implementation pattern. They prove that bulk publication exists, but they do not prove that the target service must retain user-defined scheduled extracts in the same form.

## Candidate Stage 2 Language

The Stage 2 vocabulary should avoid using `download`, `extract`, `publication` or `read API` as if they mean the same thing.

Suggested terms:

| Term | Working definition |
| --- | --- |
| Bulk data product | A named file-based data product made available for bulk consumption. |
| Download catalogue | The list of bulk data products available to a user for a date or current publication point. |
| Extract definition | The rule set that defines records, fields, format, schedule and access context for a generated file. |
| Extract generation | The process that creates a file artefact from source data and extract rules. |
| Published artefact | A generated file that can be downloaded or transferred. |
| Publication date | The date associated with a generated artefact's availability. |
| Extract format | The file format, column order, field naming and package structure that consumers depend on. |
| Field inclusion rule | The rule that decides which fields appear in a data product. |
| Extract eligibility | The access rule that decides who can see or request a data product. |
| Extract history | Evidence of previous generated artefacts, including status, generated date and storage location. |
| Extract audit | Evidence of who requested or generated an extract and whether it succeeded. |
| Publication failure | A failed generation, upload or exposure of a bulk data product. |

We should qualify `publication` carefully. Editorial publication, API publication, read-model projection and bulk file publication are different concerns.

## Candidate Stage 3 Classification

Bulk Data Publication looks like a supporting subdomain using generic batch, storage and file-transfer patterns.

| Aspect | Assessment |
| --- | --- |
| Business value | Medium to high supporting value. Downstream users and systems depend on file stability and availability. |
| Domain specificity | Medium. Record selection, field inclusion, masking, public/private eligibility and format stability are EPR-specific. |
| Rule complexity | Medium. The hardest rules are around product definition, access, field inclusion, consumer stability and history. |
| Availability of standard patterns | High for batch execution, object storage, progress tracking and file download. Lower for EPR-specific product semantics and data eligibility. |
| Suggested classification | Supporting subdomain using generic batch, file-generation and storage patterns; boundary and ownership to be tested. |

The target boundary decision should remain open. Stage 4 should test whether Bulk Data Publication is:

- a small supporting bounded context
- a thin application service alongside the External Read API
- a set of read-model/data-product rules owned by the domain contexts and delivered through shared publication tooling

## Boundary Questions

We should carry these questions forward:

| Question | Why It Matters |
| --- | --- |
| Which bulk data products are still required in the target service? | We should not migrate every legacy extract just because it exists. |
| Which consumers depend on fixed file formats and publication schedules? | Consumer dependency is the main reason to preserve a bulk publication capability. |
| Who owns field inclusion rules? | Establishment Registry and Governance may own field meaning, while Bulk Data Publication may own product packaging. |
| Who owns sensitivity and masking rules? | These may belong to Access Control, Information Governance or the domain context depending on the rule. |
| Is `gias_sharing` a read model, a publication cache or both? | This affects whether file publication and API read projection should share a delivery mechanism. |
| Should scheduled extracts remain user-defined? | Legacy scheduled extracts may be more capability than the target service needs. |
| How should publication failure be surfaced? | Failure may belong to live-service operations, Outbound Communication or the publication capability. |
| What evidence does EPR need to retain about generated files? | Audit/history needs determine whether callbacks and logs need target equivalents. |

## Recommendation For The DDD Process

We should add Bulk Data Publication to the DDD process, but with a narrow interpretation.

The capability is not `Quartz scheduling` and it is not `legacy scheduled extracts`. The capability is the governed publication of file-based data products for bulk consumers.

For Stage 1, we should capture the current products, rules, stores, jobs and histories.

For Stage 2, we should define language that separates bulk file publication from External Read API, editorial publication and generic download mechanics.

For Stage 3, we should classify it as a supporting subdomain using generic batch and file-transfer patterns, with EPR-specific rules around data-product definition, access, field inclusion, sensitivity and history.

Stage 4 should decide whether this needs a bounded context, a thin application service, or shared publication tooling fed by Establishment Registry, Governance and read-model projections.
