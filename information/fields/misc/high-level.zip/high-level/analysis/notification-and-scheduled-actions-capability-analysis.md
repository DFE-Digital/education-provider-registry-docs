# Notification And Scheduled Actions Capability Analysis

## Purpose

This document scopes unmapped legacy GIAS capabilities around notifications and scheduled actions so they can be fed back into the high-level DDD process for Stages 1, 2 and 3.

It is not a final bounded-context decision. It records evidence, interpretation and recommended next moves.

## Summary

The legacy estate has clear notification capabilities and clear scheduling capabilities, but they should not be collapsed into one model.

Recommended treatment:

| Capability area | Recommended DDD treatment | Rationale |
| --- | --- | --- |
| Outbound user and operational notifications | Treat as a candidate supporting bounded context, probably named `Outbound Communication` or `Notifications`. | The business model includes notification intent, template, recipient, eligibility, trigger, delivery channel, delivery attempt and audit. GOV.UK Notify can provide email delivery, but it does not own EPR notification rules or recipient eligibility. |
| GOV.UK Notify integration | Treat as an external delivery component used by the notification capability. | GOV.UK Notify removes the need to build an email-delivery platform, not the need to model when EPR should notify whom and why. |
| Frontend notification banners | Keep with Editorial Content unless they become event-triggered or recipient-specific. | Banners are runtime-presented content with start/end dates, not outbound delivery attempts. |
| Secure Access announcements | Treat as operational communication/integration evidence, not Editorial Content. | Legacy announcements combine trigger/action classification, audience targeting, publish/remove attempts and external Secure Access synchronisation. |
| Scheduled domain actions | Do not create a generic `Scheduling` bounded context by default. Model the due action in the owning domain or workflow context. | Establishment status changes, future-dated change requests and group membership effective dates are domain/workflow rules. A scheduler may execute them, but it should not own their meaning. |
| Scheduler and batch runtime | Treat as legacy implementation evidence and generic platform/application infrastructure. | Quartz, Spring Batch and scheduled extract machinery are solution choices in the legacy estate. They should not be treated as target business capabilities or provider-domain entities. |

The most useful Stage 1 addition is therefore not simply "Notification" and "Scheduling". It is a small set of candidate responsibilities:

- Outbound Communication / Notifications.
- Scheduled Domain Action Coordination, only if cross-context due actions need one owner.
- Operational Job Runtime, explicitly generic and probably not a bounded context.

## Legacy Notification Capabilities

### GOV.UK Notify Email Delivery

The Java backend includes a GOV.UK Notify client dependency and a central `NotificationSender` abstraction.

Evidence:

- `gias-dd-backend/pom.xml` includes `uk.gov.service.notify:notifications-java-client`.
- `gias-dd-backend/src/main/resources/applicationContext-email-notify.xml` wires `NotificationClient` instances for production, whitelist and test modes.
- `gias-dd-backend/src/main/resources/applicationContext-email-notify.xml` defines a `notifyTemplateIds` map for many notification templates.
- `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSender.java` defines application-facing send methods.
- `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSenderImpl.java` resolves template IDs, builds personalisation and calls `notificationClient.sendEmail(...)`.
- `docs/java-back-end/govuk-notify-integration.md` and `get-information-about-schools/documentation/service/back-end-component/integrations/govuk-notify-integration.md` document the integration.

Example notification types evidenced in `NotificationSender` and the Notify template map include:

- Welcome, activation, username reminder and password reset emails.
- Web-service password reset emails.
- Exception and server notification emails.
- Bulk update success, failure and error emails.
- FAQ and news review emails.
- Reminder notifications.
- User group changed emails.
- Scheduled extract failure emails.
- Federation update and new federation emails.
- Pending free school and academy sponsor-led approval/rejection emails.
- Data owner notifications.
- Staff/account expiry warning emails.
- Governance user request notifications and rejections.
- 60-day not-updated reminders.

DDD interpretation:

GOV.UK Notify is a delivery service. It can own email transmission mechanics, template rendering in Notify, Notify-side message identifiers and delivery status where available. It does not own EPR-specific rules such as:

- Which domain event or workflow state should trigger a notification.
- Which recipients are eligible.
- Whether a notification is sent to a data owner, proposer, establishment user, helpdesk, operational team or support mailbox.
- Whether a message should be suppressed, delayed, retried or escalated.
- How notification history is audited against a change request, establishment, group or governance record.

That means it is reasonable to capture an EPR notification capability as a bounded-context candidate, even if the implementation delegates email delivery to GOV.UK Notify.

### Change Request And Data Owner Notifications

The legacy backend contains notification logic around data stewardship workflows.

Evidence:

- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/ChangeRequestMailManager.java` handles data-owner action prompts, approval/rejection messages, delayed requests and helpdesk fallback when no data owner is available.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/notification/DataOwnerNotificationManagerImpl.java` groups applied override changes by data owner and sends data-owner notifications.
- `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` wires `ChangeRequestMailJob` using `change.request.email-schedule`.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` schedules `change.request.email-schedule=0 0 23 * * ?`.

DDD interpretation:

This is strong evidence that notifications are part of the data-stewardship lifecycle, but it does not mean Data Stewardship Workflow should own the full notification model. Workflow should own change state and decisions. A Notifications context could own notification intent, recipient resolution, template selection, send policy and notification audit, while using workflow/domain events as triggers.

### Reminders

The legacy backend has a general reminder model plus scheduled email sending.

Evidence:

- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/tasks/Reminder.java` and `ReminderInstance.java` model reminders and recipient instances.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/tasks/ReminderManagerImpl.java` deletes obsolete reminders and sends reminder notification emails to incomplete reminder instances.
- `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` wires `ReminderJob` using `reminders.processing-schedule`.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` schedules `reminders.processing-schedule=0 15 6 * * ?`.
- `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/bulk-updates-triggers-and-processing.md` describes `Reminder` and `ReminderInstance`.

DDD interpretation:

Reminders overlap notification and scheduling, but they are not merely emails. They have due dates, notification dates, completion state and recipient instances. If retained, reminders should be analysed as either:

- A feature inside a workflow/task-management capability, if reminders are human task reminders.
- A notification rule inside Notifications, if the only remaining behaviour is outbound reminder email.

### 60-Day Not-Updated Reminder

The legacy backend explicitly contains the policy the user remembered: a 60-day not-updated establishment reminder.

Evidence:

- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` contains the comment `#60 days not updated establishment reminder`.
- The same file schedules `sixty.day.not.updated.reminder = 0 5 19 ? * MON,TUE,WED,THU,FRI *`.
- `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` wires `SixtyDayNotUpdatedReminderJob` to that cron expression.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/SixtyDayNotUpdatedReminderJob.java` calls `SixtyDayNotUpdatedReminderManager.sendEmail()`.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/SixtyDayNotUpdatedReminderManagerImpl.java` calls `establishmentManager.findAllWithEmailsNotUpdatedForSixtyAndMoreDays()`.
- The same manager suppresses repeats where reminders were sent within the previous 8 days.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/SixtyDayNotUpdatedReminder.java` stores establishment, sending date and addressee.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/SixtyDayNotUpdatedReminderFlag.java` stores whether the reminder is enabled.

Current-state behaviour from code:

- The job is scheduled for weekdays at 19:05 in the reviewed environment configuration.
- It checks whether the 60-day reminder flag is enabled.
- It finds establishments not updated for 60 or more days.
- It avoids repeating a reminder where one was sent in the previous 8 days.
- It sends to establishment-related emails where available.
- If no establishment emails are available, it sends a support email to the configured helpdesk address.

DDD interpretation:

This is both a data-quality policy and a notification policy. The policy question belongs close to the Establishment Registry or Data Stewardship capability: "when is an establishment record stale enough to require action?" The outbound delivery and reminder history could belong to Notifications.

### Secure Access Announcements

Legacy announcements are not the same as editorial banners.

Evidence:

- `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/news-announcements-and-notifications.md` describes `AnnouncementTemplate`, `AnnouncementCollection`, `AnnouncementCollectionValues` and trigger/action relationships.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/ws/client/SafeSynchronizationService.java` publishes and unpublishes announcements to Secure Access.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` contains Secure Access announcement WSDL, username/password and publish/unpublish attempt counts.
- `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` wires `ResyncAnnouncementJob` using `schedule.task.resync.announcement`.

DDD interpretation:

Secure Access announcements are an operational communication/integration concern. They include audience targeting, external publication state, retry/resync behaviour and removal. They should stay separate from Editorial Content, because Editorial Content is about content visibility inside EPR, not external operational delivery.

### Frontend Notification Banners

The C# frontend has notification banner administration and display.

Evidence:

- `get-information-about-schools/Web/Edubase.Data/Entity/NotificationBanner.cs`.
- `get-information-about-schools/Web/Edubase.Data/Entity/NotificationTemplate.cs`.
- `get-information-about-schools/Web/Edubase.Web.UI/Controllers/NotificationsController.cs`.
- `get-information-about-schools/Web/Edubase.Web.UI/Views/Notifications/*.cshtml`.
- `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/news-announcements-and-notifications.md` records frontend banner `Start`, `End`, `Importance`, `Content` and `Version`.

DDD interpretation:

These are currently better treated as Editorial Content because they are runtime-managed presentation content with start and end dates. They should not be used as evidence for outbound notification delivery unless future requirements add recipient-specific or event-triggered sending.

## Legacy Scheduling And Scheduled Action Capabilities

### Quartz And Spring Batch Runtime

The Java backend uses Quartz for scheduled job triggers and Spring Batch for batch job runtime state.

Evidence:

- `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` defines many `CronTriggerFactoryBean` jobs.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` contains the cron schedules.
- `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/scheduler-and-batch-runtime.md` describes Quartz and Spring Batch runtime tables.
- `docs/java-back-end/scheduled-batch-operations.md` summarises the batch/scheduled-job component view.

Examples of scheduled jobs include:

- Establishment status auto-change.
- Apply approved establishment change requests.
- Apply approved group change requests.
- Reminder notification processing.
- Scheduled extract generation.
- Scheduled report generation.
- Data quality statistics refresh.
- Staff/governance record outdated checks.
- Staff role expiration checks.
- Secure Access announcement resynchronisation.
- UKPRN, Companies House and Ofsted update jobs.
- Cache rebuild and Redis initialisation jobs.
- Housekeeping jobs for callbacks, temp files, telephone/web-address removal and Azure SQL maintenance.

DDD interpretation:

Quartz and Spring Batch are operational execution mechanisms. They do not own the business meaning of scheduled actions. In target design, they could be replaced by platform scheduling, queue workers, Azure Functions, WebJobs, Hangfire, hosted services or another orchestration mechanism without changing the domain model.

### Future-Dated Establishment Change Requests

The legacy backend supports future-effective establishment changes through change request due dates and effective dates.

Evidence:

- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/change/ChangeRequest.java` stores `effectiveDate`, `dueDate`, status and change metadata.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/ChangeRequestManagerImpl.java` sets future-effective requests to `APPROVED` rather than applying them immediately.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/dao/hibernate/ChangeRequestDaoImpl.java` selects approved requests where `dueDate` is before tomorrow.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/ApplyApprovedJob.java` calls `ApplyApprovedManager.process()`.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/ApplyApprovedManager.java` loads approved requests, applies them and then processes Schools Registry and change notifications.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` schedules `change.request.processing-schedule=0 30 0 * * ?`.

DDD interpretation:

The schedule is not the source of truth. The source of truth is the approved change request and its due/effective date. The scheduled job is only the mechanism that wakes up and applies due changes.

Target implication:

Data Stewardship Workflow should own the approved-but-not-yet-applied workflow state. The owning domain context should own validation and application. Any generic scheduler should execute due work but not decide what the change means.

### Future-Dated Group Changes And Memberships

The group model also contains effective dates.

Evidence:

- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/groups/Link.java` stores `effectiveDate`.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/groups/change/GroupChangeRequest.java` stores `effectiveDate` and link effective date projections.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/dao/hibernate/GroupChangeRequestDaoImpl.java` finds approved group requests with `effectiveDate` before the current time.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/groups/change/GroupChangeRequestManagerImpl.java` applies past approved group requests.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` schedules `change.request.groups.processing-schedule=0 45 0 * * ?`.

DDD interpretation:

Group membership, group link and group relationship effective dates belong to the Establishment Registry context if groups remain in that context. A scheduler can apply due changes, but the membership rules and relationship history should remain in the domain context.

### Establishment Status Auto-Change

The backend automatically opens or closes establishments when configured dates are reached.

Evidence:

- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/EstablishmentStatusChangeJob.java` calls `EstablishmentManager.autoUpdateStatuses()`.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/EstablishmentManagerImpl.java` finds establishments proposed to close where `closeDate` is on or before today and establishments proposed to open where `openDate` is on or before today.
- The same code creates an establishment-status change request, changes status to `OPEN` or `CLOSED`, updates last-changed date and archives staff records when closing.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` schedules `establishment.auto.change.status=0 10 0 * * ?`.

DDD interpretation:

This is a domain lifecycle rule in Establishment Registry. The scheduled runner should not own the meaning of `PROPOSED_TO_OPEN`, `OPEN_PROPOSED_TO_CLOSE`, `OPEN` or `CLOSED`.

### Scheduled Extracts As Legacy Solution Evidence

Scheduled extracts are a substantial legacy implementation. They are reusable extract definitions with access, filter, selected fields, output and history.

Evidence:

- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/extracts/ScheduledExtract.java` stores creator, creator group, run-as group, run-as user, filter, schedule, callback, selected fields and public-access flag.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/extracts/Schedule.java` stores frequency, start date and end date.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/quartz/ScheduledExtractJob.java` calls `ScheduledExtractRunnerManager.generateExtractsNightly()`.
- `gias-dd-backend/src/main/java/com/texunatech/edubase/service/extracts/ScheduledExtractsManagerImpl.java` generates extracts under creator or run-as identity, handles public accessible extracts and writes generated files.
- `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/scheduled-extracts-and-callbacks.md` describes scheduled extract definition, selected fields, callback history and post-run verification.
- `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/scheduled-extract-access.md` describes creator group, run-as group/user and public access.
- `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` schedules `extracts.scheduled-extracts-cron-schedule=0 45 1 * * ?`.

DDD interpretation:

Scheduled extracts should not be carried forward as a required target capability merely because the legacy system implemented them.

The legacy model is useful evidence for consumer discovery and migration risk, but it is a solution pattern, not a domain capability. A target need should be stated independently, for example:

- A consumer needs a governed bulk data product that cannot reasonably use the External Read API.
- A statutory or operational process requires a point-in-time generated file.
- A downstream system requires asynchronous dataset delivery, callback evidence or file-based reconciliation.

Unless one of those needs is confirmed, Stage 1 should record scheduled extracts as legacy implementation evidence, not as a candidate bounded context or required capability.

## DDD Recommendations For Stages 1, 2 And 3

### Stage 1: Gather And Normalise Evidence

Add the following evidence rows or candidate responsibilities:

| Candidate responsibility | Evidence to add | Notes |
| --- | --- | --- |
| Outbound Communication / Notifications | GOV.UK Notify integration, `NotificationSender`, Notify template map, change-request emails, data-owner notifications, reminders, 60-day not-updated reminders, pending free school emails, staff/account expiry emails. | Treat GOV.UK Notify as delivery infrastructure; EPR still owns notification intent and rules. |
| Operational Announcements | `AnnouncementTemplate`, `AnnouncementCollection`, Secure Access WSDL integration, publish/unpublish/resync logic. | Keep separate from Editorial Content. |
| Scheduled Domain Actions | Change request due/effective dates, group change effective dates, establishment status auto-change. | These are domain/workflow rules executed by scheduled jobs. |
| Legacy Scheduled Extracts And Job Runtime | `ScheduledExtract`, selected extract fields, callbacks, callback history, run-as access, Quartz tables, Spring Batch tables and cron configuration. | Record as legacy implementation evidence and consumer-discovery input, not as a required target capability or bounded context. |

Stage 1 terminology conflicts to add:

| Term | Conflict or risk | Initial resolution |
| --- | --- | --- |
| Notification | Can mean outbound email, frontend banner, Secure Access announcement, domain event or UI status message. | Qualify as outbound notification, editorial banner, operational announcement or integration event. |
| Schedule | Can mean cron runtime, due date, effective date, extract frequency or content start/end period. | Qualify as job schedule, workflow due date, domain effective date, extract schedule or editorial effective period. |
| Announcement | Can mean Secure Access operational publication or general user-facing message. | Use Secure Access announcement for external operational publication. |
| Reminder | Can mean a task/reminder record or an outbound reminder email. | Separate reminder task from reminder notification. |
| Publication | Can mean editorial visibility, Secure Access publication, API/read-model publication or generated extract output. | Always qualify the publication target and mechanism. |

### Stage 2: Define Ubiquitous Language

Add a new language area for Outbound Communication / Notifications:

| Term | Working definition |
| --- | --- |
| Notification intent | The business reason and trigger for notifying someone. |
| Notification trigger | The event, state, date or manual action that creates a notification intent. |
| Recipient | A person, role, group, mailbox or support channel eligible to receive a notification. |
| Recipient resolution | The rule that turns domain data and policy into concrete email addresses or delivery targets. |
| Template | The reusable message shape selected for a notification type. |
| Personalisation | Domain values inserted into the message for a specific recipient or event. |
| Delivery channel | The mechanism used to send or present the notification, such as GOV.UK Notify email or Secure Access announcement. |
| Delivery attempt | A recorded attempt to send, publish, remove or resynchronise a notification. |
| Notification audit | The history of why a notification was created, who it targeted and what delivery outcome was recorded. |

Add a new language area for Scheduled Domain Actions if needed:

| Term | Working definition |
| --- | --- |
| Due action | A domain or workflow action that becomes eligible to run at or after a date/time. |
| Effective date | The business date from which a domain change should take effect. |
| Due date | The workflow or processing date when an approved change should be actioned. |
| Job schedule | The operational timetable used to wake a worker and check for due work. |

Stage 2 rule:

Do not use `notification` or `schedule` without a qualifier in design decisions.

### Stage 3: Identify And Classify Subdomains

Recommended classification:

| Candidate subdomain | Suggested classification | Confidence | Rationale |
| --- | --- | --- | --- |
| Outbound Communication / Notifications | Generic or supporting with EPR-specific rules | Medium to high | Sending messages is generic, but EPR-specific notification triggers, recipient rules, workflow interactions and audit are domain-specific. GOV.UK Notify should satisfy much of the delivery need. |
| Scheduled Domain Action Coordination | Supporting only if cross-context scheduling becomes explicit | Medium | The execution pattern is generic, but due actions may need coordination across Workflow, Establishment Registry and Governance. Avoid creating a context unless it owns durable due-action state beyond framework job runtime. |
| Operational Job Runtime | Generic infrastructure | High | Quartz/Spring Batch and scheduled extract runners are execution mechanisms and should not be modelled as business contexts. |
| Operational Announcements | Supporting/integration subdomain or part of Notifications | Medium | Secure Access announcements include templates, target groups, publish/remove state and retries. Confirm whether this survives EPR transformation. |

## Should Notifications Be Captured As A Bounded Context?

Yes, capture it as a bounded-context candidate, with careful wording.

Do not say "we need to build a Notifications service" yet. Say:

> EPR has a candidate Outbound Communication / Notifications bounded context. GOV.UK Notify can provide the email delivery component, but the EPR model still needs to decide who owns notification triggers, recipient resolution, template selection, suppression, retry/escalation policy and notification audit.

That keeps the DDD model honest without implying unnecessary custom infrastructure.

If the only retained notification behaviour for beta is a small number of direct GOV.UK Notify calls from application services, then implementation can remain lightweight. The bounded-context candidate is still useful because it prevents notification rules from being scattered invisibly across domain services without a shared vocabulary or audit model.

## Should Scheduling Be Captured As A Bounded Context?

Not as a broad `Scheduling` bounded context by default.

Scheduling appears in at least five meanings:

| Meaning | Example | Recommended owner |
| --- | --- | --- |
| Operational job schedule | Quartz cron for nightly jobs | Platform/application runtime |
| Workflow due date | Approved change request should apply when due | Data Stewardship Workflow plus owning domain context |
| Domain effective date | Establishment status, group link effective date | Establishment Registry or Governance, depending on the domain record |
| Editorial effective period | Banner/news start and end dates | Editorial Content |

A separate Scheduled Action Coordination context is only justified if EPR needs a durable, cross-context due-action model such as:

- Store a pending due action independent of the source workflow.
- Retry, cancel, pause or reschedule due actions consistently.
- Correlate due actions across multiple domain contexts.
- Provide operational visibility over all future-dated actions.

Without those requirements, the better design is:

- Domain contexts own effective dates and lifecycle rules.
- Workflow owns approved-but-not-applied change state.
- Editorial Content owns presentation start/end dates.
- Platform orchestration wakes workers and checks for due work.

## Recommended Next Actions

| Action | Stage | Outcome |
| --- | --- | --- |
| Add notification and scheduled-action evidence rows to Stage 1. | Stage 1 | Notifications, operational announcements and scheduled domain actions are visible in the evidence base. |
| Add qualified language for notification, schedule, announcement, reminder and publication. | Stage 2 | Prevents frontend banners, emails, Secure Access announcements and domain events being collapsed into one term. |
| Add candidate subdomain classifications for Notifications and Scheduled Domain Actions. | Stage 3 | Makes the missing capability explicit before bounded-context proposal work is revised. |
| Decide whether Notifications is a retained EPR responsibility or only delegated GOV.UK Notify calls. | Stage 3 or Stage 4 | Determines whether it appears as a bounded context, supporting component or implementation pattern. |
| Keep scheduled extracts and job runtime out of target domain ownership unless a separate consumer requirement proves a need. | Stage 4 | Avoids carrying forward Quartz/Spring Batch/scheduled extract design as a target capability by accident. |

## Open Questions

| Question | Why it matters |
| --- | --- |
| Which legacy notification types are required in EPR beta and post-beta? | Determines whether Notifications needs a real owned model or only a few direct integration calls. |
| Which notifications require durable audit evidence? | Important for change requests, data owner prompts, support escalations and statutory/accountability workflows. |
| Are Secure Access announcements still in scope for the target estate? | They are currently a separate operational communication/integration path. |
| Do any consumers need outbound data publication that cannot be met by the External Read API or read model? | This is the business capability question. It should be answered before retaining any scheduled-extract-like solution. |
| Who owns the stale-establishment data-quality policy? | The 60-day rule is confirmed in code, but target ownership should be agreed between Establishment Registry, Data Stewardship and Notifications. |
| Do future-dated changes require a central operational view? | If yes, a scheduled-action coordination capability may be justified. If no, keep due actions in workflow/domain contexts. |
