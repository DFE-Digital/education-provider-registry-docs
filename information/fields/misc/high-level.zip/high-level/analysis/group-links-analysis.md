# Group Links Analysis

## Purpose

This analysis investigates **group links** in the current GIAS data extracts and codebase.

The aim is to explain how establishments are linked to organisation groups, how complex those relationships can become, and how this differs from the public establishment **Links** tab investigated in `establishment-links-analysis.md`.

## Important Distinction

There are two different kinds of "links" in the evidence:

| Link concept | What it links | Main evidence |
| --- | --- | --- |
| Establishment links | One establishment to another establishment | Public Links tab, `EstablishmentLink`, `LinkType`, C# `linked-establishments` API calls |
| Group links | An establishment to an organisation group, such as a trust, sponsor, federation or children's-centre group | `allgroupslinksdata20260630`, `alllinksdata20260630.csv`, `grouplinks_edubaseallacademiesandfree20260630.csv`, `GroupLink` |

This document is about **group links**.

Group links should not be modelled as predecessor/successor establishment links. They are membership, sponsorship, governance-structure or collaboration relationships between an establishment and a group.

## Methodology

1. Reviewed the local files in `docs\data\extract-data\links`.
2. Profiled the group and group-link extracts:
   - `allgroupslinksdata20260630\groups.csv`;
   - `allgroupslinksdata20260630\links.csv`;
   - `alllinksdata20260630.csv`;
   - `grouplinks_edubaseallacademiesandfree20260630.csv`.
3. Counted groups by type and link rows by group type.
4. Identified large groups and establishments with multiple group links.
5. Reviewed the ERD evidence for `GroupLink`, `GroupRelationsLink`, `GroupLinkType`, `EstablishmentGroup` and cache/publication projections.
6. Reviewed Java and C# code paths that read, edit, validate, export and publish group links.

Generated evidence files:

| File | Purpose |
| --- | --- |
| `group-links-groups-by-type.csv` | Count of group records by group type. |
| `group-links-link-rows-by-group-type.csv` | Count of establishment-to-group link rows by group type. |
| `group-links-largest-groups.csv` | Largest groups by number of linked establishments. |
| `group-links-establishments-with-multiple-groups.csv` | Establishments linked to more than one group. |
| `group-links-academy-federation-type-counts.csv` | Federation type values in the academy/free-school group links extract. |

## Extract Findings

The group extract contains a group file and a link file:

| File | Rows | Interpretation |
| --- | ---: | --- |
| `allgroupslinksdata20260630\groups.csv` | 7,172 | One row per organisation group. |
| `allgroupslinksdata20260630\links.csv` | 24,369 | One row per establishment-to-group link. |
| `alllinksdata20260630.csv` | 24,369 | Same link-row shape as the links file in the zip extract. |
| `grouplinks_edubaseallacademiesandfree20260630.csv` | 21,189 | Academy/free-school focused group links extract. |

The all-groups-and-links extract contains:

| Measure | Count |
| --- | ---: |
| Group records | 7,172 |
| Distinct group UIDs present in link rows | 4,160 |
| Distinct establishments present in link rows | 15,134 |
| Maximum linked establishments for one group | 96 |
| Maximum group links for one establishment | 2 |

This shows that group links are normally simple at establishment level, but large and structurally important at group level.

## Group Types In The Extract

### Group Records By Type

| Group type | Groups |
| --- | ---: |
| Single-academy trust | 1,917 |
| Multi-academy trust | 1,762 |
| School sponsor | 1,236 |
| Federation | 1,108 |
| Children's Centres Group | 579 |
| Trust | 475 |
| Children's Centres Collaboration | 74 |
| Umbrella trust | 20 |
| Secure single-academy trust | 1 |

### Link Rows By Group Type

| Group type | Link rows |
| --- | ---: |
| Multi-academy trust | 11,173 |
| School sponsor | 9,206 |
| Children's Centres Group | 1,384 |
| Federation | 1,158 |
| Single-academy trust | 831 |
| Trust | 465 |
| Children's Centres Collaboration | 151 |
| Secure single-academy trust | 1 |

The difference between group counts and link-row counts is important. There are many single-academy trusts, but multi-academy trusts and school sponsors dominate the number of establishment links.

## Status Findings

Group records include current, closed and proposed group states:

| Group status | Groups |
| --- | ---: |
| Open | 5,006 |
| Closed | 2,164 |
| Proposed to open | 1 |
| Proposed to close | 1 |

The code filters visible/current links by group status and effective date. This means the stored relationship history is broader than the links a user may see in a current public or non-backoffice view.

## Complex Examples

### Large Trust And Sponsor Pairing

The largest group-link pattern found is a paired multi-academy trust and school sponsor structure.

| Group UID | Group name | Group type | Linked establishments |
| ---: | --- | --- | ---: |
| 5142 | United Learning Trust | School sponsor | 96 |
| 5143 | UNITED LEARNING TRUST | Multi-academy trust | 96 |
| 4320 | REACH2 ACADEMY TRUST | Multi-academy trust | 65 |
| 4318 | REAch2 Academy Trust | School sponsor | 65 |
| 4475 | Delta Academies Trust | School sponsor | 64 |
| 4474 | DELTA ACADEMIES TRUST | Multi-academy trust | 64 |
| 15916 | St Gabriel the Archangel Catholic Multi-Academy Trust | School sponsor | 63 |
| 4127 | ST GABRIEL THE ARCHANGEL CATHOLIC MULTI-ACADEMY TRUST | Multi-academy trust | 63 |

This suggests that some academy establishments can be linked to both:

- a trust group; and
- a sponsor group.

Those are separate group records even when they represent closely related real-world organisations.

### Establishments With Two Group Links

The maximum number of group links observed for a single establishment in the extract is two.

Examples:

| URN | Establishment | Establishment type | Group | Group type | Joined date |
| ---: | --- | --- | --- | --- | --- |
| 130912 | Paddington Academy | Academy sponsor led | United Learning Trust | School sponsor | 01/09/2006 |
| 130912 | Paddington Academy | Academy sponsor led | UNITED LEARNING TRUST | Multi-academy trust | 01/09/2006 |
| 146300 | St Joseph's Catholic Primary School | Academy converter | CHRISTUS CATHOLIC TRUST | Multi-academy trust | 01/12/2017 |
| 146300 | St Joseph's Catholic Primary School | Academy converter | Catholic Diocese of Brentwood Schools Trust | School sponsor | 01/12/2017 |
| 146303 | AldridgeUTC@MediaCityUK | University technical college | ALDRIDGE EDUCATION | Multi-academy trust | 01/09/2018 |
| 146303 | AldridgeUTC@MediaCityUK | University technical college | Aldridge Education | School sponsor | 01/09/2018 |

This is a key modelling point: an establishment may have multiple simultaneous group relationships, but the extract suggests the current practical maximum is two.

### Children's Centre Group Link

Children's centre data uses group links too.

Example:

| URN | Establishment | Establishment type | Group | Group type | Joined date |
| ---: | --- | --- | --- | --- | --- |
| 20003 | Central Sure Start Children's Centre | Children's centre | Central | Children's Centres Group | 01/01/1900 |

The code has a children-centre-specific link characteristic, `ccLinkType`, and the C# editing model has a `CCIsLeadCentre` flag. This means children's-centre group links carry additional semantics beyond simple membership.

## What Group Links Are

A group link is a typed or specialised relationship between one establishment and one organisation group.

In the ERD, this is represented by:

| Table | Meaning |
| --- | --- |
| `EstablishmentGroup` | The organisation group, such as a trust, sponsor, federation or children's-centre group. |
| `GroupLink` | The bridge row between an establishment and a group. |
| `Establishment` | The establishment linked to the group. |
| `GroupRelationsLink` | A separate group-to-group relationship table. |
| `GroupLinkType` | Reference data for group-to-group relationship types, especially SAT/MAT predecessor-successor relationships. |

The important `GroupLink` columns are:

| Column | Meaning |
| --- | --- |
| `GroupLink.urn` | Establishment identifier. |
| `GroupLink.group_id` | Group identifier. |
| `GroupLink.effectiveDate` | Date from which the establishment-to-group link applies. |
| `GroupLink.archived` | Soft-delete or inactive flag. |
| `GroupLink.linkType` | Federation-specific link characteristic in the Java embedded `Link` object. |
| `GroupLink.ccLinkType` | Children's-centre-specific link characteristic. |

## Children's Centre Link Type Nuance

`GroupLink.ccLinkType` is not the same thing as `GroupLinkType`.

`GroupLinkType` classifies `GroupRelationsLink`, which is a group-to-group relationship. `ccLinkType` sits directly on `GroupLink`, which is the establishment-to-group relationship. It is only meaningful for children's-centre group links.

In Java, `ccLinkType` is represented by `ChildrensCentresGroupLinkType`:

| Stored enum value | Display value | Meaning |
| --- | --- | --- |
| `STANDARD` | `No` | The linked children's centre is not the lead centre for the group link. |
| `LEAD` | `Yes` | The linked children's centre is the lead centre for the group link. |

Implementation nuance:

| Behaviour | Meaning |
| --- | --- |
| `ccLinkType` is set only for children's-centre group types | Java clears it to `null` when the group is not a children's-centre group. |
| C# exposes this as `CCIsLeadCentre` | The frontend models the same concept as a boolean: is this linked establishment the lead centre? |
| The UI derives `CCLeadCentreUrn` from linked establishments | The selected lead centre is represented as the linked establishment with `CCIsLeadCentre = true`. |
| Java converts `ccLinkType = LEAD` to `ccIsLeadCentre = true` | The REST model hides the enum behind a boolean for the C# UI. |
| The value is not physically FK-backed in the captured schema | It is stored as a nullable enum/string-like column on `GroupLink`, not as a normal lookup table FK. |

This means children-centre group links have additional role semantics. They are not just "establishment belongs to group"; one linked establishment can be marked as the lead centre for that group.

## Group Links And Group-To-Group Links

`GroupLink` and `GroupRelationsLink` should be kept separate.

| Relationship | Source | Target | Meaning |
| --- | --- | --- | --- |
| `GroupLink` | Establishment | Establishment group | This establishment belongs to, is sponsored by, or participates in this group. |
| `GroupRelationsLink` | Establishment group | Establishment group | This group is related to another group, especially for trust conversion/history. |

The ERD and Java code indicate that `GroupRelationsLink` is mainly used for SAT-to-MAT conversion history. Java creates reciprocal group-to-group links for old SAT to new MAT and new MAT to old SAT.

Known `GroupLinkType` values are:

| Code | Name |
| --- | --- |
| `0` | Not recorded |
| `1M` | Successor MAT |
| `1S` | Predecessor SAT |

This is not the same vocabulary as establishment `LinkType`.

## How Group Links Are Exported

The Java `GroupExtractsController` exposes extract endpoints for:

| Extract | Meaning |
| --- | --- |
| `groups.xls` | Group records only. |
| `links.xls` | Group-link records only. |
| `groups_and_links.zip` | Groups and links together. |

The controller comments also describe public CSV shapes for:

| Extract | Meaning |
| --- | --- |
| `allgroupsdata.csv` | All group records. |
| `alllinksdata.csv` | All group links. |
| `allgroupslinksdata.zip` | All groups plus all group links. |

This aligns with the files in `docs\data\extract-data\links`.

## How Group Links Are Implemented In Java

The Java backend maps `GroupLink` as an audited entity with an embedded `Link` value object.

Key behaviour:

| Behaviour | Implementation evidence |
| --- | --- |
| Relationship entity | `com.texunatech.edubase.domain.groups.GroupLink`. |
| Embedded relationship details | `com.texunatech.edubase.domain.groups.Link` maps `group_id`, `urn`, `linkType`, `ccLinkType` and `effectiveDate`. |
| Current links by establishment | `GroupLinkDaoImpl.findLinks(urn)` returns non-archived links where `effectiveDate <= today`. |
| All links by establishment | `findAllLinksByURN(urn)` returns non-archived links regardless of effective date. |
| All links by group | `findAllLinksByGroupId(id)` returns non-archived links for a group. |
| Public/export filtering | Export logic can require public-visible/open-or-closed group status and hides created-in-error groups for non-backoffice users. |
| Federation checks | Java queries group links where group type is federation to determine whether an establishment is in a federation. |
| Children's-centre semantics | `ccLinkType` and lead-centre behaviour are handled separately from ordinary membership. |
| Audit | `GroupLink` is audited through Hibernate Envers. |

The Java domain therefore treats group links as live structural relationships, not just extract rows.

## How Group Links Are Implemented In C#

The C# group editing UI models linked establishments as part of group edit/create flows.

Key behaviour:

| Behaviour | Implementation evidence |
| --- | --- |
| UI collection | `GroupLinkedEstablishmentsViewModel.Establishments` holds linked establishments for a group. |
| Link DTO | `LinkedEstablishmentGroup` carries `Id`, `Urn`, `JoinedDate` and `CCIsLeadCentre`. |
| Display/edit model | `EstablishmentGroupViewModel` carries establishment name, URN, type, status, joined date and `CCIsLeadCentre`. |
| Add/edit/remove links | `GroupController` builds a `SaveGroupDto` containing linked establishments. |
| Joined date validation | Group validators and API validation check establishment joined dates. |
| Children's-centre lead centre | If no linked establishment is marked as lead centre, the UI logic marks the first one. |

This matters because group-link editing is a group-management workflow, not an establishment Links tab workflow.

## Interpretation For Future Modelling

We should model group links as **membership or participation relationships between an establishment and an organisation group**.

Important modelling points:

| Point | Reason |
| --- | --- |
| Keep group links separate from establishment links | `GroupLink` and `EstablishmentLink` represent different business concepts. |
| Allow more than one group link per establishment | The extract shows establishments linked to both a trust and a sponsor. |
| Model joined/effective date | The current model uses `effectiveDate`, and extracts expose `Joined date`. |
| Model group status separately | Groups can be open, closed, proposed to open or proposed to close. Link visibility depends partly on group status. |
| Preserve group type | Group type changes the meaning of the relationship: MAT, SAT, sponsor, federation and children's-centre group are not interchangeable. |
| Treat children's-centre semantics explicitly | `ccLinkType` and `CCIsLeadCentre` show that children's-centre links carry additional meaning. |
| Treat group-to-group history separately | `GroupRelationsLink` is the group-to-group relationship pattern, especially SAT/MAT conversion history. |
| Do not assume group records map one-to-one to legal organisations | Similar names appear as separate MAT and sponsor group records. |
| Preserve audit/change history | `GroupLink` is audited and participates in group change-request workflows. |

## Recommended Next Checks

1. Validate current allowed values for `GroupLink.linkType` and `GroupLink.ccLinkType`.
2. Confirm whether the two-link establishment maximum is a business rule or only an observed extract pattern.
3. Confirm whether sponsor links should remain separate from trust membership links in the future model.
4. Confirm how closed group links should be exposed in public extracts and APIs.
5. Confirm whether children's-centre lead-centre behaviour should be modelled as a property of the link or as a role within the group.
6. Validate group-to-group relationship data directly if a current extract is available for `GroupRelationsLink`.

## Design Implications

| Implication | What this means |
| --- | --- |
| Group links need explicit modelling. | We need a relationship between establishment and establishment group with dates and role semantics where applicable. |
| Trust and sponsor links are different relationships. | We should not collapse sponsor and trust relationships into one text field. |
| Children's-centre lead centre is a link role. | Lead-centre behaviour should be explicit if children's-centre groups remain in scope. |
| Group-to-group relationships are separate. | SAT-to-MAT history should not be represented as an establishment link. |
