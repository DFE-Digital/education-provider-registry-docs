# Legacy Notification Catalogue

## Purpose

We need a plain catalogue of the outbound notifications implemented in the legacy Java backend.

This document is intentionally as-is. It lists the notification template keys and sender methods we can see in the code. It does not decide whether these notifications should exist in the target service, and it does not classify them as bounded contexts.

## Source Evidence

| Source | Evidence Used |
| --- | --- |
| `gias-dd-backend/src/main/resources/applicationContext-email-notify.xml` | GOV.UK Notify template keys and template IDs. |
| `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSender.java` | Application-facing sender method names. |
| `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSenderImpl.java` | Mapping from sender methods to template keys and personalisation. |

## Catalogue Notes

- `Template key` is the key in the `notifyTemplateIds` map.
- `Sender method` is the Java method exposed by `NotificationSender`.
- Some sender methods use hard-coded recipient routing or derive recipients before sending. This catalogue only records the notification shape, not every caller.
- The spelling `Establishmnet` is preserved where it appears in the legacy code.

## Account And Access Lifecycle

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `welcomeEmail` | `sendWelcomeEmail` | Welcome email for a user login. |
| `remindUsernameEmail` | `sendRemindUsernameEmail` | Username reminder email. |
| `activationEmail` | `sendActivationEmail` | Account activation email. |
| `newPasswordEmail` | `sendNewPasswordEmail` | New password email. |
| `resetPasswordEmail` | `sendResetPasswordEmail` | Password reset email. |
| `resetEstablishmnetPasswordEmail` | `sendResetEstablishmnetPasswordEmail` | Establishment password reset email. |
| `resetWsPasswordEmail` | `sendResetWsPasswordEmail` | Web-service password reset email. |
| `resetEstablishmnetWsPasswordEmail` | `sendResetEstablishmnetWsPasswordEmail` | Establishment web-service password reset email. |
| `changePasswordEmail` | `sendChangePasswordEmail` | Changed password email. |
| `agreementApprovedEmail` | `sendAgreementApprovedEmail` | Agreement approved email. |
| `agreementRejectedEmail` | `sendAgreementRejectedEmail` | Agreement rejected email. |
| `agreementExpirationWarningEmail` | `sendAgreementExpirationWarningEmail` | Agreement expiry warning email. |
| `userAccountExpiresNotification` | `sendUserAccountExpiresNotification` | User account expiry notification. |
| `userGroupChangedMail` | `sendUserGroupChangedMail` | User group changed email. |
| `changeUserGroup` | `sendChangeUserGroup` | Change user group email. |

## Subscription And Invoice

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `subscriptionSuccessfulEmail` | `sendSubscriptionSuccessfulEmail` | Subscription success email. |
| `subscriptionInvoiceEmail` | `sendSubscriptionInvoiceEmail` | Subscription invoice email. |
| `confirmInvoicePaymentEmail` | `sendConfirmInvoicePaymentEmail` | Invoice payment confirmation email. |

## Operational And System Alerts

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `exceptionOnServerEmail` | `sendExceptionOnServerEmail` | Exception/server error email. |
| `notificationOnServerEmail` | `sendNotificationOnServerEmail` | General server notification email. |
| `sanityCheckFailedMail` | `sendSanityCheckFailedMail` | Sanity check failure email. |
| `scheduleExtractFailure` | `sendScheduleExtractFailure` | Scheduled extract failure email. |

## Feedback

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `feedbackEmail` | `sendFeedbackEmail` | General feedback email. |
| `feedbackUnknownEmail` | `sendFeedbackUnknownEmail` | Feedback email where the issue type is unknown. |
| `feedbackSecureAccessPin` | `sendFeedbackSecureAccessPin` | Feedback email about Secure Access PIN. |
| `feedbackEstablishmentDetails` | `sendFeedbackEstablishmentDetails` | Feedback email about establishment details. |

## Bulk Update

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `bulkUpdateSuccessEmail` | `sendBulkUpdateSuccessEmail` | Bulk update success email. |
| `bulkUpdateFailEmail` | `sendBulkUpdateFailEmail` | Bulk update failure email. |
| `bulkUpdateErrorEmail` | `sendBulkUpdateErrorEmail` | Bulk update error email. |

## Content Review

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `faqReviewEmail` | `sendFaqReviewEmail` | FAQ review email. |
| `newsStoryReviewEmail` | `sendNewsStoryReviewEmail` | News story review email. |
| `automatedEmailTemplateReview` | `sendAutomatedEmailTemplateReview` | Automated email template review email. |

## Reminders And Data Freshness

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `reminderNotificationEmail` | `sendReminderNotificationEmail` | General reminder notification email. |
| `sixtyDayNotUpdatedReminderEmail` | `sendSixtyDayNotUpdatedReminderEmail` | 60-day not-updated reminder email sent to establishment contacts/users. |
| `sixtyDayNotUpdatedReminderSupportEmail` | `sendSixtyDayNotUpdatedReminderSupportEmail` | 60-day not-updated support email sent to helpdesk where establishment recipient emails are missing. |

## Establishment And Group Workflow

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `federationUpdateEmail` | `sendFederationUpdateEmail` | Federation update email. |
| `newFederationEmail` | `sendNewFederationEmail` | New federation email. |
| `newIebtEstablishmentEmail` | `sendNewIebtEstablishmentEmail` | New IEBT establishment email. |
| `newSootEstablishmentEmail` | `sendNewSootEstablishmentEmail` | New SOOT establishment email. |
| `spiChangesEmail` | `sendSpiChangesEmail` | SPI changes email. |
| `userMigrationRejectedEmail` | `sendUserMigrationRejectedEmail` | User migration rejected email. |
| `multipleUAMSAccounts` | `sendMultipleUAMSAccounts` | Multiple UAMS accounts email. |
| `iebtConvertedToFreeSchool` | `sendIebtConvertedToFreeSchool` | IEBT converted to free school email. |

## Pending Free School And Academy Sponsor-Led Workflow

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `newPendingFreeSchool` | `sendNewPendingFreeSchool` | New pending free school email. |
| `approveOrRejectPendingFreeSchool` | `sendApproveOrRejectPendingFreeSchool` | Approve or reject pending free school email. |
| `approveOrRejectPendingAcademySponsorLed` | `sendApproveOrRejectPendingAcademySponsorLed` | Approve or reject pending academy sponsor-led email. |
| `pendingFreeSchools` | `sendPendingFreeSchools` | Pending free schools summary email. |
| `newFreeSchoolUserNotification` | `sendNewFreeSchoolUserNotification` | New free school user notification email. |
| `notifyNewFreeSchoolUser` | `sendNotifyNewFreeSchoolUser` | Notify new free school user email. |

## Data Owner And Change Request Workflow

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `dataOwnerNotification` | `sendDataOwnerNotification` | Data-owner notification for applied override change requests. |
| `delay` | `sendDelay` | Change request delay email. |
| `reminderToApproveOrReject` | `sendReminderToApproveOrReject` | Reminder to approve or reject change requests. |
| `requestApproved` | `sendRequestApproved` | Change request approved email. |
| `requestRejected` | `sendRequestRejected` | Change request rejected email. |
| `askDOForAction` | `sendAskDOForAction` | Ask data owner for action email. |

## Staff And Governance

| Template key | Sender method | As-is purpose |
| --- | --- | --- |
| `staffExpirationNotificationWarningFirst` | `sendStaffExpirationNotificationWarningFirst` | First staff expiration warning email. |
| `staffExpirationNotificationWarningLast` | `sendStaffExpirationNotificationWarningLast` | Final staff expiration warning email. |
| `governorUserRequestNotification` | `sendGovernorUserRequestNotification` | Governor user request notification email. |
| `governorUserRequestRejection` | `sendGovernorUserRequestRejection` | Governor user request rejection email. |

## Template Key Coverage Check

Every active template key in `applicationContext-email-notify.xml` has a corresponding sender operation in `NotificationSender`.

The commented `test` entry in the XML file is not included in this catalogue.

## Raw Template Key List

For quick checking, the active template keys in `applicationContext-email-notify.xml` are:

```text
welcomeEmail
remindUsernameEmail
activationEmail
newPasswordEmail
resetPasswordEmail
resetEstablishmnetPasswordEmail
resetWsPasswordEmail
resetEstablishmnetWsPasswordEmail
agreementRejectedEmail
agreementApprovedEmail
changePasswordEmail
subscriptionSuccessfulEmail
subscriptionInvoiceEmail
confirmInvoicePaymentEmail
exceptionOnServerEmail
notificationOnServerEmail
feedbackEmail
bulkUpdateSuccessEmail
bulkUpdateFailEmail
bulkUpdateErrorEmail
faqReviewEmail
newsStoryReviewEmail
reminderNotificationEmail
userGroupChangedMail
sanityCheckFailedMail
federationUpdateEmail
newFederationEmail
newIebtEstablishmentEmail
newSootEstablishmentEmail
spiChangesEmail
userMigrationRejectedEmail
multipleUAMSAccounts
iebtConvertedToFreeSchool
newPendingFreeSchool
approveOrRejectPendingFreeSchool
approveOrRejectPendingAcademySponsorLed
pendingFreeSchools
dataOwnerNotification
newFreeSchoolUserNotification
staffExpirationNotificationWarningLast
staffExpirationNotificationWarningFirst
changeUserGroup
notifyNewFreeSchoolUser
delay
reminderToApproveOrReject
requestApproved
requestRejected
askDOForAction
automatedEmailTemplateReview
governorUserRequestNotification
governorUserRequestRejection
userAccountExpiresNotification
feedbackUnknownEmail
feedbackSecureAccessPin
feedbackEstablishmentDetails
agreementExpirationWarningEmail
sixtyDayNotUpdatedReminderEmail
sixtyDayNotUpdatedReminderSupportEmail
scheduleExtractFailure
```
