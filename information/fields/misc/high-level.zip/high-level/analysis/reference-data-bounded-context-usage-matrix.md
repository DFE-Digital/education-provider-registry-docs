# Reference Data Usage By Bounded Context

## Purpose

This matrix identifies which current reference-data items are evidenced as used by the Establishment Registry bounded context, the Governance bounded context, or both. It supports distributed ownership decisions; it does not propose a separate Reference Data bounded context.

## Methodology

The matrix was derived on 8 July 2026 from `reference-data-ownership-analysis.md`, supported by the schema-wide reference-data analysis and UI-tab analysis. A **Yes** means the existing analysis explicitly assigns the item to the context or names that context as a consumer. It does not prove a separate physical copy exists.

`ValidationRule` is excluded because target validation rules belong inside each bounded context and are behaviour/configuration rather than business reference data. `Title` is included as a shared person-title vocabulary. Items used only by Access Control are outside this two-context matrix.

## Items Used By Both

| Reference data | Values | Why Establishment Registry uses it | Why Governance uses it | Materiality classification | Target handling |
| --- | --- | --- | --- | --- | --- |
| `Title` | Examples include `Mr`, `Mrs`, `Miss`, `Ms` and `Dr`; blank title is also present in governance extracts. | Provides the title used for establishment and group contacts, such as headteachers, principals and managers. | Governance-person records contain a title for display. | **Trivial for boundary design.** It is presentation data, not a governance rule or invariant. | Do not replicate a lookup into Governance. Store the selected title with the person where required, or compose the displayed governance name in the frontend/read layer using a canonical title value. |
| `LocalAuthority` | The full local-authority code and name dataset; it is not a small fixed enumeration. | Identifies the local authority associated with establishments and groups and supports geography, filtering and scope. | Governance may need the establishment's local-authority context for display, filtering or authorisation. | **Important establishment context, but not shared Governance reference data.** | Establishment Registry remains authoritative. Governance references the subject by `URN`; frontend/read composition or a query contract supplies local-authority details when needed. |
| `EstablishmentType` | The establishment-type catalogue, such as community school, academy converter, pupil referral unit and children's centre. | Drives field applicability, validation, display and lifecycle behaviour. | May determine expected governance model or how governance is presented. | **Essential cross-context fact where governance rules vary by establishment type.** The labels themselves do not need replication. | Establishment Registry owns and resolves the type. Supply the stable type code or resolved attribute through a contract only where Governance has a real rule depending on it. |
| `EstablishmentGroupType` | Group types including academy trusts, sponsors, federations and children's-centre group types. | Drives interpretation of groups, memberships and relationships. | Distinguishes trust/group contexts for group-scoped governance. | **Essential cross-context fact for group-scoped governance.** It is an Establishment Registry classification, not Governance-owned reference data. | Establishment Registry owns the catalogue. Governance consumes a stable group-type code or resolved group context through the group identity contract. |
| `GovernorsFlag` | `haslocal`, `haslocalandshared`, `hasshared`, `nolocal`. | Records the academy or group's local/shared/no-local governor arrangement as part of its structural classification. | Determines whether local governors, shared local governors, both, or no local governors should be expected and presented. | **Important, not trivial, if local/shared governance remains in scope.** The four-value lookup itself is trivial; the selected value is a meaningful domain fact. | Keep the selected flag and its rules in Establishment Registry. Governance or the frontend/read layer consumes the resolved flag; do not maintain an independent Governance copy of the lookup. |
| `Governance` | `1` LA; `2` Other Community Group; `3` Health; `4` PVI; `NA` N/A. | Classifies how governance is arranged for an establishment, especially children's centres and non-school settings. | Could inform which governance arrangement should be interpreted or displayed. | **Likely trivial/legacy for the target boundary.** It is a small establishment classification and is not the Governance bounded-context model. Confirm whether any retained journey or rule still uses it. | Keep with Establishment Registry if retained. Ignore in Governance unless a specific rule is evidenced; otherwise compose the label in the frontend/read layer or retire it. |

These six overlaps are evidence of cross-context consumption, not evidence of replication. On closer classification, none requires a separately maintained reference-data copy in Governance. The important integrations are resolved establishment/group facts (`EstablishmentType`, `EstablishmentGroupType` and `GovernorsFlag`), while display-only values can be composed by the frontend/read layer.

### Essential Sharing Conclusion

| Category | Items | Sharing requirement |
| --- | --- | --- |
| Essential contextual facts | `EstablishmentType`, `EstablishmentGroupType`, `GovernorsFlag` | Governance may need the selected code/fact through an Establishment Registry contract. It does not need to own or replicate the lookup catalogue. |
| Contextual but not intrinsically Governance data | `LocalAuthority` | Compose through Establishment Registry/read models when a journey, filter or policy needs it. |
| Presentation-only | `Title` | Compose in the frontend/read layer or carry the selected display value with the governance person. No cross-context reference service is needed. |
| Trivial or legacy candidate | `Governance` | Retain only if an evidenced target rule or journey uses it; otherwise ignore or retire it. |

## Full Matrix

| Reference data | Establishment Registry uses | Governance uses | Used by both |
| --- | --- | --- | --- |
| `AccommodationChanged` | Yes | No | No |
| `AdministrativeWard` | Yes | No | No |
| `AdmissionsPolicy` | Yes | No | No |
| `Association` | Yes | No | No |
| `Beacon` | Yes | No | No |
| `Boarders` | Yes | No | No |
| `BoardingEstablishment` | Yes | No | No |
| `BurnhamReport` | Yes | No | No |
| `ByTypeFieldPermission` | Yes | No | No |
| `CasWard` | Yes | No | No |
| `ChangeReason` | Yes | No | No |
| `ChildCareFacilities` | Yes | No | No |
| `ChildrensCentresGroupFlag` | Yes | No | No |
| `ChildrensCentresLeadFlag` | Yes | No | No |
| `ChildrensCentresPhaseType` | Yes | No | No |
| `ContactPreference` | Yes | No | No |
| `ContactType` | Yes | No | No |
| `County` | Yes | No | No |
| `DataDictionary` | Yes | No | No |
| `Diocese` | Yes | No | No |
| `DirectProvisionOfEarlyYears` | Yes | No | No |
| `DisadvantagedArea` | Yes | No | No |
| `DistrictAdministrative` | Yes | No | No |
| `EarlyExcellence` | Yes | No | No |
| `EduBaseTrigger` | Yes | No | No |
| `EducationActionZone` | Yes | No | No |
| `EducationByOthers` | Yes | No | No |
| `EducationPhase` | Yes | No | No |
| `EducationPhaseGroup` | Yes | No | No |
| `EstablishmentAccredited` | Yes | No | No |
| `EstablishmentField` | Yes | No | No |
| `EstablishmentFieldValidation` | Yes | No | No |
| `EstablishmentGroupType` | Yes | Yes | Yes |
| `EstablishmentStatus` | Yes | No | No |
| `EstablishmentType` | Yes | Yes | Yes |
| `EstablishmentTypeGroup` | Yes | No | No |
| `ExcellenceInCities` | Yes | No | No |
| `ExcellenceInCitiesActionZone` | Yes | No | No |
| `ExcellenceInCitiesCityLearningCentre` | Yes | No | No |
| `ExcellenceInCitiesGroup` | Yes | No | No |
| `EYFSExemption` | Yes | No | No |
| `Federation` | Yes | No | No |
| `FieldGroup` | Yes | No | No |
| `FieldPosition` | Yes | No | No |
| `FieldTab` | Yes | No | No |
| `FreshStart` | Yes | No | No |
| `FullTimeProvision` | Yes | No | No |
| `FurtherEducationType` | Yes | No | No |
| `Gender` | Yes | No | No |
| `GeoData` | Yes | No | No |
| `GorLookup` | Yes | No | No |
| `Governance` | Yes | Yes | Yes |
| `GovernmentOfficeRegion` | Yes | No | No |
| `GovernorsFlag` | Yes | Yes | Yes |
| `GroupField` | Yes | No | No |
| `GroupFieldPermission` | Yes | No | No |
| `GroupFieldPosition` | Yes | No | No |
| `GroupFieldTab` | Yes | No | No |
| `GroupLinkType` | Yes | No | No |
| `GSSLACode` | Yes | No | No |
| `HighPerformanceOption` | Yes | No | No |
| `IndependentSchoolType` | Yes | No | No |
| `Inspectorate` | Yes | No | No |
| `InspectorateName` | Yes | No | No |
| `InvestorInPeople` | Yes | No | No |
| `LaGorMapping` | Yes | No | No |
| `LaGssMapping` | Yes | No | No |
| `LeadershipIncentive` | Yes | No | No |
| `LearningSupportUnit` | Yes | No | No |
| `LinkType` | Yes | No | No |
| `LLSC` | Yes | No | No |
| `LocalAuthority` | Yes | Yes | Yes |
| `LocalAuthorityGroup` | Yes | No | No |
| `LSOA` | Yes | No | No |
| `MarketingOptOut` | Yes | No | No |
| `MovedToEdubaseLogin` | Yes | No | No |
| `MSOA` | Yes | No | No |
| `Nationality` | Yes | No | No |
| `NurseryProvision` | Yes | No | No |
| `OfficialSixthForm` | Yes | No | No |
| `OfstedRating` | Yes | No | No |
| `OfstedSpecialMeasures` | Yes | No | No |
| `OperationalHours` | Yes | No | No |
| `ParliamentaryConstituency` | Yes | No | No |
| `PrivateFinanceInitiative` | Yes | No | No |
| `ProprietorType` | Yes | No | No |
| `ProvisionEbd` | Yes | No | No |
| `ProvisionSen` | Yes | No | No |
| `QualityAssuranceBodyName` | Yes | No | No |
| `ReasonEstablishmentClosed` | Yes | No | No |
| `ReasonEstablishmentOpened` | Yes | No | No |
| `RegisteredEarlyYears` | Yes | No | No |
| `RegistrationSuspended` | Yes | No | No |
| `ReligiousCharacter` | Yes | No | No |
| `ReligiousEthos` | Yes | No | No |
| `RSCRegion` | Yes | No | No |
| `S2SLogin` | Yes | No | No |
| `SAAccessRestrictions` | Yes | No | No |
| `SecondMainSpecialism` | Yes | No | No |
| `SecondSpecialism` | Yes | No | No |
| `Section41Approved` | Yes | No | No |
| `Sen` | Yes | No | No |
| `SpecialClasses` | Yes | No | No |
| `Specialism` | Yes | No | No |
| `StaffAppointingBody` | No | Yes | No |
| `StaffField` | No | Yes | No |
| `StaffFieldPermission` | No | Yes | No |
| `StaffFieldPosition` | No | Yes | No |
| `StaffFieldRole` | No | Yes | No |
| `StaffRole` | No | Yes | No |
| `StaffRoleType` | No | Yes | No |
| `StaffType` | No | Yes | No |
| `StudioSchoolIndicator` | Yes | No | No |
| `SuperannuationCategory` | Yes | No | No |
| `TeenagedMothers` | Yes | No | No |
| `Title` | Yes | Yes | Yes |
| `ToeFieldGroup` | Yes | No | No |
| `TrainingSchool` | Yes | No | No |
| `TrustSchool` | Yes | No | No |
| `Ttwa` | Yes | No | No |
| `TypeOfReservedProvision` | Yes | No | No |
| `UrbanRural` | Yes | No | No |
| `UserGroupPermission` | Yes | No | No |

## Interpretation

The matrix supports reference-data ownership inside the domain bounded contexts:

- Establishment Registry owns establishment, group, relationship, location and establishment-facing classifications.
- Governance owns governance roles, appointing bodies and governance-field metadata.
- Cross-context use is concentrated in six items and can be handled through an authoritative contract rather than a separate Reference Data bounded context.
- The matrix does not show evidence that the six shared items are currently replicated between two independently owned stores.

## Sources

- `docs/transformation/high-level/domain-driven-design/reference-data-ownership-analysis.md`
- `docs/data/investigation/reference-data-analysis.md`
- `docs/data/investigation/reference-data-by-ui-tab.md`
