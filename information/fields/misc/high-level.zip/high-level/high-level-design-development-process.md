# High-Level Design Development Process

## Purpose

We need to produce a high-level design for the transformed Education Provider Registry.

Before we draw the HLD, we should produce evidence that we have used domain-driven design principles to identify, test and explain the bounded contexts. The immediate output should be a good-looking bounded-context design document that can be published in Confluence. Once that is agreed, we can use it as the foundation for the HLD and the C4 diagrams.

This document defines the staged process we should use in `docs/transformation/high-level` to get there.

## Methodology

This process uses:

- Existing transformation analysis in `docs/transformation`.
- The access-control analysis and conceptual model in `docs/transformation/access-control`.
- The data-stewardship workflow analysis in `docs/transformation/data-stewardship`.
- Existing service-boundary thinking in `docs/transformation/tech-plan/05-service-boundaries.md`.
- Domain-driven design strategic design practices: domain exploration, ubiquitous language, subdomain classification, bounded-context identification, context mapping and boundary testing.
- C4 modelling for the eventual HLD diagrams.

This is a working process document. It is not yet the bounded-context paper or the final HLD.

## Outcomes

We should work towards two main outcomes.

| Outcome | Purpose | Format |
| --- | --- | --- |
| Bounded-context evidence document | Shows that we have used DDD principles to identify and test the service boundaries. This should be suitable for Confluence publication. | Narrative document with context map, bounded-context catalogue, boundary tests, assumptions, risks and open questions. |
| High-level design document | Describes the agreed target architecture and how the major components work together. | HLD with C4 diagrams, responsibilities, integration patterns, data ownership, access-control model, workflow model and key design decisions. |

## Domain-Driven Design Approach

Domain-driven design does not start by drawing services. It starts by understanding the domain and the language the business uses.

We should use DDD to do the following:

1. Identify the core business capabilities.
2. Build a shared language for each capability.
3. Separate concepts that look similar but have different business meaning.
4. Identify bounded contexts where a model, language and set of rules should be internally consistent.
5. Map how bounded contexts collaborate.
6. Test whether the proposed boundaries reduce coupling, protect ownership and support change.

For this work, DDD should help us avoid turning database areas, UI tabs or legacy structures directly into services. We should use legacy evidence, but we should not let the legacy schema define the target architecture by accident.

## Candidate Responsibilities

The responsibilities we currently need to resolve are:

| Responsibility | Initial Interpretation |
| --- | --- |
| Establishment and Establishment Group transactional data | Owns the operational model for education providers and provider groupings. This includes the lifecycle, identity, classification, status, relationships and business rules for establishments and establishment groups. |
| Governance transactional data | Owns governance people, roles, appointments, governance bodies and governance relationships. This context has its own language and lifecycle that should not be folded into establishment details by default. |
| Access Control | Owns policy, authorisation decisions, permissions, scopes, protected resources and decision audit. This needs to work across all domain service boundaries. |
| Data Stewardship Workflows | Owns change requests, proposed values, workflow tasks, decisions, evidence and workflow history. This needs to coordinate changes across domain service boundaries without owning the authoritative domain records. |
| External Read API | Owns stable read contracts for external consumers. It should expose governed data products and API resources without leaking internal transaction models or workflow implementation details. |
| Reference Data | Responsibility covering the reference data used across the registry. Its language, ownership, lifecycle, rules and boundaries must be established through the DDD process. |
| Editorial Content | Responsibility covering authored news, frontend editorial banners, FAQs, documents, content pages and glossary entries. Its current stores, ownership, publication lifecycle and target disposition must be established without including outbound message delivery. |
| Outbound Communication | Responsibility covering outbound notifications, notification intent, triggers, recipient resolution, delivery channels, delivery attempts, templates, reminders, operational alerts and notification history. Its boundary must be tested against GOV.UK Notify, workflow, access control and the domain contexts that create the need to notify. |

## Candidate Bounded Contexts

We should start with these candidate bounded contexts and then test them.

| Candidate bounded context | Primary model | Owns | Does not own |
| --- | --- | --- | --- |
| Establishment and Establishment Group | Establishment, establishment group, identifiers, classification, status, lifecycle, membership and relationships. | Authoritative establishment and establishment group transactional records. | Governance appointments, access policy, workflow lifecycle or external API contract design. |
| Governance | Governance person, role, appointment, board, trustee, member, local governor and governance relationship. | Authoritative governance transactional records and governance-specific business rules. | Establishment lifecycle, establishment group lifecycle, access policy or workflow lifecycle. |
| Access Control | Actor, role, group, scope, protected resource, action, policy, policy version, decision and audit. | Authorisation policy, policy versions, access decisions and decision audit. | Domain records or change-request lifecycle. |
| Data Stewardship Workflow | Change request, change item, proposed value, task, decision, evidence, workflow state and workflow history. | Workflow lifecycle and the record of proposed, reviewed, approved and applied changes. | Authoritative establishment or governance records, access policy or external API contracts. |
| External Read API | API resource, representation, version, consumer, contract and read permission. | External consumer contract and read-facing resource model. | Domain transaction ownership, workflow ownership or internal persistence model. |
| Reference Data | Reference dataset, code, label, definition, version, effective period, supersession and retirement. | To be established through the DDD process. | To be established through the DDD process. |
| Editorial Content | Article, editorial banner, FAQ, document, content page, section, glossary entry, publication state, effective period, editorial grouping and presentation audience. | To be established through the DDD process. | Outbound message delivery, delivery attempts, retry processing, provider facts, identity or permission policy. |
| Outbound Communication | Outbound notification, notification intent, trigger, recipient, recipient resolution, delivery channel, delivery attempt, notification template, notification history, reminder and operational alert. | To be established through the DDD process. | Establishment, governance, workflow or access-control facts; GOV.UK Notify as an external delivery provider. |

Reference Data, Editorial Content and Outbound Communication are initial candidate bounded contexts on the same footing as the other candidates in this section. Their inclusion does not imply that any of them will become a bounded context or a separately deployed service.

## Cross-Boundary Context Map

We should make the dependencies explicit before the HLD diagrams are drawn.

```mermaid
flowchart LR
    establishment["Establishment and Establishment Group\nbounded context"]
    governance["Governance\nbounded context"]
    workflow["Data Stewardship Workflow\nbounded context"]
    access["Access Control\nbounded context"]
    readapi["External Read API\nbounded context"]
    reference["Reference Data\ncandidate bounded context"]
    editorial["Editorial Content\ncandidate bounded context"]
    outbound["Outbound Communication\ncandidate bounded context"]

    workflow -->|Requests validation and applies approved changes| establishment
    workflow -->|Requests validation and applies approved changes| governance
    workflow -->|Asks whether workflow action is allowed| access
    readapi -->|Reads governed establishment and group data| establishment
    readapi -->|Reads governed governance data| governance
    readapi -->|Asks whether read action is allowed| access
    establishment -->|Uses policy decision for protected actions| access
    governance -->|Uses policy decision for protected actions| access
    reference -.-|Relationship to be established| establishment
    reference -.-|Relationship to be established| governance
    reference -.-|Relationship to be established| workflow
    reference -.-|Relationship to be established| access
    reference -.-|Relationship to be established| readapi
    editorial -.-|Authorisation relationship to be established| access
    editorial -.-|Reference-data relationship to be established| reference
    outbound -.-|May send workflow notifications| workflow
    outbound -.-|May use domain facts for recipient resolution| establishment
    outbound -.-|May use governance facts for recipient resolution| governance
    outbound -.-|May use access decisions for protected recipients| access
```

The dotted Reference Data, Editorial Content and Outbound Communication lines show relationships that must be considered. They do not assert ownership, dependency direction, integration style or that any candidate will become a bounded context. Those conclusions will come from the DDD evidence and boundary tests. Outbound message delivery is not part of the Editorial Content candidate.

This is a starting map. We should refine it as we test the bounded contexts.

## Boundary Tests

We should test each candidate bounded context before treating it as a service boundary.

| Test | Question We Should Ask | Evidence We Should Capture |
| --- | --- | --- |
| Language test | Does this context have its own business language, or is it just a technical grouping? | Vocabulary differences, terms with different meanings, examples from source documents. |
| Ownership test | Is there a clear owner for the data and rules in this context? | Business ownership, data ownership, stewardship responsibility and decision authority. |
| Lifecycle test | Do the main entities in this context change together through a coherent lifecycle? | Lifecycle states, transitions, events and change triggers. |
| Rule consistency test | Are the rules internally consistent inside the context and different outside it? | Validation rules, policy rules, workflow rules and exception handling. |
| Transaction test | What must change atomically, and what can be eventually consistent? | Transaction boundaries, consistency needs and cross-context events. |
| Access-control test | Can Access Control make decisions across the boundary without owning domain data? | Protected resources, actions, scopes and policy attributes needed from the context. |
| Workflow test | Can Data Stewardship Workflow coordinate change without owning the domain model? | Validation and apply commands, proposed values, decision points and audit needs. |
| API contract test | Can the External Read API expose useful resources without leaking internal model details? | Consumer needs, resource shapes, versioning and anti-corruption requirements. |
| Change test | Would likely policy or organisational changes be contained mostly inside this boundary? | Change scenarios and likely blast radius. |
| Coupling test | Does the boundary reduce coupling, or does it introduce orchestration noise? | Dependency map, synchronous calls, event flows and known failure modes. |

## Staged Work Plan

### Stage 1: Gather And Normalise Evidence

We should collect the evidence already produced across the workspace and normalise it into the language needed for bounded-context design.

Inputs should include:

- Establishment and group analysis under `docs/data/extract-data`.
- Governance analysis under `docs/data/extract-data/governors`.
- Domain model and ontology analysis.
- Access-control initial analysis, vocabulary and conceptual model.
- Data-stewardship workflow initial analysis and vocabulary.
- Existing high-level service-boundary notes.
- Read API and read model assumptions from the transformation tech plan.
- Reference-data catalogues, UI usage analysis, ownership analysis and delivery options.
- Editorial content current-state analysis covering news, frontend editorial banners, FAQs, documents, content pages and glossary entries.
- Outbound communication evidence covering GOV.UK Notify, notification templates, notification sender methods, reminder flows, recipient resolution, suppression and notification history.

Output:

- Evidence notes grouped by candidate bounded context.
- Glossary conflicts and terms that need resolving.
- Initial list of assumptions and open questions.

### Stage 2: Define The Ubiquitous Language

We should define the business language for each context before we decide whether it deserves a separate service.

For each candidate context, we should capture:

- Core nouns.
- Core verbs.
- Lifecycle states.
- Business events.
- Rules and invariants.
- Terms that should not be reused across contexts.

For Reference Data, this includes distinguishing a reference dataset, classification, code, label, version, effective period, supersession and retirement. We should also identify where the same code set has different meaning or governance in different contexts.

For Editorial Content, this includes distinguishing an article, editorial banner, FAQ, document, content page, section, glossary entry, editorial grouping, presentation audience and publication state. Delivery-attempt and retry language belongs to Outbound Communication or to orphaned legacy evidence that we are not carrying into later DDD stages.

For Outbound Communication, this includes distinguishing outbound communication, outbound notification, notification intent, notification trigger, recipient, recipient resolution, delivery channel, delivery attempt, notification template, notification history, reminder and operational alert. We should treat GOV.UK Notify as a delivery channel unless the boundary tests prove EPR needs a fuller owned notification model.

Output:

- Ubiquitous-language section in the bounded-context evidence document.
- Terms that need a decision because they are overloaded or legacy-specific.

### Stage 3: Identify And Classify Subdomains

We should classify the subdomains so we know where to spend design effort.

Initial classification:

| Subdomain | Suggested classification | Rationale |
| --- | --- | --- |
| Establishment and Establishment Group | Core or supporting, to be confirmed | Central to the registry and public value of the service. Needs careful modelling because many other capabilities depend on it. |
| Governance | Supporting, with high business importance | Important, specialised and likely to have its own rules and lifecycle. |
| Access Control | Generic capability with EPR-specific policy | Authorisation is a solved architectural problem, but the protected resources, scopes and policy attributes are domain-specific. |
| Data Stewardship Workflow | Supporting capability with EPR-specific routes | Workflow engines are generic, but EPR change routes, evidence, stewardship and maker-checker rules are domain-specific. |
| External Read API | Supporting platform/product capability | Consumer contract and API product design are essential, but they should be derived from domain and consumer needs. |
| Reference Data | To be classified | Reference Data is a candidate subdomain and bounded context. Its classification will follow the same evidence gathering, language analysis and boundary testing as Establishment and Establishment Group. |
| Editorial Content | Generic or supporting, to be confirmed | Editorial publishing is common service capability, but current runtime editing, approval, audience and document requirements must be established before deciding whether EPR needs a custom context. |
| Outbound Communication | Supporting capability using generic delivery patterns, to be confirmed | Notification delivery is a common capability, but EPR-specific intent, trigger, recipient-resolution, suppression and history requirements must be tested before deciding whether this is a supporting context, thin application service or domain-owned rule set. |

Output:

- Subdomain classification with rationale.
- Areas that need deeper domain modelling before service decisions are locked.

### Stage 4: Propose Bounded Contexts

We should turn the candidate contexts into a proposed bounded-context model.

For each bounded context, we should write:

- Purpose.
- Business capability.
- Owned model.
- Owned data.
- Key rules.
- Public contracts.
- Events or commands offered to other contexts.
- Dependencies on other contexts.
- Things it explicitly does not own.

Output:

- Confluence-ready bounded-context catalogue.
- Context map showing dependencies and integration styles.

### Stage 5: Test The Boundaries

We should test the proposed boundaries against real scenarios.

Example scenarios:

- Update establishment details.
- Change an establishment group relationship.
- Add or end a governance role.
- Apply maker-checker approval to a sensitive change.
- Enforce field-level access control.
- Publish a changed record to external read consumers.
- Show public read data through the External Read API.
- Handle a rejected, returned or superseded change request.
- Add, rename, supersede or retire a shared reference-data value without breaking consuming contexts.
- Author, review, publish, expire and archive an editorial item.
- Retire or migrate a legacy editorial store while preserving required content, links and audit history.
- Send a workflow notification to a data owner after a domain event or stewardship decision.
- Send a data-freshness reminder with suppression, fallback recipient and notification-history requirements.

For each scenario, we should ask:

- Which context owns the command?
- Which context owns the data?
- Which context validates the change?
- Which context decides access?
- Which context records workflow history?
- Which context publishes or exposes the result?
- What must be synchronous?
- What can be asynchronous?
- What would be difficult if the boundary is wrong?

Output:

- Scenario-based boundary test results.
- Boundary changes or open decisions.

### Stage 6: Produce The HLD

After the bounded-context document is agreed, we should produce the HLD.

The HLD should include:

- Scope and design goals.
- Architecture principles.
- C4 system context diagram.
- C4 container diagram.
- Bounded-context diagram.
- Key runtime flows.
- Service responsibilities.
- Data ownership and persistence boundaries.
- Access-control approach.
- Data-stewardship workflow approach.
- External Read API approach.
- Reference-data ownership and publication approach.
- Editorial-content ownership, publishing and migration approach.
- Outbound-communication and GOV.UK Notify integration approach.
- Integration patterns.
- Security and audit considerations.
- Operational considerations.
- Key decisions, assumptions, risks and open questions.

## C4 Diagrams To Produce

We should use C4 to describe the HLD at the right level of abstraction.

| Diagram | Purpose | Notes |
| --- | --- | --- |
| System Context | Shows EPR, users, external systems and major external dependencies. | Good first diagram for senior stakeholders. |
| Container | Shows the main deployable or executable parts: frontend, backend APIs, domain services, workflow, access control, read API and data stores. | This should be the main HLD diagram. |
| Component, selective only | Shows internals only where a boundary needs explanation. | We should avoid component diagrams for every service unless needed. |
| Dynamic diagrams | Shows important flows such as proposed data change, approval and read API consumption. | Use sparingly to explain cross-boundary behaviour. |

## Evidence We Need Before Drawing The HLD

We should be able to answer these before the HLD is treated as more than a sketch:

- Do Establishment and Establishment Group belong in the same bounded context, or should they split?
- Does Governance need to be its own bounded context and service from the start?
- What resource model does Access Control protect across Establishment, Group, Governance, Workflow and Read API?
- What workflow state does Access Control need as decision context?
- What commands does Workflow send to Establishment and Governance services?
- What data does the External Read API own, and what does it only expose?
- Does Reference Data have sufficiently coherent language, ownership, lifecycle, rules and change patterns to form a bounded context?
- What boundaries and relationships emerge when Reference Data is tested alongside the other candidate contexts?
- Which editorial capabilities still require runtime management, and which should be source-controlled, externally published, archived or retired?
- Does retained Editorial Content have sufficiently coherent ownership, language, lifecycle and consistency rules to form a bounded context?
- How should Editorial Content use Access Control for authors and presentation audiences without owning permission policy?
- Should Outbound Communication be a small supporting context, a thin application service around GOV.UK Notify, or domain-owned notification rules using shared delivery tooling?
- Which retained notifications need EPR-owned history, suppression or recipient-resolution rules outside GOV.UK Notify?
- Which data stores are transactional stores, read models, audit stores or policy stores?
- Which flows must be synchronous, and which should use events?
- What is in scope for beta, and what is target architecture beyond beta?

## Proposed Workspace Artefacts

We should use `docs/transformation/high-level` as the workspace for these artefacts:

| Artefact | Purpose |
| --- | --- |
| `high-level-design-development-process.md` | This process document. |
| `domain-driven-design/stage-1-gather-and-normalise-evidence.md` | Stage 1 DDD evidence document. |
| `domain-driven-design/stage-2-define-ubiquitous-language.md` | Stage 2 DDD ubiquitous-language document. |
| `domain-driven-design/stage-3-identify-and-classify-subdomains.md` | Stage 3 DDD subdomain-classification document. |
| `domain-driven-design/stage-4-propose-bounded-contexts.md` | Stage 4 DDD bounded-context proposal document. |
| `analysis/editorial-content-candidate-bounded-context-analysis.md` | Raw current-state evidence for editorial content, explicitly excluding outbound message delivery. |
| `analysis/outbound-notification-code-analysis.md` | Code-led current-state evidence for legacy outbound notifications, GOV.UK Notify integration, reminder flows, recipient resolution and DDD implications. |
| `analysis/legacy-notification-catalogue.md` | Plain as-is catalogue of legacy Java GOV.UK Notify template keys and sender methods. |
| `editorial-content-bounded-context-recommendation.md` | Current recommendation for treating Editorial Content as a candidate for discovery and boundary testing. |
| `editorial-content-candidate-bounded-context-task-list.md` | Evidence, decision and architecture-update tasks for the Editorial Content candidate. |
| `bounded-context-scenario-tests.md` | Scenario-based tests for the proposed boundaries. |
| `high-level-design.md` | The eventual HLD. |
| `c4-diagrams/` | Mermaid C4 source diagrams and rendered images if needed. |

## Working Rule

We should not draw the HLD as the first design act.

We should first prove the bounded contexts using DDD evidence and scenario tests. Once those boundaries are credible, the HLD can show how the architecture supports them.
