# DDD Service Decomposition — Design Validation

## 1. Purpose and Scope

This document is a critical peer review of the domain-driven design work produced across Stages 1–4 of the GIAS 2.0 / EPR bounded-context design process, read alongside the broader transformation tech plan, access-control design, data-stewardship workflow design, coexistence design, migration overview and enterprise data model alignment work.

The review covers the documents listed in the task brief, all of which were read in full before this document was written. It does not summarise what those documents say. It identifies where the design thinking is incomplete, inconsistent or unrealistic, and what needs to be resolved before Stage 5 boundary testing or any detailed implementation design can proceed with confidence.

---

## 2. Overall Assessment

The DDD process work from Stages 1–4 is methodologically competent. It applies the right strategic DDD techniques — domain exploration, language definition, subdomain classification, bounded-context proposal and context mapping — in the right sequence and with appropriate evidence. The five proposed bounded contexts (Establishment Registry, Governance, Access Control, Data Stewardship Workflow, External Read API) are defensible as a starting hypothesis.

The problem is not with the method; it is with what the method has left unresolved. The design has reached Stage 4 carrying a substantial cluster of open questions that are treated as "to be decided in Stage 5", but several of those questions are not boundary-testing questions — they are architectural preconditions without which a boundary cannot be tested properly. Stages 1–4 have also avoided two topics that are not merely implementation detail: reference data ownership, and the relationship between the DDD decomposition and the delivery sequence implied by the strangler migration approach.

The access-control conceptual model is the strongest single design artefact in the corpus. The data-stewardship vocabulary and workflow analysis are thorough. The coexistence technical design is operationally realistic. The enterprise data model alignment document is an honest partial assessment. The tech plan documents are appropriately provisional.

The weakest areas are: (1) the External Read API as a bounded context; (2) reference data, which has no owner anywhere in the model; (3) the cross-context consistency problem between Workflow and domain services; (4) the assumptions embedded in the strangler delivery sequence that the DDD decomposition does not actually support; and (5) the near-total absence of tactical DDD.

---

## 3. Validated Strengths

**The separation of Data Stewardship Workflow from domain services is correctly derived and well-articulated.** Stage 1, Stage 2 and the workflow analysis converge cleanly on the principle that the workflow engine owns the change-request lifecycle but not the authoritative domain records. The proposed-vs-accepted-vs-applied value distinction, the maker-checker pattern and the stewardship routing pattern are all grounded in real BAU evidence. This is not just theoretical — the evidence base supports it.

**The Access Control bounded context is correctly positioned as cross-cutting, not embedded in domain services.** The access-control conceptual model is the most detailed design artefact in the corpus and correctly separates the PDP, PEP, PIP and PAP. The distinction between governance role and access-control role, and between data owner, trusted source and write permission, are important and are handled consistently across the vocabulary, approach options and conceptual model documents.

**Governance as a separate bounded context has strong evidence.** Stage 1's evidence section on governance correctly identifies that governance cannot be treated as a field set on an establishment: governance records attach to both URN (establishment-scoped) and UID (group-scoped), have a distinct lifecycle and role vocabulary, and carry privacy implications. The language work in Stage 2 reinforces this. The decision to propose Governance as a separate context from Establishment Registry in Stage 4 is justified by the evidence.

**The strangler delivery rationale is sound.** The big-bang-vs-strangler document is correct in every dimension it covers. The coexistence technical design is operationally grounded: Azure Front Door routing, the service shell contract, the IP-restriction approach for private beta, and the rollback checklist are all realistic. The acknowledgement that legacy GIAS remains the write system throughout beta is correct.

**The terminology discipline in Stage 2 is better than average.** The explicit qualification rules for `role`, `link`, `group`, `person`, `workflow` and `decision` reflect genuine insight into where cross-context language confusion creates model damage. Maintaining this discipline will require active management but the vocabulary documents provide a usable foundation.

---

## 4. Blindspots and Gaps

### 4.1 Reference Data Has No Owner

**The gap.** Establishment types, local authority codes, country codes, governance role types, link types, group types, SEN provision types and every other controlled list appear as inputs to the Establishment Registry, Governance, Access Control, Workflow and External Read API contexts. Not one document in the corpus identifies a bounded context that owns reference data. Stage 1 raises it as an open question ("Should reference data be owned inside Establishment/Governance contexts or treated as a separate supporting context later?") but then parks it without resolution. Stages 2, 3 and 4 do not revisit it. The tech plan (section 09) mentions "reference and classification data" as a data domain requiring attention but does not assign ownership.

**Why it matters.** Reference data is not a marginal concern. Establishment type is a policy attribute in Access Control decisions. It drives field applicability in the Establishment Registry. It determines which governance model applies. It affects read API representation. If reference data is owned by the Establishment Registry, then every other context depends on that context for what are effectively system-wide lookup values. If it is distributed, no one is responsible for lifecycle, versioning, archiving of retired codes or consistency. The access-control conceptual model's `ResourceType`, `Action` and `DataClassification` vocabularies are themselves reference data — who owns those? Stage 1 explicitly acknowledges that "reference data appears throughout establishment, group, governance, access-control and workflow rules", which makes the absence of any ownership decision all the more striking.

**Recommendation.** Before Stage 5, a decision is needed: either Reference Data is a subdomain that deserves its own lightweight bounded context (or at least a named owner and a published contract), or it is explicitly assigned to the Establishment Registry with defined APIs that other contexts consume. The lifecycle questions — who can create a new establishment type, what happens when a code is retired and legacy data still references it, how are code lists versioned — need an answer that is consistent with the boundary model. This is not a detail; it directly affects every boundary test in Stage 5.

---

### 4.2 The External Read API Is Not a Bounded Context in DDD Terms

**The gap.** The External Read API is proposed as a bounded context in Stage 4, but it fails the core DDD test for a bounded context: it does not own a domain model with its own language, invariants and rules. What it owns, as described in Stage 4, is "API contract definitions and versions, consumer-facing resource shapes, API documentation and compatibility rules" and — tentatively — "read-facing cache or projection ownership, if we decide this context owns read projections."

A bounded context exists where a model must be internally consistent. A contract boundary, an API management boundary, a product boundary, and a bounded context are different things. The External Read API is a product/contract layer that translates representations from domain contexts into stable consumer-facing shapes. That is closer to an anti-corruption layer or a published language implementation than a bounded context.

Stage 2 says "External Read API is a candidate bounded context or at least a distinct contract boundary." Stage 3 classifies it as a "supporting product/API subdomain." Stage 4 calls it a bounded context anyway. Stage 1 explicitly flags this as unresolved: "Is External Read API a bounded context or a product/API boundary over the read model?"

The conceptual model document (stage 4) makes the tension visible: "Read-facing cache or projection ownership, if we decide this context owns read projections." If it does not own projections, it owns only a contract — which is an API management concern, not a domain concern. If it does own projections, then who builds those projections, from what events, with what freshness guarantee, and what happens when the projection is wrong?

**Why it matters.** Calling the External Read API a bounded context muddies the Stage 5 boundary tests. The test scenarios in stage 5 ask: "Which context owns the data? Which context publishes or exposes the result?" If the External Read API is a bounded context, the answer to "who publishes" is straightforwardly it. But that answer hides a real question: does the read API own a projection store, or is it a pass-through to projections owned by the domain contexts? The answer has architectural consequences — particularly for data freshness, write-side publication patterns, and who gets paged when the read API is serving stale data.

**Recommendation.** Clarify before Stage 5: is the External Read API a bounded context with its own projection store and domain model, or is it a product/API layer whose job is to expose stable contracts over read models owned by the Establishment Registry and Governance contexts? If the latter, remove it from the context map as a peer context and redesign it as an anti-corruption adapter or consumer-side translation layer. This matters most for the data architecture decision about how approved changes in domain contexts are published into consumer-visible representations.

---

### 4.3 The Workflow-to-Domain Consistency Model Is Incomplete

**The gap.** The design correctly establishes that Workflow calls domain services to validate and apply approved changes. But it does not resolve the consistency model when that apply call happens. Specifically:

- What is the behaviour if the domain service is unavailable when Workflow tries to apply an approved change?
- What is the behaviour if the domain service accepts the apply call but then emits a domain event indicating a constraint violation?
- What happens if a change request is approved by the checker while a conflicting change is simultaneously applied through a different path (e.g. a trusted-source auto-apply)?
- How does Workflow know that the value it accepted is still the current value when it tries to apply? The workflow holds `CurrentValue` at the time of request — but what if the current value has changed between the time the change was submitted and the time it is applied?

Stage 4 proposes "Synchronous command with domain audit, or reliable asynchronous command where needed" for workflow-to-domain apply. Stage 2 notes "Workflow must coordinate changes across domain service boundaries without owning the authoritative domain records." Neither addresses the race condition or the idempotency problem. The data-stewardship workflow analysis is thorough on workflow state management but does not engage with cross-context consistency or conflict detection.

The access-control conceptual model correctly notes that domain services enforce decisions, not the access-control component. But the model does not specify what happens to the workflow audit trail if the apply step fails — a scenario that is operationally common and has real implications for steward trust in the system.

**Why it matters.** This is not a theoretical edge case. In a system with 270,000+ governance rows and an active MAT governance lifecycle, concurrent modification conflicts will occur. If the apply protocol is not idempotent and the failure handling is not specified, the result is either workflow records showing "applied" for changes that were silently not applied, or a support burden that requires manual inspection of domain state to determine whether a workflow completed. The proposal to have Workflow call domain services synchronously for apply is reasonable at beta scale but needs an explicit answer to what "reliable asynchronous command where needed" means in practice.

**Recommendation.** Before Stage 5, document the apply protocol: what Workflow sends to a domain service, what the domain service returns, what Workflow does on failure (retry, escalate, mark as verification-failed), and how conflict detection works when the current value has changed since the change request was submitted. This should be part of the `Verify` stage in the workflow state machine, which the vocabulary defines but which the integration design has not operationalised.

---

### 4.4 The PDP Attribute Supply Problem Is Not Solved

**The gap.** The access-control conceptual model is well-designed. The problem is the Policy Information Point: who supplies the attributes the PDP needs, how, at what latency, and at what freshness?

The model describes `RequestAttribute` as "facts supplied for the decision, such as provider type, local authority, workflow state from the workflow engine, or field classification." But this description assumes the calling service has all these facts ready at request time. Consider a realistic scenario: a user attempts to edit a governance appointment. The PDP needs: actor's role and organisation scope (from Access Control's own store); the governance appointment's resource type (from Governance); the establishment type of the linked establishment (from Establishment Registry); the current workflow state if there is a pending change request (from Workflow); and the data classification of the field being edited (from Access Control's attribute store). That is four cross-context reads before the PDP can return an allow/deny decision.

The access-control design documents say "Access Control evaluates domain facts but does not own them" and "Keep domain facts in domain services unless there is a clear decision-performance reason to replicate them." But the conceptual model has an open question: "How much domain context should be replicated into the access-control component?" — and this remains unresolved.

At beta scale with limited concurrent users, the latency cost of multi-context attribute assembly may be acceptable. But the design does not acknowledge the problem, which means it will be discovered under load rather than addressed in the design.

**Why it matters.** The access-control approach options document correctly identifies that ABAC requires attributes about actor, resource, action and environment. But supplying those attributes across service boundaries in real time has latency, availability, and cache-invalidation implications. If the PDP blocks on a synchronous call to Establishment Registry to get the establishment type before it can make an access decision, and the Establishment Registry is briefly unavailable, then every protected action across the system fails. The design says nothing about the availability contract of the PDP or what happens when attribute sources are unavailable.

**Recommendation.** Before Stage 5, define the attribute supply model for at least the top three most-complex access-control scenarios (e.g. edit governance appointment, approve a change request, submit a change for a restricted field). For each, identify: which attributes are needed, which context owns them, whether they can be cached in the calling service, and what the failure mode is if an attribute source is unavailable. This is essential information for the Stage 5 coupling tests.

---

### 4.5 The Strangler Delivery Order Does Not Follow from the Boundary Decomposition

**The gap.** The strangler migration overview proposes a delivery sequence: (1) foundation, (2) Establishments and Groups Read, (3) Governance Read/Write, (4) Exports, (5) Establishments and Groups Write. The big-bang-vs-strangler document advocates iterative strangler delivery. Both are correct in principle.

But the DDD decomposition in Stage 4 proposes five bounded contexts: Establishment Registry (combined establishments and groups), Governance, Access Control, Data Stewardship Workflow, and External Read API. These are not decomposed along the same lines as the strangler sequence. The strangler sequence treats Governance Read/Write as Step 3 — implying Governance can be extracted before Establishment/Group writes. But Stage 4's Governance context depends on Establishment Registry for identity references (URN, UID, Companies House number). If Establishment Registry has not yet committed writes to GIAS 2.0 when Governance Read/Write migrates, what is Governance pointing its identity references at? Legacy data? Migrated-but-read-only data? The dependency arrow in Stage 4's context map from Governance to Establishment Registry becomes a live coexistence problem that is not addressed.

Similarly, the migration overview names "Exports" as Step 4 — but exports are not a bounded context in the Stage 4 design. The DDD work has no Exports context. The migration overview names it; Stage 4 does not model it; the tech plan (section 10) treats it as part of data movement and reconciliation. This is a genuine structural gap between the migration sequencing and the DDD decomposition.

The R12 and R13 risks in the risks register are aware of the problem: "Establishment and group write cutover is treated as the automatic next step after Find/Share" and "Governance and Export carve-outs are not assessed early enough." But noting the risk is not the same as resolving the design tension.

**Why it matters.** If the delivery team implements services in the order implied by the strangler sequence, but the bounded context design has not resolved the dependencies between them, each new service either has to tolerate stale cross-context data (with undefined freshness guarantees) or call back into the legacy system (introducing a dependency the strangler pattern is supposed to eliminate). The "anti-corruption protects the new model from the legacy model" principle in the migration overview is correct, but it requires the anti-corruption layer to be designed — which the DDD documents do not do.

**Recommendation.** Produce an explicit strangler-sequence-vs-bounded-context mapping table before Stage 5. For each migration step in the strangler sequence, identify: which bounded context or contexts are being extracted, which dependencies must be in place, what the anti-corruption layer translates, and what the fallback is if the dependency context is not yet live. This table will expose the real delivery ordering constraints that the DDD decomposition implies but does not state.

---

### 4.6 Notifications, Push Feeds, Operational Integrations and Extracts Have No Context

**The gap.** GIAS has downstream consumers: DfE internal systems (schools digital, teacher services, UKRLP reconciliation, Ordnance Survey geocoding), the legacy extract and download infrastructure, and the current SOAP/REST APIs consumed by external bodies. The migration overview mentions these: "REST APIs, SOAP interfaces for External Consumer and internal DfE integrations, Extract & Download Services, Batch & Scheduled Jobs, Reference-data integrations such as Companies House, UKRLP, GOV.UK Notify and Ordnance Survey."

None of these appear as a bounded context, a dependency, or a named responsibility in the DDD design (Stages 1–4). The context map in Stage 4 shows the External Read API consuming from Establishment Registry and Governance, but it does not show outbound push feeds, scheduled extract generation, notification delivery to downstream systems, or inbound reference-data enrichment from UKRLP or Ordnance Survey.

The tech plan section 10 on integration and data movement covers the inbound path (legacy GIAS database to read model), but says nothing about outbound integrations or what happens to existing DfE consumers when GIAS 2.0 begins serving different data. The read API scope and audience document (section 07) notes "existing SOAP/REST interfaces" as a consumer risk but defers the decision.

The R04 risk ("User-facing coexistence between legacy GIAS and GIAS 2.0 is not designed") is in the risk register, and D05 ("Confirmed user-facing coexistence and journey-transition model") is a listed dependency. But the broader integration coexistence problem — including downstream data consumers and scheduled extracts — is not risk-registered at all.

**Why it matters.** GIAS data is consumed by external organisations who cannot simply wait for GIAS 2.0 to reach feature parity. If the legacy extracts and SOAP/REST APIs are not mapped onto GIAS 2.0 bounded contexts, there is no clear route for migrating those consumers. The strangler principle is "move consumers before turning off providers" — but you cannot move consumers to a bounded context that does not exist in the design.

**Recommendation.** Add at least a named capability (if not a full bounded context) for Extracts and Outbound Integrations before Stage 5. For each existing downstream integration, identify: which bounded context owns the data it needs, what migration path exists for that consumer, and whether the External Read API can serve it or whether a separate publishing pattern is required. The GOV.UK Notify integration (governance change notifications) and the UKRLP enrichment feed are specific cases that have no home in the current design.

---

### 4.7 Audit, Monitoring, Logging and Rate Limiting Are Cross-Cutting Concerns Without an Owner

**The gap.** Every bounded context needs audit, structured logging, rate limiting and monitoring. The access-control conceptual model handles access decision audit well. The workflow vocabulary handles workflow audit well. But cross-cutting operational concerns — application-level audit logging, centralised structured log aggregation, rate limiting on the read API and the BFF, alerting thresholds, and observability design — appear implicitly in several documents without being assigned to any bounded context or named owner.

The coexistence technical design (edge-routed-coexistence-technical-design.md) has the most concrete observability content: structured log fields, alert thresholds, dashboards. But this is specific to the coexistence routing layer, not to the service internals.

The security, access and governance document (section 12) lists audit events that must be captured, but does not say where audit event storage lives or who queries it for support and compliance purposes. The data architecture document (section 09) mentions "Audit and lineage requirements for loads, transformations, API access and user-visible changes" but does not assign ownership.

In a DDD context, this is the classic cross-cutting concern problem: audit is not a bounded context itself, but it must be consistently implemented across all contexts and some of its outputs (decision audit, domain change history, workflow history) have different ownership and retention requirements.

**Why it matters.** At private beta, the absence of a clear audit model is a service assessment risk. At live, it is an information governance and DPIA risk. The access-control conceptual model explicitly differentiates domain change history (owned by domain contexts) from access decision audit (owned by Access Control) from workflow history (owned by Data Stewardship Workflow). This tripartite structure is correct but means that producing a coherent audit trail for a single change event requires correlating records from three different stores. The design does not say how that correlation works in practice.

**Recommendation.** Define an audit event taxonomy before Stage 5 that maps: each category of auditable event, which context emits it, what the retention requirement is, how correlation identifiers work across context boundaries, and how support teams can produce a coherent change history for a single establishment. This is a Stage 5 prerequisite for the audit boundary test scenarios.

---

### 4.8 The "Public Beta is Read-Only" Assumption Creates an Invisible Design Debt

**The gap.** Multiple documents repeat: public beta is read-oriented; create/change comes after public beta. This is correct as a delivery scope decision and the 26 May clarification confirms it. But the design treats this as a simplifying assumption without acknowledging the structural consequences.

Authenticated read access is already in scope for public beta (governor email addresses, non-public establishment data). Authenticated read access requires: identity and authentication, role-based scope, field-level classification, access decisions from the PDP, and audit of what was read. This is almost the full access-control model. The only thing that is different from write access is that the workflow context is not involved.

But the design — particularly the tech plan (section 12) — says "The `Find`, `Share` phase can start with anonymous/public journeys, but the target architecture must leave space for authenticated users and controlled data maintenance." It does not say how that space is left. The access-control conceptual model is full-featured, but it is not phased. Which parts of it need to be implemented for authenticated read, and which parts can wait for write?

Similarly, governance data is PII-containing data that is publicly visible in parts (role, establishment) but sensitive in other parts (email addresses, appointment dates, person identity). The public beta deliverable document says "Governance data that is approved for public release." But who approves what for public release, using what process and what access-control model, is not defined.

**Why it matters.** If the team treats public beta as "just read, access control is simple", they will build access control for anonymous reads and then be forced to retrofit field-level, organisation-scoped, authenticated-user access control on top of it when write journeys begin. That retrofit is expensive and is exactly the pattern the access-control design is intended to prevent. The risk R08 in the risk register ("Public/open data boundaries and authenticated access requirements are not agreed early enough") is already flagged, but the DDD design has not closed it.

**Recommendation.** Before Stage 5, define the minimum access-control implementation required for authenticated read access in public beta, including: which fields are public, which fields require authentication, which fields require authentication plus organisation scope, and which fields require authentication plus access decision from the PDP. This scopes the access-control build work and avoids the retrofit problem.

---

### 4.9 Tactical DDD Is Absent

**The gap.** The design is entirely strategic DDD. There is no tactical DDD: no aggregates, no aggregate roots, no domain events defined at the entity level, no value objects, no domain services within contexts, no factories, no repositories (beyond the implicit assumption that each context has one). Stage 4 defines "owned model" for each context but does not ask what the aggregate boundaries are within those owned models.

This matters most for the Establishment Registry. The owned model includes: establishment, establishment type, establishment status, establishment identifiers, establishment details, establishment location, establishment link, establishment group, group membership, group relationship, and children's-centre lead-centre role. That is a large surface. Without aggregate boundaries, the implementation team will either treat the whole establishment as one large aggregate (which creates concurrency and performance problems) or create multiple smaller aggregates with unclear consistency boundaries (which creates the same problems the bounded context design is trying to avoid).

For Governance: is a GovernanceAppointment an aggregate root? Or is GovernancePerson the aggregate root with appointments as child entities? If a MAT has 50 trustees and a workflow updates one, what locks? What events are emitted?

For Access Control: a PolicyDocument/PolicyVersion is clearly an aggregate. But is an AccessDecision a separate aggregate, or is it an entity within the PolicyVersion aggregate? The conceptual model stores them separately, which is correct, but the tactical design implications of that choice are not explored.

**Why it matters.** Without aggregate boundaries, Stage 5 scenario tests will produce correct-sounding answers about which context owns a command, but the answers will be too coarse to validate the implementation design. The transaction boundary test in the process document asks "What must change atomically, and what can be eventually consistent?" — this is precisely an aggregate boundary question. Stage 5 cannot answer it without tactical DDD inputs.

**Recommendation.** Before Stage 5, define the principal aggregates for Establishment Registry and Governance at minimum. For each aggregate, identify the aggregate root, the consistency boundary, the domain events emitted on state change, and the invariants enforced. This does not need to be complete — but the two or three most complex aggregates in each context (e.g. Establishment, GroupMembership, GovernanceAppointment) should be defined enough to test the "what must change atomically" question in Stage 5.

---

### 4.10 The EPR Model Is Only Partially Aligned to the Enterprise Data Model — and That Matters

**The gap.** The enterprise data model alignment document is honest: the EPR model is "partially aligned and broadly compatible, but not formally aligned." The `Person` and `Role` patterns from the EDM are not implemented in the EPR ontology, even though governance appointments, headteacher records, and trust contacts are all person-holding-a-role patterns that will need to align to the EDM if cross-DfE integration is a target.

Stage 2 defines `GovernancePerson` as a working term and explicitly says it "may overlap with identity and user-account modelling." Stage 4's Governance context owns "Governance people and identity data needed for governance records" but does not say how this aligns to either the EDM person model or the access-control actor model.

If a governance person is also a DfE Sign-in user (e.g. a governance professional with a system account), the Governance context must not model them as a simple person record without considering how their identity resolves to an authenticated actor in the access-control model. This is not a theoretical problem: the current GIAS already has disabled-account synchronisation evidence (referenced in section 12 of the tech plan).

**Why it matters.** If the Governance context models GovernancePerson as a simple data object with no connection to the identity and access layer, then adding system access for a governance role-holder (a likely post-beta requirement) will require re-modelling rather than extension. The EDM recommendation (from the alignment document) to use the Person/Role/Organisation pattern before expanding into named people is correct, but it has not been fed back into the bounded-context design.

**Recommendation.** Before Stage 5, resolve the GovernancePerson identity question: is a governance person always a named individual with no system access, or can a governance person hold a system account? If the latter, how does the Governance context's person model relate to the access-control Actor model? Define the relationship — even if it is "separate data, correlated by identity provider subject identifier" — before the Stage 5 governance appointment scenarios are tested.

---

### 4.11 The Context Map Has Missing and Possibly Incorrect Arrows

**The gap.** The Stage 4 context map shows the following dependency arrows:

- Workflow → Establishment Registry (validate and apply)
- Workflow → Governance (validate and apply)
- Workflow → Access Control (workflow action allowed?)
- Establishment Registry → Access Control (protected establishment action allowed?)
- Governance → Access Control (protected governance action allowed?)
- External Read API → Establishment Registry (read governed data)
- External Read API → Governance (read governed data)
- External Read API → Access Control (read action allowed?)
- Governance → Establishment Registry (reference establishment identity)
- Access Control → Establishment Registry (use domain attributes for policy decisions)
- Access Control → Governance (use governance attributes for policy decisions)

Missing or potentially incorrect:

1. There is no arrow from Establishment Registry to Workflow or Governance showing domain events published after a successful apply. If domain events are the mechanism for eventual consistency (as implied in Stage 4's integration style table), the arrows should show them.
2. There is no arrow showing how the External Read API is notified of changes to expose. The "May react to domain events from Establishment Registry and Governance" in Stage 4 is tentative where it should be specified — because this is the critical path for data freshness in the read API.
3. The Access Control arrows (to Establishment Registry and Governance for policy attributes) are drawn in the wrong direction for a PULL model. In the proposed design, domain services supply attributes to the PDP when they make a decision request. The arrows should show domain services → Access Control (supplying attributes WITH the decision request), not Access Control → domain services (which would imply the PDP pulling attributes on demand). This is architecturally important: a pull model creates the availability coupling described in gap 4.4; a push/supply model avoids it.
4. There is no arrow from any context to a Notifications or downstream integration capability — because, as gap 4.6 notes, that capability does not exist in the model.

**Why it matters.** Context map arrows in DDD are meant to show dependency direction and integration style. Incorrect or missing arrows lead to incorrect Stage 5 scenario tests. If the team tests "Update establishment details" using a context map that doesn't show the domain event path from Establishment Registry to External Read API, they will get an incomplete test result.

**Recommendation.** Before Stage 5, revise the context map to: (a) add domain event arrows from domain contexts to consumers; (b) clarify whether Access Control pulls attributes or receives them in decision requests; (c) explicitly model the downstream notification and integration path, even if labelled "TBD context" for now; (d) distinguish synchronous from asynchronous arrows.

---

### 4.12 The Distinction Between Event-Driven Integration and Event Sourcing Is Not Made

**The gap.** The design occasionally hints at event-driven integration but never makes the distinction between publishing domain events for integration purposes and using event sourcing as a persistence pattern explicit. Stage 4 says Establishment Registry and Governance should "Publish domain events where downstream contexts need eventual consistency." The External Read API "May react to domain events." But "domain events" in DDD can mean either:
- A notification emitted after a state change, consumed by other contexts (integration event)
- The sole source of persistence, with current state derived by replaying the event log (event sourcing)

These are architecturally very different patterns. Event sourcing has significant implications for the Establishment Registry in particular: with 40+ establishment types, type-sensitive fields, and complex lifecycle link semantics, an event-sourced aggregate would require careful event schema design and versioning. The design gives no indication of whether event sourcing is considered, and the data architecture (section 09) proposes PostgreSQL as the persistence layer, which is consistent with a traditional state-based persistence model.

If the design intends only integration events (which is the simpler and more likely interpretation), it should say so. The silence creates a design ambiguity that an implementation team will resolve arbitrarily.

**Why it matters.** At beta scale, with relatively low write volume and short development timelines, event sourcing would be disproportionate complexity. Integration events published after state changes are appropriate. But if this is not stated, a team member who reads "publish domain events" may make a different architectural choice. The distinction also matters for the Workflow-to-domain apply step: if the domain context applies a change by handling a command and publishing a domain event, the workflow context can subscribe to that event to confirm the apply step succeeded. If the domain context just returns a success response, the workflow has to trust the response without an independent verification mechanism.

**Recommendation.** State explicitly in the integration assumptions that domain events in this design mean integration events — notifications published after successful state change — not event sourcing. Specify the minimum content of those events (aggregate identity, event type, timestamp, version) so that the Stage 5 scenario tests can validate that downstream consumers receive enough information to act.

---

## 5. Cross-Cutting Risks

**Data freshness under coexistence.** The coexistence technical design correctly notes that legacy GIAS and the GIAS 2.0 read model "are not automatically consistent." But during beta, users who change data in legacy GIAS and then search in GIAS 2.0 may see stale results. The staleness window is described as "15 minutes – 1 hour" with more frequent ETL. This is operationally manageable for read journeys, but it becomes a support and trust problem if the data a user changed in legacy GIAS does not appear in GIAS 2.0 within a reasonable time. The design proposes a staleness indicator but does not mandate it. That decision should be made before private beta.

**The beta bounded-context design does not match the post-beta design.** For beta, the architecture is: legacy GIAS (write) → ETL pipeline → PostgreSQL read model → BFF and Read API. The bounded contexts in Stages 1–4 describe the post-beta target architecture. These two models are not the same. The DDD decomposition is the target; the beta delivery is an intermediate step. This is understood, but the connection between them is not explicit in any single document. The risk is that the beta architecture encodes assumptions (e.g. the read model is flat and denormalised; there is no Workflow context; the Establishment Registry and Governance contexts are not yet services) that make the later transition to the target architecture harder than expected.

**Access control is needed from day one of authenticated access, but the design defers it.** The design acknowledges that the access-control model is complex and that beta focuses on read. But public beta includes authenticated read access to non-public data, which requires a functional, tested access-control implementation — not a full ABAC model, but at minimum: identity, role, organisation scope, and field classification. The decision DEC10 ("Security and access model") is listed as Open in the risk register. If this decision remains open past private beta build, authenticated read access will either be delayed or built on ad hoc foundations that the DDD design explicitly says should be avoided.

**The bounded-context design has no operational model.** None of the DDD documents address how each bounded context will be operated in production: which team owns it, what its SLA is, what its escalation path is, how its data is backed up, who runs its migrations. The strangler migration overview mentions "support and administration tooling should be part of phase planning" but this has not been connected to the bounded-context design. For Governance in particular, with sensitive PII and an active maintenance user population, the operational model is not optional.

---

## 6. Recommended Next Design Actions (Prioritised)

These are ordered by their criticality as prerequisites for Stage 5 or for beta delivery. Items 1–4 are blocking for Stage 5 boundary tests. Items 5–8 are required before implementation design can begin.

**1. Define reference data ownership.** Decide whether reference data is a bounded context, a responsibility of Establishment Registry, or distributed across contexts with a defined publication contract. Document the lifecycle model for creating, retiring and versioning reference data values. This resolves a cross-cutting dependency that affects every Stage 5 boundary test.

**2. Resolve the External Read API question.** Decide whether the External Read API is a bounded context with its own projection store, or a product layer over projections owned by domain contexts. If the latter, redesign it as a consumer-side adapter and remove it from the peer context map. Define who builds and owns the read projections and how they are triggered on domain state changes.

**3. Define the attribute supply model for the PDP.** For the three most complex access-control scenarios, identify every attribute required for an access decision, which context owns it, and how it reaches the PDP. Define the failure mode when an attribute source is unavailable. This is needed before the Stage 5 access-control boundary test can be run.

**4. Correct and extend the Stage 4 context map.** Add domain event arrows from domain contexts to downstream consumers. Clarify the direction of attribute supply to the PDP. Add a provisional "downstream integration" node for outbound feeds and extracts. Mark arrows as synchronous or asynchronous.

**5. Define aggregate boundaries for Establishment Registry and Governance.** For each context, identify the principal aggregates, their roots, their consistency boundaries, and the domain events they emit. This is needed before Stage 5 transaction boundary tests can be run and before implementation design can begin.

**6. Specify the workflow apply protocol.** Document what Workflow sends to domain services on apply, what domain services return, and what Workflow does on failure, timeout or conflict. Define how Workflow detects that the current value has changed since the change request was submitted.

**7. Produce the strangler-to-bounded-context mapping.** For each step in the migration sequence, identify which bounded contexts are being extracted, which cross-context dependencies must already be in place, and what the anti-corruption layer translates from legacy GIAS. This resolves the structural gap between the migration sequence and the DDD decomposition.

**8. Define the minimum access-control implementation for authenticated read (public beta scope).** Specify which fields require which level of access control for authenticated read journeys. Define the PDP scope for public beta. This prevents the read-access implementation from being built on assumptions that create retrofit costs when write journeys begin.
