# Additional Bounded Context Candidates

## Purpose

This document identifies two bounded context candidates that have not yet been classified and recommends they are added to the subdomain map before bounded context design proceeds.

Both candidates are evidenced in the legacy estate. Neither is named in the existing subdomain classification. Their omission is not a deliberate design decision — it is a gap in the evidence sweep.

Stage 4 will make the bounded-context boundary decisions for both.

---

## Candidate 1: Bulk Data Publication

### Why It Is Missing

The current subdomain classification names External Read API for programmatic, versioned, on-demand read contracts. Bulk Data Publication is a different capability: it produces scheduled, file-based data extracts consumed by statisticians, researchers, operational teams and downstream DfE systems. It is not the same thing as an on-demand API.

The legacy estate contains substantial evidence for this capability, but it was not separated from the External Read API candidate during the evidence normalisation pass.

### Evidence

| Evidence | What it shows |
| --- | --- |
| `DataOpsJobs` schema — multiple active tables | A dedicated schema for scheduled data processing and extract jobs. Not all tables had observed 30-day activity, but several are clearly operational. |
| `gias_sharing` schema — 7 tables with observed activity | A schema used for data-sharing output, distinct from the main `dbo` transactional schema. Indicates a publication or sharing output concern. |
| Scheduled extract failure notification type in legacy `NotificationSender` | A named notification intent — `scheduledExtractFailureEmail` — treated as a distinct business event with its own recipient and template. Delivery failure is a business concern, not just infrastructure noise. |
| `DataOpsJobs.Ofsted_GIASProdExtract` | Evidence that extract production and preparation involves its own staging and processing tables. |
| `DataOpsJobs` tables for school census, exclusion lists and postcode updates | Extract machinery includes both inbound and outbound data processing, confirming that the DataOpsJobs schema covers a wide operational data-movement surface. |
| Distinct field inclusion rules in current GIAS extracts | The public and restricted establishment extracts expose different field sets under different access conditions. These are extract-specific decisions, not API contract decisions. |

### Normalised Capability

Bulk Data Publication is the capability for producing governed, scheduled data extracts that are made available as files for bulk consumption.

The key concepts that belong to this capability are distinct from External Read API:

| Concept | Meaning |
| --- | --- |
| Scheduled extract | A file-based dataset produced on a defined schedule and made available for download or onward transfer. |
| Extract job | The process that produces a scheduled extract, including execution, failure and retry. |
| Extract format | The file structure, column order, encoding and field definitions that consuming systems depend on. |
| Field inclusion rule | The rule that determines which establishment or governance fields appear in which extract, under which access conditions. |
| Sensitivity classification | The classification of extract content as public, restricted or protected, applied per-field and per-extract. |
| Extract consumer | A downstream system, team or data user that depends on extract format stability and publication schedule. |
| Publication schedule | The expected cadence of extract availability, including the consequences of missed or failed runs. |
| Extract audit | The record of when an extract was produced, what it contained and whether it was successfully published. |

### Classification Recommendation

| Aspect | Assessment |
| --- | --- |
| Business value | Medium to high supporting value. Downstream consumers depend on extract stability. |
| Domain specificity | Medium. Field inclusion rules and sensitivity classification are EPR-specific; batch machinery and file production are generic. |
| Rule complexity | Medium. The rules are mainly around which fields are included for which consumer under which access conditions. |
| Availability of standard patterns | High for batch processing and file transfer infrastructure. Low for EPR-specific field inclusion and access rules. |
| Recommended classification | Supporting subdomain using generic batch and file-transfer patterns. |

### What Stage 4 Must Decide

- Whether Bulk Data Publication is a small supporting bounded context or a thin application service owned alongside External Read API.
- Which context owns field inclusion rules and sensitivity classification — Bulk Data Publication, or the owning domain context (Establishment Registry, Governance)?
- Whether the extract failure notification intent belongs to Bulk Data Publication or to Outbound Communication.
- How extract format stability and versioning is governed when domain models change.

---

## Candidate 2: External Data Ingest

### Why It Is Missing

GIAS receives data from external authoritative sources — Ofsted inspection records, school census returns, administrative geography updates and UKPRN allocations. This ingest has its own lifecycle, reconciliation rules and authority model that is not owned by Establishment Registry.

The legacy estate contains clear staging tables and processing machinery for ingest, but this was treated as infrastructure evidence during the evidence normalisation pass rather than as a domain capability.

### Evidence

| Evidence | What it shows |
| --- | --- |
| `DataOpsJobs.Ofsted_FurtherEducation`, `Ofsted_GIASProdExtract`, `Ofsted_IndependentSchools`, `Ofsted_StateFunded` | Staging tables for inbound Ofsted inspection data, partitioned by inspection type. These are not the domain records — they are ingest intermediaries. |
| `DataOpsJobs.GIAS_IEBTSchoolCensus`, `GIAS_IEBTSchoolCensus_Updates`, `GIAS_SchoolCensus`, `GIAS_SchoolCensus_Updates` | Staging tables for school census data, including update deltas. Confirms an ingest pipeline with update reconciliation behaviour. |
| `DataOpsJobs.pcd_pcon_uk_Import` | Ingest staging for postcode and parliamentary constituency geography data from an external source (ONS or equivalent). |
| `DataOpsJobs.HE_to_add_to_GIAS` | A staging table for higher-education institutions to be added to the registry from an external source. |
| `MasterProvider` schema — 2 tables with observed activity | A dedicated schema for the UKPRN master register. Provider reference number allocation and master-register reconciliation is a separate concern from establishment identity owned by GIAS. |
| Vocabulary model — `epr:AccreditationAndQualityAssurance`, `epr:OfstedInspectionRecord`, `epr:SectionNinetyOneOfstedRecord` | The EPR vocabulary explicitly models Ofsted inspection outcomes as establishment data. Something must get that data from Ofsted into the registry. |
| `DataOpsJobs.NullCodeFieldEstablishments` | Evidence of a data quality processing step that runs against inbound data, suggesting the ingest surface has its own validation pass distinct from domain validation. |

### Normalised Capability

External Data Ingest is the capability for receiving authoritative data from external sources, validating it against EPR rules, reconciling it with the existing registry, and either applying it directly or initiating a stewardship workflow.

The key concepts that belong to this capability are:

| Concept | Meaning |
| --- | --- |
| External source | An authoritative body — Ofsted, DfE census, ONS, Companies House, UKPRN register — that supplies data EPR uses. |
| Ingest event | A discrete delivery of data from an external source, either scheduled or triggered. |
| Ingest record | A unit of data received from an external source before reconciliation with the registry. |
| Reconciliation | The process of comparing an ingest record against the current registry state and deciding what to do. |
| Source authority | The rule that determines whether an external source can overwrite a registry value, trigger a workflow or be rejected. |
| Conflict | A case where ingest data disagrees with an existing authoritative value and a resolution decision is needed. |
| Ingest outcome | The result of reconciliation — applied directly, routed to stewardship workflow, rejected or flagged for review. |
| Ingest audit | The record of what was received, when, from which source, and what was done with it. |

### Classification Recommendation

| Aspect | Assessment |
| --- | --- |
| Business value | High supporting value. Ofsted inspection outcomes and census returns are operationally critical and often time-sensitive. |
| Domain specificity | Medium to high around reconciliation and source authority rules; low around the ETL mechanics. |
| Rule complexity | Medium to high. Source authority, conflict resolution and the decision to apply directly versus route to workflow are EPR-specific decisions. |
| Availability of standard patterns | High for ETL tooling and pipeline infrastructure. Low for EPR-specific authority and reconciliation rules. |
| Recommended classification | Supporting subdomain using generic ETL and pipeline patterns, with EPR-specific authority and reconciliation rules. |

### Key Boundary Distinction

External Data Ingest must not become part of Establishment Registry even though it supplies data to it. The two contexts have different models and lifecycles:

- Establishment Registry owns authoritative establishment and group records. It enforces domain rules and serves as the source of truth.
- External Data Ingest owns the pipeline for receiving, staging, validating and reconciling external data before it reaches the registry. It must know source authority rules and conflict-resolution policy.

If ingest is absorbed into Establishment Registry, the registry becomes responsible for ETL logic, pipeline failure, retry, external source formats and ingest audit — concerns that are operationally distinct from managing an authoritative domain record.

### What Stage 4 Must Decide

- Whether External Data Ingest is a small supporting bounded context or a platform/infrastructure capability that sits outside the domain boundary map.
- Which context owns source authority rules — External Data Ingest, or Establishment Registry?
- Whether the ingest-to-workflow handoff is a command from External Data Ingest to Data Stewardship Workflow, or whether domain events from an accepted ingest trigger workflow independently.
- How `MasterProvider` / UKPRN master register integration relates to establishment identity in Establishment Registry.
- Whether geography ingest (postcode, LSOA, MSOA, parliamentary constituency) belongs to this subdomain or to reference data owned by Establishment Registry.

---

## Summary

| Candidate | Proposed classification | Confidence | Boundary decision needed in Stage 4 |
| --- | --- | --- | --- |
| Bulk Data Publication | Supporting using generic batch and file-transfer patterns, to be confirmed | Medium | Yes: decide whether this is a supporting bounded context or a thin application service alongside External Read API; decide ownership of field inclusion and sensitivity rules. |
| External Data Ingest | Supporting using generic ETL and pipeline patterns, with EPR-specific authority rules, to be confirmed | Medium | Yes: decide whether this is a domain bounded context or platform infrastructure; decide source authority and conflict-resolution ownership; clarify UKPRN master register and geography ingest scope. |
