# Stage 1 Evidence: Outbound Communication And Notifications

## Purpose

We need to understand whether Outbound Communication / Notifications is a capability we should carry into the bounded-context discovery process for the transformed Education Provider Registry.

We are using this document to gather and normalise the evidence we have found in the legacy GIAS codebase, data model and service documentation. Later DDD stages can then decide the language, subdomain classification and bounded-context boundary without treating the existing implementation as the answer.

We should treat this as a Stage 1 evidence note, not as a final target design decision.

## Scope

We have included evidence for:

- Email notification delivery through GOV.UK Notify.
- Legacy automated email templates and inbox-style email records.
- Workflow notifications for data owners, free schools, academy sponsor-led requests, federations and change requests.
- Reminder notifications, including task reminders and the 60-day establishment data freshness reminder.
- Operational notification emails, including failure, sanity-check and exception alerts.
- Front-end notification banners and announcements where these overlap with the word `notification`.
- Secure Access announcement integration where the legacy system publishes or withdraws operational announcements.

We should treat Quartz jobs, scheduled extracts and scheduler implementation classes as legacy implementation evidence. They can show that the legacy system triggered work on a schedule, but they do not automatically become target business capabilities.

## Evidence Sources

| Source | Evidence Found |
| --- | --- |
| `docs/java-back-end/govuk-notify-integration.md` | Shows the backend GOV.UK Notify integration, notification sender abstraction, production, whitelist and test recipient configuration. |
| `get-information-about-schools/documentation/service/back-end-component/integrations/govuk-notify-integration.md` | Shows the same GOV.UK Notify integration from the service documentation side. |
| `gias-dd-backend/src/main/resources/applicationContext-email-notify.xml` | Wires `NotificationClient`, `NotificationSender`, Notify template IDs and the legacy template-key catalogue. |
| `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSender.java` | Defines the outbound notification operations exposed to the rest of the backend. |
| `gias-dd-backend/src/main/java/com/texunatech/mail/notify/NotificationSenderImpl.java` | Implements Notify email sending, template lookup and personalisation. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/ChangeRequestMailManager.java` | Coordinates change-request and data-owner workflow emails. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/notification/DataOwnerNotificationManagerImpl.java` | Groups applied override changes by data owner and sends data-owner notifications. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/tasks/ReminderManagerImpl.java` | Processes reminder instances and sends reminder notification emails. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/establishment/SixtyDayNotUpdatedReminderManagerImpl.java` | Sends the 60-day data freshness reminder and records reminder history. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/SixtyDayNotUpdatedReminder.java` | Stores 60-day reminder history, establishment, sending date and addressee. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/domain/SixtyDayNotUpdatedReminderFlag.java` | Stores whether the 60-day reminder process is enabled. |
| `gias-dd-backend/src/main/resources/applicationContext-quartz.xml` | Wires scheduled jobs that trigger reminder, pending free school, change request and 60-day reminder processing. |
| `gias-dd-backend/env/server-properties/dev-azure-backend-server.properties` | Shows environment schedules and notification settings, including the 60-day reminder weekday evening schedule. |
| `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/inbox-recipients-and-email.md` | Documents legacy inbox, recipient, attachment and automated email template tables. |
| `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/news-announcements-and-notifications.md` | Documents news stories, announcements, announcement collections and front-end notification banners. |
| `get-information-about-schools/documentation/operations/data/entity-relationship-diagrams/bulk-updates-triggers-and-processing.md` | Documents reminder, 60-day reminder, bulk update and staff/governance freshness-related tables. |
| `gias-dd-backend/src/main/java/com/texunatech/edubase/service/ws/client/SafeSynchronizationService.java` | Publishes and unpublishes announcements to Secure Access through a SOAP integration. |
| `get-information-about-schools/Web/Edubase.Web.UI/Controllers/NotificationsController.cs` | Handles front-end notification banner administration in the .NET application. |
| `get-information-about-schools/Web/Edubase.Data/Entity/NotificationBanner.cs` | Models front-end notification banner content, dates and importance. |
| `get-information-about-schools/Web/Edubase.Data/Entity/NotificationTemplate.cs` | Models front-end notification banner templates. |

## Normalised Legacy Capability Inventory

| Capability | Legacy Evidence | Trigger Or Origin | Recipient Or Audience | DDD Notes |
| --- | --- | --- | --- | --- |
| GOV.UK Notify email delivery | `NotificationSender`, `NotificationSenderImpl`, `applicationContext-email-notify.xml`, Notify integration docs | Backend services and scheduled jobs call the sender | Email address resolved by the calling service | We should treat this as a delivery mechanism, not the whole capability. The domain still owns why we send a notification, who receives it, which template is used and what audit we need. |
| Account and access lifecycle emails | Notify template keys such as `welcomeEmail`, `activationEmail`, `newPasswordEmail`, `resetPasswordEmail`, `changePasswordEmail`, `agreementApprovedEmail`, `agreementRejectedEmail`, `userAccountExpiresNotification` | User account, password, access agreement and group-change events | User or account holder | The source events appear to sit close to Access Control or User Management. Notifications may provide delivery and template handling. |
| Web service account emails | Notify template keys for web service password reset and establishment web service password reset | Web service credential lifecycle events | Web service account contact | This follows the account lifecycle pattern, but may belong with integration access rather than establishment modelling. |
| Data-owner workflow notifications | `ChangeRequestMailManager`, `DataOwnerNotificationManagerImpl`, template keys such as `dataOwnerNotification`, `askDOForAction`, `requestApproved`, `requestRejected`, `delay`, `reminderToApproveOrReject` | Change request lifecycle and applied override changes | Data owners, requestors, helpdesk fallback | The source rules appear to sit in Data Stewardship Workflow. We should separate workflow decision logic from notification delivery and notification history. |
| Pending free school and academy sponsor-led notifications | Template keys such as `newPendingFreeSchool`, `approveOrRejectPendingFreeSchool`, `approveOrRejectPendingAcademySponsorLed`, `pendingFreeSchools`, `newFreeSchoolUserNotification` | Pending establishment workflow events and scheduled pending-free-school processing | Approvers, users, helpdesk or configured recipients | These are establishment lifecycle workflow notifications. They are not independent establishment facts. |
| Federation and establishment group notifications | Template keys such as `federationUpdateEmail`, `newFederationEmail` | Federation or group-related updates | Relevant users or data owners | The trigger belongs with establishment group management. Outbound delivery can still be normalised with the other notification behaviours. |
| Bulk update result notifications | Template keys such as `bulkUpdateSuccessEmail`, `bulkUpdateFailEmail`, `bulkUpdateErrorEmail` | Bulk update processing outcome | Uploading user or operational recipients | We should treat this as evidence of process-result communication. The batch process owns success and failure semantics; a notification capability may own delivery if we retain it. |
| Reminder notifications | `ReminderManagerImpl`, `Reminder`, `ReminderInstance`, template key `reminderNotificationEmail` | Reminder instances identified as incomplete | Users associated with reminder instances | We should treat reminders as having their own lifecycle and state. Sending an email is one possible outcome of a reminder. |
| 60-day establishment data freshness reminder | `SixtyDayNotUpdatedReminderManagerImpl`, `SixtyDayNotUpdatedReminder`, `SixtyDayNotUpdatedReminderFlag`, template keys `sixtyDayNotUpdatedReminderEmail`, `sixtyDayNotUpdatedReminderSupportEmail` | Establishments whose email data has not been updated for 60 or more days; scheduled weekdays at 19:05 in the observed environment | Establishment contacts, or helpdesk support email where no establishment email exists | We have strong evidence for a data-freshness policy, reminder history and recipient fallback behaviour. We should decide the policy owner separately from the email delivery owner. |
| Staff and governance freshness notifications | Template keys such as `staffExpirationNotificationWarningFirst`, `staffExpirationNotificationWarningLast`, `agreementExpirationWarningEmail`; ERD evidence for `StaffRecordsOutdated` and `StaffRoleExpiration` | Staff or governance data freshness and role-expiration rules | Establishment users, data owners or configured recipients | We should keep the governance freshness rule separate from notification delivery. A governance rule can trigger a notification without making notifications part of the Governance model. |
| Feedback routing notifications | Template keys such as `feedbackEmail`, `feedbackUnknownEmail`, `feedbackSecureAccessPin`, `feedbackEstablishmentDetails` | Feedback submission type | Support, helpdesk or relevant handling mailbox | This may be a support workflow capability rather than a core registry capability. |
| Content review notifications | Template keys such as `faqReviewEmail`, `newsStoryReviewEmail`, `automatedEmailTemplateReview` | FAQ, news story or email template review workflow | Reviewers or approvers | These are content-management workflow notifications. We should only retain them if the target service retains the related editorial workflow. |
| Operational and system alert emails | Template keys such as `exceptionOnServerEmail`, `notificationOnServerEmail`, `sanityCheckFailedMail`, `scheduleExtractFailure` | Exceptions, sanity checks, failed scheduled extract processing or other operational events | Operational recipients configured in the environment | These are operational alerts. We should consider them with monitoring, incident management and live-service operations rather than with the public service domain model. |
| Secure Access announcements | `SafeSynchronizationService`, Secure Access announcement properties, announcement-related ERD docs | Publish or unpublish announcement requests | Secure Access users or groups through the external Secure Access service | We should treat this as an external announcement integration. It is closer to operational announcement publication than email notification delivery. |
| Inbox email records and attachments | `InboxMessage`, `Recipient`, `EmailAttachment`, `AutomatedEmailTemplate`, `AutomatedEmailTemplateAud` ERD documentation | Legacy internal inbox/email composition and automated template workflows | Recipients stored in legacy tables | This gives us evidence for communication records, recipients, attachments, templates and audit. We should not collapse this into a simple Notify adapter without checking target needs. |
| Front-end notification banners | `NotificationBanner`, `NotificationTemplate`, `NotificationsController`, `FrontEndNotificationTemplates`, `FrontEndNotificationBanners` | Editorial/admin creation of dated banners | Users viewing the front-end site | We should treat this as presentation content, not outbound delivery. It shares the word `notification`, but we should model it separately unless we deliberately create a broader communications model. |

## Normalised Concepts

| Legacy Term Or Concept | Normalised Meaning | Notes |
| --- | --- | --- |
| Notification | A communication emitted because a domain event, workflow state, reminder rule or operational condition has occurred. | The legacy system uses this word for email, front-end banners and announcements, so we should qualify the term in Stage 2. |
| Email notification | An outbound email sent through GOV.UK Notify or a legacy mail/template path. | We should make the delivery channel explicit. |
| Template | Reusable content with a template key or Notify template ID. | Some templates are GOV.UK Notify templates; others are legacy automated email templates with approval and audit. |
| Recipient | The person, mailbox or organisation contact that receives a communication. | Recipients may be explicit email addresses, data owners, establishment contacts, users, reviewers, helpdesk mailboxes or operational distribution lists. |
| Audience | A target group for a banner, announcement or published message. | Audience targeting appears in announcement collections and user-group relationships. |
| Reminder | A time or rule-driven prompt that exists before any email is sent. | We should keep the reminder lifecycle separate from the notification delivery lifecycle. |
| Announcement | Published information, sometimes integrated with Secure Access. | Announcement publication is not the same as sending an email. |
| Banner | A dated front-end message displayed in the application. | We should treat this as a presentation concern and avoid merging it blindly with outbound email. |
| Delivery attempt | The act of sending through GOV.UK Notify or another channel. | The legacy Notify sender logs failures and returns a response object or null. We need to confirm target audit and retry requirements. |
| Notification history | Evidence that a communication was sent, attempted, suppressed or skipped. | We can see this explicitly for the 60-day reminder and implicitly in inbox/template tables. |

## Implementation Patterns In The Legacy System

### GOV.UK Notify Adapter

The backend has a central Notify sender abstraction. Most email methods resolve a template key, populate personalisation and call GOV.UK Notify through the Notify Java client.

That gives us evidence that GOV.UK Notify is a delivery adapter. The business capability still includes:

- Deciding when we should send a notification.
- Resolving the recipient.
- Selecting the template.
- Supplying personalisation.
- Recording, suppressing or retrying delivery where required.

### Legacy Template And Inbox Model

The data model includes inbox messages, recipients, email attachments and automated email templates with audit. That is broader than a simple email-send adapter. We have evidence for composed communications, recipient scoping, attachments and template approval/review.

We should decide which of these behaviours are still required before assuming GOV.UK Notify removes the need for a communication model.

### Scheduled Triggering

Several notifications are triggered by Quartz jobs. Examples include reminder processing, pending free school processing, change request mail processing and the 60-day not-updated reminder.

For Stage 1, the important evidence is the business work being triggered:

- Process outstanding reminders.
- Notify about pending establishment workflows.
- Send change request workflow emails.
- Prompt establishments whose data has become stale.

Quartz itself is not the business capability.

### Operational Communication

The legacy system also sends operational emails for exceptions, failed extracts, sanity checks and server notifications. These are communication behaviours, but they may belong with monitoring, support and live-service operations rather than with the public service domain model.

## DDD Observations

1. Outbound Communication / Notifications is a credible candidate capability.

   We have found a broad set of notification behaviours used by several source domains. GOV.UK Notify can provide delivery, but it does not own notification intent, recipient resolution, template policy or business audit.

2. Notification triggers come from several domains.

   Establishment lifecycle, Data Stewardship Workflow, Access Control, Governance, content management and operations all trigger communications. This points away from putting every notification rule inside Establishment Registry.

3. `Notification` is overloaded.

   The legacy estate uses notification-like terms for outbound email, front-end banners, internal inbox records and Secure Access announcements. We should split these meanings carefully in Stage 2.

4. Reminders are not just notifications.

   The reminder model has state before email delivery. A reminder can be incomplete, eligible, suppressed or completed. Sending an email is only one outcome.

5. The 60-day freshness reminder is specific domain policy evidence.

   The 60-day reminder shows a policy about asking establishments to confirm or update their data. We should decide the owner of that policy separately from the owner of email delivery.

6. GOV.UK Notify reduces build scope but not modelling scope.

   We may not need to build an email delivery component, but we may still need to model or orchestrate notification intent, recipient resolution and audit where those are in scope.

## Candidate Stage 2 Language Additions

| Term | Candidate Definition |
| --- | --- |
| Outbound communication | A message emitted from the service to a user, contact, operational recipient or external publication channel. |
| Notification intent | The reason and business context for sending a notification. |
| Notification trigger | The event, rule or schedule that makes a notification eligible to be sent. |
| Recipient resolution | The process of identifying who should receive a notification. |
| Notification template | Reusable message content selected by notification type and channel. |
| Notification delivery | The channel-specific send operation, such as GOV.UK Notify email delivery. |
| Notification history | A record of a notification being generated, sent, skipped, suppressed or failed. |
| Reminder | A domain prompt with its own lifecycle, which may result in one or more notifications. |
| Announcement | Published information made visible to a target audience, potentially through another system such as Secure Access. |
| Banner | A front-end presentation message shown within the service over a configured date range. |

## Candidate Stage 3 Subdomain Framing

| Candidate Subdomain | Classification Hypothesis | Rationale |
| --- | --- | --- |
| Outbound Communication / Notifications | Supporting or generic, depending on retained scope | If we only need GOV.UK Notify for simple transactional emails, much of this could be generic. If recipient resolution, template governance, audit, suppression and reminder history are material, it starts to look like a supporting bounded context. |
| Reminder Management | Supporting | Reminders have lifecycle and policy separate from delivery. We should decide whether each reminder belongs with the domain that owns the policy, or whether multiple domains need a shared reminder capability. |
| Operational Announcements | Supporting or out of scope | Secure Access announcements and front-end banners are publication behaviours rather than provider facts. Whether we retain them depends on target operational and user-communication requirements. |
| Operational Alerts | Generic/live-service operations | Exception, sanity-check and extract-failure emails should be considered with monitoring, SIEM, incident response and service management. |

## Open Questions For Later Stages

| Question | Why It Matters |
| --- | --- |
| Which legacy notification types do we need for beta? | We should avoid carrying every legacy email template into target scope by default. |
| Do we need a target notification history or audit model? | GOV.UK Notify can send emails, but the service may still need proof of generated, skipped or failed communications. |
| Who owns template content and approval? | Legacy automated templates have review/audit behaviours that we may or may not need to retain. |
| Does recipient resolution belong inside each source domain or inside a notification context? | This affects whether Notifications is a thin adapter or a real supporting bounded context. |
| Are front-end banners in scope for the transformed service? | Banners are presentation content, not outbound email. |
| Are Secure Access announcements still required? | They introduce a separate publication channel and external system integration. |
| What is the exact target rule for asking users whether establishment data is up to date? | The legacy evidence shows a 60-day reminder, but we need to confirm the target policy owner and interval. |
| What retry, suppression and escalation rules do we need? | These determine whether notification delivery needs more than a simple call to GOV.UK Notify. |

## Recommended Stage 1 Output

We should add Outbound Communication / Notifications to the Stage 1 evidence set as a candidate capability area with the following normalised statement:

> The legacy system sends and publishes communications in response to account events, establishment and change-request workflows, data-owner responsibilities, reminder rules, data-freshness policies, content-review workflows and operational conditions. GOV.UK Notify is used for many email deliveries, but the legacy capability also includes recipient resolution, template selection, reminder state, notification history, front-end banners, announcements and operational alerts.

We should use this evidence in later stages to decide:

- Whether Notifications should be a separate supporting bounded context.
- Which notification triggers remain owned by Establishment Registry, Governance, Access Control or Data Stewardship Workflow.
- Which delivery behaviours can be delegated to GOV.UK Notify.
- Which legacy announcement, banner and operational alert behaviours are out of scope for beta.
