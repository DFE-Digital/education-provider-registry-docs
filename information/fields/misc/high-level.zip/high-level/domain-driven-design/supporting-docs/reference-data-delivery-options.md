# Reference Data Delivery Options

## Purpose

This document sits alongside `reference-data-ownership-analysis.md`.

The ownership analysis decides which bounded context should own each reference-data family. This document looks at the delivery question: once ownership is clear, how should reference data be stored, changed, published and consumed?

The important distinction is:

- Ownership is about who controls lifecycle and meaning.
- Delivery is about how values are stored, distributed, cached, validated and exposed.

We should not assume that all reference data must be delivered in the same way.

## Methodology

This paper uses:

| Source | How it was used |
| --- | --- |
| `reference-data-ownership-analysis.md` | Source for the proposed ownership split between Establishment Registry, Governance, Access Control and shared/problem cases. |
| `../analysis/reference-data-bounded-context-usage-matrix.md` | Item-level evidence showing that almost all reference data belongs to one bounded context and that the small overlap set is static, bounded and does not require a separate Reference Data context. |
| `docs/data/investigation/reference-data-analysis.md` | Source for the active reference-data catalogue and application insights. |
| `docs/data/investigation/reference-data-by-ui-tab.md` | Source for cross-tab reuse and UI-driven reference-data dependencies. |
| [W3C SKOS Primer](https://www.w3.org/TR/skos-primer/) | Used as an established model for controlled vocabularies, concept schemes, labels, notes and mappings. |
| [HL7 FHIR Terminology Module](https://hl7.org/fhir/R4/terminology-module.html) | Used as an example of a mature terminology-service pattern using code systems, value sets, lookup, validation, expansion and translation operations. |

This is an options paper, not a physical design decision. The recommendation should be tested against the logical model, access-control design, data-stewardship workflow and beta delivery scope.

## Name Of The Problem

This is a known architecture and data-management concern. The common names are:

| Term | Meaning |
| --- | --- |
| Reference Data Management | Managing relatively stable code lists and classifications such as establishment type, phase, status, role type and geography codes. |
| Controlled Vocabulary Management | Managing defined values and labels where the meaning of each value matters. |
| Code List Management | A practical implementation view of reference data: codes, labels, status, order, effective dates and retirement. |
| Terminology Service | A service pattern that can look up, validate, expand, translate and publish coded values. The FHIR terminology model is a mature example. |
| Knowledge Organisation System | A broader semantic-web term for taxonomies, thesauri, subject headings and controlled vocabularies. SKOS is the relevant W3C model. |
| Master Data Management | Adjacent but not identical. MDM is usually about core business entities such as organisations, people and places. Reference data is usually smaller, more stable classification data. |
| Published Language | A DDD pattern where a context publishes a stable language that other contexts can consume without sharing the internal model. |
| Shared Kernel | A DDD pattern where multiple contexts share a small model. This can work for tiny stable code lists, but it increases coupling. |

So yes, the concern is solved in the sense that there are established patterns. It is not solved by a single universal product or database choice. The right answer depends on volatility, ownership, volume, relationship complexity, validation needs and how many consumers rely on the values.

## Design Forces

Reference-data delivery needs to balance:

| Force | Why it matters |
| --- | --- |
| Clear ownership | One context must decide when a value is created, renamed, retired or split. |
| Consumer independence | Other services should not need direct access to another service's transaction database. |
| Historical integrity | Old records may reference retired values and must still display correctly. |
| Change control | Some lists need BA/steward approval; others are deployment-time configuration. |
| Validation | Some values are labels only; others enforce domain rules. |
| Performance | UI and API reads should not call a slow central lookup service for every row. |
| Availability | Reference data should be cacheable and resilient because many journeys depend on it. |
| Semantics | Some values need definitions, mappings, hierarchy or public URIs, not just code and label. |
| External source | Geography and postcode reference data is externally shaped and may need ingestion rather than manual maintenance. |

## Options

### Option 1: Store Reference Data In Each Owning Transactional Database

Each bounded context stores the reference data it owns in its own transactional database.

For example:

- Establishment Registry stores `EstablishmentType`, `EstablishmentStatus`, `EducationPhase`, `LinkType`, `EstablishmentGroupType`, geography classifications and establishment-facing legacy flags.
- Governance stores `StaffRole`, `StaffAppointingBody`, `StaffType`, `StaffRoleType` and governance-field metadata.
- Access Control stores `Authority`, `Tool`, `ToolPermission`, `UserRole` and policy-facing capability values.

| Pros | Cons |
| --- | --- |
| Strong ownership alignment with DDD boundaries. | Consumers need published APIs, events or replicated views rather than direct table joins. |
| Relational constraints, foreign keys, effective dates and audit columns are straightforward. | Shared values such as `Title`, `LocalAuthority` and `ValidationRule` need explicit publication rules. |
| Works well for rule-bearing reference data used in validation. | Can create duplicated lookup APIs if every service builds the same plumbing. |
| Easy to version alongside transactional schema and migrations. | Cross-context reporting may need denormalised projections. |
| Simple for engineers to understand and operate. | Not ideal for rich semantic vocabularies with mappings, hierarchy and public linked-data needs. |

Best fit:

- Establishment and establishment-group classifications.
- Governance role and appointing-body values.
- Access-control capability vocabularies.
- Values that enforce domain rules.

### Option 2: Domain-Owned Reference Data With Published Read Contracts

The owning context stores the data, but consumers do not read the owning database. Instead the owner publishes a stable contract:

- Lookup API.
- Versioned JSON endpoint.
- Domain event when a code list changes.
- Read-model table owned by the consuming context.
- Static export for public or documentation use.

| Pros | Cons |
| --- | --- |
| Preserves ownership while reducing direct database coupling. | Requires explicit contract design and versioning. |
| Lets consumers cache or replicate values safely. | Consumers need to handle stale values and sync failures. |
| Supports different consumer needs, such as UI dropdowns, API display labels and policy attributes. | More moving parts than direct table access. |
| Works well with a decomposed architecture. | Requires discipline so copied data is treated as a projection, not a new source of truth. |
| Makes historical and retired values easier to publish consistently. | Needs clear compatibility rules when labels or meanings change. |

Best fit:

- Our likely default pattern.
- Shared values consumed by Governance, Access Control and External Read API.
- Values needed in read models or cache layers.

### Option 3: Separate Reference Data Service Or Terminology Service

A dedicated service owns lookup tables, code systems, validation, expansion, translation and publication.

This is similar to a terminology-service pattern. In healthcare, FHIR separates `CodeSystem`, `ValueSet`, lookup, validation, expansion and translation operations as part of its terminology model.

| Pros | Cons |
| --- | --- |
| Gives one place for reference-data lifecycle, audit and publication. | Can become a generic dumping ground for unrelated business meaning. |
| Useful where many services need the same vocabulary services. | Creates a runtime dependency for many services unless values are cached aggressively. |
| Can provide standard operations such as lookup, validate, expand and translate. | Risks pulling rule-bearing domain concepts away from the context that understands them. |
| Can support UI administration and stewarded changes. | Additional service, database, deployment, ownership and support burden. |
| Good for truly shared enterprise vocabularies. | May be over-engineering for private beta. |

Best fit:

- Only if shared reference-data governance becomes large enough to justify a service.
- Enterprise-wide vocabularies used outside EPR.
- Rich terminology operations such as mapping old codes to new codes.

Not the recommended default for EPR right now because establishment and governance reference data has strong domain ownership.

### Option 4: Source-Controlled JSON Or YAML

Reference data is stored as JSON/YAML files in source control and loaded by the application at build, deploy or startup.

| Pros | Cons |
| --- | --- |
| Very simple for low-volatility values. | Changing values usually requires an engineering change and deployment. |
| Git history gives a clean audit trail. | Not suitable where business users or data stewards need runtime changes. |
| Easy to review through pull requests. | Harder to enforce relational integrity against transactional records. |
| Good for values that are really application configuration. | Multiple services can drift if they each carry their own copy. |
| Does not require a relational database. | Historical display of retired values needs careful design. |

Best fit:

- Small stable technical vocabularies.
- Access-control policy documents if engineers are maintaining them initially.
- Development-time seed data.
- Values where runtime update is not required.

Poor fit:

- Establishment type, status, governance roles or local authority where business lifecycle and historical compatibility matter.

### Option 5: Static Published JSON From Object Storage Or CDN

The owner publishes versioned reference-data files, such as JSON, CSV or Turtle, to object storage or a static docs/data endpoint. Applications download and cache them.

| Pros | Cons |
| --- | --- |
| Cheap, scalable and easy to cache. | Does not provide transactional integrity by itself. |
| Good for public or read-only vocabularies. | Consumers need refresh, validation and fallback behaviour. |
| Decouples consumers from the owning transaction database. | Not ideal where immediate consistency is required. |
| Can publish multiple formats for different consumers. | Requires separate process for approving, generating and publishing files. |
| Good for low-change high-read values. | Harder to support complex query/filter operations without additional indexing. |

Best fit:

- Public vocabulary exports.
- External Read API support data.
- Documentation/site publishing.
- Read-only consumers that can tolerate eventual consistency.

### Option 6: RDF/SKOS Vocabulary Published As Turtle Or JSON-LD

Reference data is represented as concepts in concept schemes, using SKOS-style identifiers, labels, notes, broader/narrower relationships and mappings.

| Pros | Cons |
| --- | --- |
| Strong fit for controlled vocabularies, taxonomy, public URIs and linked-data publication. | More complex than simple relational lookup tables for application developers. |
| Supports labels, definitions, synonyms, hierarchy and mappings. | Not every reference list needs semantic-web modelling. |
| Helps avoid modelling values as OWL classes. | Runtime applications may still need simpler JSON/read models. |
| Good for public documentation and interoperability. | Requires governance for URI design and vocabulary lifecycle. |
| Can coexist with relational transactional storage. | Graph/RDF tooling is a specialist skill compared with SQL/JSON. |

Best fit:

- Published vocabulary for establishment types, group types, governance role types and relationship types.
- Documentation and API semantics.
- Mapping old/current values or aligning to external vocabularies.

Poor fit:

- High-throughput UI dropdown lookup as the only runtime mechanism.

### Option 7: Key-Value Store Or Distributed Cache

Reference data is stored or replicated into a key-value store, cache or configuration store. The application reads values by key.

| Pros | Cons |
| --- | --- |
| Very fast lookup. | Weak fit for lifecycle, audit and complex relationships unless another system owns the source. |
| Useful for high-read, low-change values. | Cache invalidation and staleness need explicit design. |
| Can reduce pressure on transactional databases. | Should not become the source of truth for rule-bearing business values. |
| Easy to use for feature/config toggles or simple label lookup. | Harder to query by relationship, hierarchy, effective date or historical version. |
| Works well as a projection. | Consumers may accidentally treat cached values as authoritative. |

Best fit:

- Cached projection of domain-owned reference data.
- High-read UI and API lookup paths.
- Access-control decision support where values are versioned and safely refreshed.

Poor fit:

- Source of truth for establishment type, governance roles or local authority.

### Option 8: Document Store

Reference data is stored as documents, such as one document per code list or one document per versioned vocabulary.

| Pros | Cons |
| --- | --- |
| Flexible structure for lists with different attributes. | Weaker relational integrity than SQL. |
| Good for versioned snapshots and API-shaped payloads. | Can become messy if every list has a different shape. |
| Works well for nested metadata, mappings and display configuration. | Querying across lists can be harder. |
| Natural fit for JSON APIs. | Requires validation schema discipline. |
| Can support effective-dated document versions. | Not ideal for values that need frequent relational joins. |

Best fit:

- Versioned vocabulary snapshots.
- API representation cache.
- Field metadata where the shape is more configuration-document than relational lookup.

### Option 9: External Dataset Ingestion Store

Externally sourced reference data is ingested into a store designed for the data shape. This might still be relational, but it may need spatial, bulk-load, staging or versioned import support.

Examples:

- Postcode-to-geography data.
- LSOA and MSOA.
- Wards.
- Constituencies.
- Local authority mappings.

| Pros | Cons |
| --- | --- |
| Treats large external datasets as data products rather than hand-authored lookup values. | Requires ingestion pipelines, reconciliation and update monitoring. |
| Supports repeatable refresh from authoritative sources. | More operational work than static small code lists. |
| Can preserve source version and effective date. | Target services still need simple consumption contracts. |
| Better fit for geography and postcode data. | May need specialist indexing or spatial features. |
| Keeps manually governed business vocabularies separate from imported datasets. | Ownership can become unclear if "geography service" and Establishment Registry both use the data. |

Best fit:

- Geography and administrative reference data.
- Any future externally maintained classification list.

## Summary Comparison

| Option | Best fit | Main risk | EPR position |
| --- | --- | --- | --- |
| Domain-owned relational tables | Rule-bearing domain reference data | Direct database coupling if consumers join across contexts | Use as the default source of truth inside Establishment Registry, Governance and Access Control. |
| Published read contracts | Cross-context consumption | Contract/versioning work | Use for consumers of domain-owned values. |
| Reference/terminology service | Enterprise shared vocabulary service | Over-centralisation and extra runtime dependency | Do not start here for private beta; reconsider if shared governance becomes large. |
| Source-controlled JSON/YAML | Stable technical/config values | Deployment required for every change | Use selectively for engineer-maintained config or seed data. |
| Static JSON/object storage/CDN | Read-only public or cacheable vocabularies | Staleness and weak integrity | Use for published exports and docs/API support. |
| RDF/SKOS vocabulary | Semantic vocabularies and public URIs | Runtime complexity | Use for published vocabulary, not as the only application lookup mechanism. |
| Key-value/cache | Fast lookup projection | Mistaken source-of-truth ownership | Use as cache/projection only. |
| Document store | Versioned snapshots and varied metadata | Loose schema discipline | Consider for published snapshots or complex UI metadata. |
| External dataset ingestion store | Geography and other external datasets | Operational ingestion complexity | Use for geography-style data where the shape and refresh cycle justify it. |

## Recommended EPR Pattern

### Architecture conclusion

**Reference Data should not be a bounded context in EPR.**

The usage matrix shows that most values belong naturally to the bounded context whose rules they support:

- Establishment Registry owns establishment, establishment-group, relationship, status and geography reference data.
- Governance owns governance roles, appointing bodies and governance-field reference data.
- Access Control owns its policy-facing capabilities and authorities.

The apparent overlap is small. `EstablishmentType`, `EstablishmentGroupType` and `GovernorsFlag` are important facts owned by Establishment Registry that Governance may consume. `LocalAuthority` is establishment context. `Title` is display-only and can be composed in the frontend/read layer. The legacy `Governance` classification is small and may be ignored or retired unless a target rule is evidenced.

This does not justify a separate model, team, runtime service or deployment boundary for Reference Data.

### Recommended hybrid pattern

We should use this pattern:

1. Use domain-owned relational reference tables as the source of truth for rule-bearing values.
2. For cross-context facts that must remain current, publish them from the owning context as part of a subject/read contract rather than exposing its database.
3. Permit a small number of static, bounded lists to be duplicated in source control or seeded into each consuming context when that is operationally simpler than a runtime dependency.
4. Treat each duplicated copy as local application data; one agreed source definition remains the change authority.
5. Allow consumers to cache or project larger or more changeable reference data, but make it clear that cached/projection copies are not authoritative.
6. Use static JSON or Turtle/SKOS exports for public vocabulary, documentation and API semantics.
7. Use source-controlled JSON/YAML for stable technical configuration and deliberately duplicated static lists.
8. Treat geography and postcode datasets as externally sourced reference data with an ingestion and publication pattern.
9. Do not create a Reference Data bounded context or central service from the current evidence.

In practical terms:

| Reference data | Recommended delivery |
| --- | --- |
| Establishment type, status, phase, link types and group types | Establishment Registry source of truth. Supply selected codes/facts through establishment/group contracts; publish a lookup export only where a consumer genuinely needs the catalogue. |
| Governance role, appointing body, staff type and role type | Governance relational source of truth, published lookup API/export, cached by consumers. |
| Local authority and geography classifications | Establishment Registry ownership with external dataset ingestion and versioned publication. |
| Title | Treat as presentation data. Compose governance display in the frontend/read layer or carry the selected value with the person; no shared runtime reference service is needed. |
| Governors flag | Establishment Registry owns `haslocal`, `haslocalandshared`, `hasshared` and `nolocal`. Governance may consume the selected flag through the subject contract; it does not need its own authoritative lookup. |
| Legacy `Governance` classification | Keep in Establishment Registry only if a retained rule uses `LA`, `Other Community Group`, `Health`, `PVI` or `N/A`; otherwise retire or ignore it. |
| Validation rules | Not treated as reference data in the target model. Each bounded context owns its validation behaviour and configuration. |
| Access-control authorities, tools and role/capability values | Access Control-owned relational/config source of truth, versioned with policy documents. |
| Public vocabulary and taxonomy | Published SKOS/Turtle/JSON-LD view generated from owned reference data, not a competing source of truth. |

## Operational Cost Of Deliberate Duplication

Duplicating a small static list in two bounded contexts has a real but slight operational cost:

| Cost | Practical control |
| --- | --- |
| Two copies must be changed | Keep one canonical source-controlled definition or clearly named owning context and update both copies in one change. |
| Values can drift | Add an automated contract/parity test comparing codes and meanings. |
| Deployments may need coordination | Because these lists change rarely, schedule coordinated deployment only when a value is added, renamed or retired. Maintain backward compatibility during rollout. |
| Historic values may be removed inconsistently | Never delete a referenced code without a retirement/supersession rule and compatibility period. |
| Ownership can become unclear | Record the owner next to the list and in the architecture decision; duplication does not create joint authority. |

For a handful of tiny, slow-changing lists, this cost is lower than operating a central service, adding network availability concerns, versioning a runtime API and coupling both bounded contexts to it.

Duplication is suitable only when all of these are true:

- the list is small and bounded
- changes are rare and controlled
- no immediate runtime consistency is required
- compatibility can be checked automatically
- an authoritative owner is named

Larger, externally sourced or more frequently changing datasets such as local authorities and geography should not be manually duplicated. They should remain owned and published by the appropriate context or ingestion process.

## When To Reconsider A Separate Reference Data Service

We should reconsider a dedicated reference/terminology service only if several of these become true:

| Trigger | Why it matters |
| --- | --- |
| Many services need to validate codes at runtime and no single domain owner is natural. | A terminology service may reduce duplicated logic. |
| Business users need one UI to maintain reference data across multiple bounded contexts. | A central stewardship UI may be justified, though ownership still needs domain accountability. |
| We need code translation, value-set expansion or mapping between old and new classifications as a common capability. | This is classic terminology-service territory. |
| External consumers require a stable enterprise code-list service. | Publication becomes a product, not just an internal implementation detail. |
| Reference-data changes become frequent enough that deployments are too slow but controlled enough that runtime admin is safe. | A service with workflow and audit may be worth the operational cost. |

Until then, centralising all reference data would probably add more coupling than it removes.

## Decision Guidance

Use this checklist when deciding the delivery mechanism for a reference-data family:

| Question | Prefer |
| --- | --- |
| Does the value enforce domain rules or foreign-key integrity? | Domain-owned relational storage. |
| Is the value consumed by another bounded context and needed as a current domain fact? | Owning-context contract plus cache/projection where justified. |
| Is the shared list tiny, bounded and rarely changed? | Deliberate source-controlled duplication with an owner and parity test. |
| Is the list externally sourced and large? | Ingestion store plus versioned publication. |
| Does the value need public URI, definitions, hierarchy or mappings? | SKOS/RDF publication as a generated view. |
| Is the value tiny, stable and technical? | Source-controlled JSON/YAML or code enum. |
| Does the value need fast lookup but not ownership? | Cache or key-value projection. |
| Does the value need stewarded runtime changes across domains? | Consider a reference/terminology service, but keep domain ownership explicit. |

## Conclusion

Reference data is an implementation and ownership concern within EPR's business bounded contexts, not a bounded context of its own.

The recommended decision is distributed ownership: Establishment Registry, Governance and Access Control each own the reference data that supports their rules. Cross-context facts are supplied through owning-context contracts. A very small number of static, bounded lists may be duplicated deliberately where this removes unnecessary runtime coupling. Their low change frequency makes the additional maintenance modest, provided ownership, parity testing, coordinated change and retirement controls are explicit.

This is simpler and more cohesive than creating a Reference Data bounded context or central runtime service.
