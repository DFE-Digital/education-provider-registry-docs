# Stage 3: Identify And Classify Subdomains

## Purpose

This document executes **Stage 3: Identify And Classify Subdomains** for the high-level design work.

We use this stage to decide which parts of the Education Provider Registry domain need the most modelling attention. This is not the same as deciding service boundaries. A subdomain classification helps us understand business importance, differentiation and complexity before we propose bounded contexts in Stage 4.

## Stage 3 Method

We should classify subdomains using the evidence gathered in Stage 1 and the language defined in Stage 2.

Domain-driven design usually separates subdomains into:

| Classification | Meaning | Design implication |
| --- | --- | --- |
| Core subdomain | A business capability that is central to the value of the service and where poor modelling would create major risk. | We should invest the most design effort here and avoid blindly buying or copying a generic model. |
| Supporting subdomain | A business capability that is important to the service but not the main differentiator. | We should model enough to meet EPR needs, but avoid unnecessary custom complexity. |
| Generic subdomain | A common capability where standard patterns, products or frameworks can do much of the work. | We should prefer established patterns and avoid inventing our own platform where possible. |

The classification is about the business problem, not the current database structure. A database area, UI tab or legacy module does not automatically become a subdomain.

## Inputs

This stage uses:

- [Stage 1: Gather And Normalise Evidence](stage-1-gather-and-normalise-evidence.md)
- [Stage 2: Define The Ubiquitous Language](stage-2-define-ubiquitous-language.md)
- Published analysis documents in [analysis](../analysis)
- Access-control analysis in `docs/transformation/access-control`
- Data-stewardship workflow analysis in `docs/transformation/data-stewardship`
- Existing service-boundary thinking in `docs/transformation/tech-plan/05-service-boundaries.md`
- Reference-data ownership and delivery analysis in `docs/transformation/high-level/domain-driven-design`
- [Editorial Content Current-State Analysis](../analysis/editorial-content-candidate-bounded-context-analysis.md)
- [Outbound Notification Code Analysis](../analysis/outbound-notification-code-analysis.md)
- [Legacy Notification Catalogue](../analysis/legacy-notification-catalogue.md)

## Classification Criteria

We should classify each candidate subdomain against these questions:

| Question | Why it matters |
| --- | --- |
| Is this central to the public and operational value of the registry? | Core subdomains deserve deeper modelling and stronger ownership. |
| Does the business language differ from surrounding areas? | Distinct language suggests a real subdomain boundary may exist. |
| Does the data have its own lifecycle and rules? | Independent lifecycle and rules suggest the model should not be buried inside another area. |
| Would poor modelling create high operational, policy or trust risk? | Risk can push a capability towards core or high-priority supporting status. |
| Is this a solved architectural problem? | Generic subdomains should use proven patterns where possible. |
| How much EPR-specific policy or data is needed? | A generic mechanism may still need domain-specific configuration or vocabulary. |

## Candidate Subdomain Classification

| Candidate subdomain | Classification | Rationale |
| --- | --- | --- |
| Establishment Registry | Core subdomain | The registry's primary value is the authoritative record of establishments, establishment types, statuses, identifiers, locations and relationships. Many other capabilities depend on this model being correct. |
| Establishment Groups And Memberships | Core subdomain | Trusts, sponsors, federations and children's-centre groups materially change how establishments are understood. Group identity, membership and relationship rules are part of the registry's central business value, whether implemented inside the Establishment Registry context or as a collaborating context. |
| Governance | Core subdomain | Governance accountability, statutory transparency and public trust are central service outcomes. Governance has distinct language, roles, appointments, identifiers, lifecycle rules and privacy concerns. |
| Access Control | Generic subdomain with EPR-specific policy | Authorisation is a well-established architectural problem, but EPR protected resources, scopes, attributes and policy decisions are domain-specific. |
| Data Stewardship Workflow | Supporting subdomain using generic workflow patterns | Workflow engines and maker-checker patterns are common, but EPR change requests, proposed values, evidence and stewardship rules are domain-specific. |
| External Read API | Supporting product/API subdomain | The read API is essential for consumers, but it should expose governed representations derived from the domain model rather than own the transactional model. |
| Reference Data | Supporting subdomain with mixed ownership, to be confirmed | Governed codes, labels, definitions and lifecycles support every major domain area. Reference-data management uses common patterns, but the meaning and authority of individual datasets can be domain-specific. |
| Editorial Content | Generic or supporting subdomain, to be confirmed | Authoring and publishing are common capabilities. EPR-specific needs may remain for runtime editorial banners, audience presentation, document handling and audit, but the current evidence does not justify treating all editorial material as custom core functionality. |
| Outbound Communication | Supporting subdomain using generic delivery patterns, to be confirmed | The service needs to generate user, workflow, reminder, data-owner and operational messages, but GOV.UK Notify and email delivery are generic capabilities. EPR-specific modelling is mainly around intent, trigger, recipient resolution, suppression, history and ownership of domain-triggering rules. |

## Establishment Registry

We should treat the Establishment Registry as the strongest core-subdomain candidate.

Evidence:

- Establishment type drives field applicability, governance expectations, access-control attributes and read-model representation.
- Establishment status, identifiers and lifecycle are central to public and operational use.
- Establishment links carry lifecycle meaning such as predecessor, successor, merged and amalgamated relationships.
- Location is mostly common establishment data, but still belongs close to the establishment record.
- The DfE Enterprise Data Model treats Establishment as a key education-domain organisation concept.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High |
| Domain specificity | High |
| Rule complexity | High |
| Dependency from other contexts | High |
| Suggested classification | Core |

Design implication:

We should model this carefully and avoid letting legacy table boundaries or public page tabs define the target model by accident.

## Establishment Groups And Memberships

Establishment Groups And Memberships is a core subdomain. It is tightly coupled to the Establishment Registry, but classification as core does not predetermine whether it forms a separate bounded context.

Evidence:

- The group extract contains trusts, sponsors, federations, children's-centre groups, children's-centre collaborations, SATs, MATs and secure SATs.
- Group links represent establishment-to-group relationships, not establishment-to-establishment links.
- Trust and sponsor relationships are distinct and should not be collapsed into a single text field.
- Children's-centre group links can carry lead-centre semantics through `ccLinkType` or `CCIsLeadCentre`.
- Group-to-group links are a separate relationship model, mainly around SAT/MAT history.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High |
| Domain specificity | High |
| Rule complexity | Medium to high |
| Coupling to establishment records | High |
| Suggested classification | Core |

Design implication:

We should not decide too early whether establishments and groups are one bounded context or two. Stage 4 should test both options.

## Governance

Governance should be treated as a core subdomain and a serious bounded-context candidate.

Evidence:

- Governance extracts contain 270,736 governance rows across LA, academy and MAT scopes.
- Governance can be establishment-scoped through `URN` or group-scoped through `UID`.
- Governance role language is distinct: trustee, member, governor, local governor, chair, accounting officer, chief financial officer and governance professional.
- Governance appointments have their own role, appointing-body, term and historical concerns.
- Governance data is privacy-sensitive and public presentation differs from raw extract structure.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High |
| Domain specificity | High |
| Rule complexity | High |
| Dependency from Establishment Registry | Medium |
| Suggested classification | Core |

Design implication:

Governance should not be modelled as a set of person fields on an establishment. It should be tested as its own bounded context with explicit relationships to establishments and establishment groups.

## Access Control

Access Control should be treated as a generic subdomain with EPR-specific policy.

Evidence:

- RBAC, ABAC and policy-decision architecture are established patterns.
- EPR still needs domain-specific protected resources, actions, scopes and policy attributes.
- Access Control must work across Establishment Registry, Governance, Data Stewardship Workflow and External Read API boundaries.
- Access Control should not own domain data such as establishment status, group membership or governance appointments.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High |
| Domain specificity | Medium |
| Rule complexity | Medium to high |
| Availability of standard patterns | High |
| Suggested classification | Generic with EPR-specific policy |

Design implication:

We should prefer a policy-driven access-control component using standard patterns. The EPR-specific work is defining protected resources, actions, scopes, attributes and policy governance.

## Data Stewardship Workflow

Data Stewardship Workflow should be treated as a supporting subdomain that can use generic workflow patterns.

Evidence:

- The workflow problem is about changing application data.
- We need change requests, proposed values, review tasks, decisions, evidence, workflow states and workflow history.
- Workflow must coordinate changes across domain service boundaries without owning the authoritative domain records.
- The workflow context may need to request validation or application from Establishment Registry and Governance contexts.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High |
| Domain specificity | Medium |
| Rule complexity | Medium to high |
| Availability of standard patterns | High |
| Suggested classification | Supporting, using generic workflow patterns |

Design implication:

We should avoid making the workflow engine the owner of establishment, group or governance data. It should own the process and history of change, not the authoritative domain records.

## External Read API

The External Read API should be treated as a supporting product/API subdomain.

Evidence:

- External consumers need stable read contracts.
- The read API will likely combine establishment, group and governance information into useful resources.
- API representation should not leak internal transaction models, workflow state mechanics or legacy table structures.
- Access control and public/private data rules need to apply to read resources.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High |
| Domain specificity | Medium |
| Rule complexity | Medium |
| Dependency on domain contexts | High |
| Suggested classification | Supporting product/API subdomain |

Design implication:

The read API should not own the transactional model. It should publish stable governed representations derived from domain contexts.

## Reference Data

Reference Data should be treated as a supporting subdomain candidate whose internal ownership may be distributed across domain contexts.

Evidence:

- The current estate contains substantial governed classifications, code sets, labels, definitions, validation metadata and controlled values.
- Reference values have business lifecycles including introduction, renaming, effective use, supersession and retirement.
- Establishment, governance, access-control and workflow concerns consume different datasets with different meanings and likely owners.
- Shared use and a common technical table shape do not prove that all reference data forms one consistency or ownership boundary.
- Consumers need stable, versioned reference contracts without depending on shared persistence details.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | High supporting value |
| Domain specificity | Mixed: high for individual meanings, lower for management mechanics |
| Rule complexity | Medium to high across the full catalogue |
| Availability of standard patterns | High for storage, versioning and publication |
| Suggested classification | Supporting with common management patterns; boundary and ownership to be tested |

Design implication:

Stage 4 should test both a dedicated Reference Data context and domain-owned datasets published through common tooling. It should not centralise authority merely because values can share delivery infrastructure.

## Editorial Content

Editorial Content should be treated as a generic or supporting subdomain candidate, subject to confirmation of which capabilities remain in EPR.

Evidence:

- Current editorial capabilities include news, frontend editorial banners, FAQs, documents, content pages and glossary entries.
- News, FAQs and glossary entries have separate legacy and frontend storage shapes with unresolved authority and parity.
- Documents and content pages are legacy-only in the reviewed evidence and require confirmation of live use.
- Editorial concepts have authoring, review, publication, effective-period, expiry and archival concerns distinct from provider-record lifecycles.
- Runtime management may be justified for some content, such as urgent in-service banners, but is not established for every content family.
- Audience and grouping semantics differ across news, FAQs, documents and banners.

Provider-event triggers, outbound delivery attempts, retries and delivery history are excluded. They belong to outbound communication or to orphaned legacy evidence that we are not carrying into later DDD stages, and must not be used as evidence that Editorial Content needs an event-driven delivery model.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | Medium supporting value |
| Domain specificity | Low to medium |
| Rule complexity | Currently uncertain and capability-dependent |
| Availability of standard products/patterns | High for publishing; variable for authenticated and audience-specific content |
| Suggested classification | Generic or supporting, to be confirmed after build/buy/delegate and retention analysis |

Design implication:

Stage 4 should carry Editorial Content as a candidate context, not an approved service boundary. It must test whether retained runtime-managed content has coherent ownership and rules, and whether other content should be source-controlled, externally published, archived or retired.

## Outbound Communication

Outbound Communication should be treated as a supporting subdomain candidate that can use generic delivery patterns and GOV.UK Notify as a delivery channel.

Evidence:

- The legacy Java backend has a central GOV.UK Notify adapter configured through `applicationContext-email-notify.xml`.
- The legacy notification surface is not just a generic `send email` operation. `NotificationSender` exposes business-named methods for account lifecycle, workflow, reminder, data-owner, feedback, bulk update, governance and operational notifications.
- Notification intent is represented through named template keys and sender methods.
- Recipient resolution includes users, data owners, establishment contacts, helpdesk addresses and operational distribution lists.
- Reminder behaviour has its own lifecycle, including general reminders and the 60-day data-freshness reminder.
- Some flows need suppression, fallback or history, such as the 60-day reminder repeat-suppression and helpdesk fallback behaviour.
- GOV.UK Notify is the delivery service; it does not own the EPR notification intent, trigger, recipient-resolution or audit language.

Classification:

| Aspect | Assessment |
| --- | --- |
| Business value | Medium to high supporting value |
| Domain specificity | Medium: high around intent, triggers and recipient rules; low around delivery mechanics |
| Rule complexity | Medium |
| Availability of standard products/patterns | High for delivery, templates and operational monitoring |
| Suggested classification | Supporting, using generic delivery patterns; boundary and ownership to be tested |

Design implication:

Stage 4 should test whether Outbound Communication is a small supporting bounded context, a thin application service around GOV.UK Notify, or a set of domain-owned notification rules using shared delivery tooling. It should not become the owner of establishment, governance, workflow or access-control facts merely because those facts trigger messages.

## Classification Summary

| Subdomain | Proposed classification | Confidence | Boundary decision needed in Stage 4 |
| --- | --- | --- | --- |
| Establishment Registry | Core | High | Yes: decide whether groups are inside this context or separate. |
| Establishment Groups And Memberships | Core | High | Yes: test whether this core subdomain shares the Establishment Registry context or needs a collaborating context. |
| Governance | Core | High | Yes: test its separate bounded-context boundary and contracts with the other core subdomains. |
| Access Control | Generic with EPR-specific policy | High | Yes: define integration pattern across contexts. |
| Data Stewardship Workflow | Supporting using generic workflow patterns | High | Yes: define orchestration and ownership boundaries. |
| External Read API | Supporting product/API subdomain | Medium | Yes: define anti-corruption and read-model ownership. |
| Reference Data | Supporting with mixed domain ownership | Medium | Yes: test central context versus domain ownership with common delivery tooling. |
| Editorial Content | Generic or supporting, to be confirmed | Medium to low | Yes: determine retained runtime scope, ownership, cohesion and build/buy/delegate outcome. |
| Outbound Communication | Supporting using generic delivery patterns, to be confirmed | Medium | Yes: decide whether this is a small supporting context, a thin application service around GOV.UK Notify, or domain-owned notification rules using shared delivery tooling. |

## Key Risks

| Risk | Why it matters | Mitigation |
| --- | --- | --- |
| Treating a UI tab as a subdomain | Tabs combine presentation concerns and may hide data ownership. | Use evidence from extracts, code and business rules, not only page layout. |
| Collapsing all links into one model | Establishment links, group links and group-to-group links have different meanings. | Keep relationship types explicit in Stage 4. |
| Treating governance as establishment fields | Governance can be group-scoped and has its own lifecycle. | Boundary-test Governance separately. |
| Making Access Control own domain data | This would couple policy to transaction models and duplicate facts. | Access Control should evaluate attributes supplied by domain contexts. |
| Making Workflow own domain data | This would make workflow the real transaction system by accident. | Workflow should own change process, not authoritative records. |
| Centralising all Reference Data by technical shape | This could separate values from their true business owners and change rules. | Test ownership per dataset and separate authority from shared delivery tooling. |
| Treating all editorial tables as one subdomain | News, banners, FAQs, documents, pages and glossary entries may have different owners and target dispositions. | Confirm live use and consistency needs before proposing one context. |
| Pulling outbound delivery into Editorial Content | Delivery attempts, retries and operational message history would distort an authored-content boundary. | Keep outbound communication separate from authored content presentation. |
| Treating GOV.UK Notify as the notification model | GOV.UK Notify solves delivery, but not EPR intent, trigger, recipient-resolution, suppression or domain ownership questions. | Treat GOV.UK Notify as a delivery channel and test the EPR-owned language in Stage 4. |

## Decisions To Carry Into Stage 4

| Decision area | Question for bounded-context proposal |
| --- | --- |
| Establishments and groups | Should the Establishment Registry and Establishment Groups core subdomains share one bounded context or use two collaborating contexts? |
| Governance | What separate bounded-context boundary and contracts best protect the Governance core subdomain? |
| Access Control | What policy-decision integration pattern lets Access Control work across all contexts without owning domain facts? |
| Data Stewardship Workflow | How does Workflow coordinate proposed changes across contexts without owning the final domain state? |
| External Read API | Does the read API own a read model, or does it only expose representations from domain-owned read models? |
| Reference Data | Which datasets are domain-owned, and which capabilities—if any—belong in a shared Reference Data context? |
| Editorial Content | Which editorial capabilities require runtime management, and do the retained capabilities have coherent ownership and lifecycle rules? |
| Editorial Content sourcing | Which content should be built, bought, delegated to an approved publishing platform, source-controlled, archived or retired? |
| Outbound Communication | Should notification intent, trigger, recipient resolution and history be owned by a supporting context, a thin application service or the domain context that creates the need to notify? |
| GOV.UK Notify integration | Which retained notifications should use GOV.UK Notify directly, and what evidence/history does EPR need to keep outside the delivery provider? |

## Output

The output of Stage 3 is this subdomain classification:

- Establishment Registry is the main core-subdomain candidate.
- Establishment Groups And Memberships is a core subdomain; Stage 4 must decide whether it shares the Establishment Registry bounded context or uses a closely collaborating context.
- Governance is a core subdomain and should be boundary-tested as its own context.
- Access Control is a generic subdomain with EPR-specific policy.
- Data Stewardship Workflow is a supporting subdomain using generic workflow patterns.
- External Read API is a supporting product/API subdomain.
- Reference Data is a supporting subdomain candidate with mixed domain ownership and reusable management/delivery patterns.
- Editorial Content is a generic or supporting subdomain candidate whose retained runtime scope and cohesion must be established; outbound message delivery is excluded.
- Outbound Communication is a supporting subdomain candidate using generic delivery patterns; Stage 4 must decide whether it is a small supporting context, a thin application service, or domain-owned notification rules using shared delivery tooling.

Stage 4 should use this classification to propose bounded contexts and a context map.
