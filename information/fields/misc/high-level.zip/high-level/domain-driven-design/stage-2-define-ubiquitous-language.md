# Stage 2: Define The Ubiquitous Language

## Purpose

This document executes **Stage 2: Define The Ubiquitous Language** for the high-level design work.

The goal is to make our language precise enough to test bounded contexts. We are not trying to create a final glossary for the whole service yet. We are defining the working language we should use when discussing candidate bounded contexts, service responsibilities, data ownership and cross-context collaboration.

## Stage 2 Method

We should define language by context, not as one global dictionary.

Some terms can safely have a shared meaning across the programme. Other terms are overloaded and must be qualified. For example, `role` can mean a governance role, an access-control role or a workflow responsibility. Treating those as the same thing would lead to the wrong model.

For each candidate context, this document identifies:

| Item | Meaning |
| --- | --- |
| Preferred business language | Terms we should use in HLD and Confluence-facing design work. |
| Source-system language | Terms we may need to retain when referring to current extracts, ERDs or legacy system behaviour. |
| Terms to qualify | Words that must not be used on their own because they mean different things in different contexts. |
| Modelling notes | Language choices that affect bounded-context or logical-model design. |

## Shared Language Principles

| Principle | What we should do |
| --- | --- |
| Prefer precise business terms where possible | Use terms such as establishment, academy trust, federation, sponsor and governance role when that is what we mean. |
| Preserve source terms when citing evidence | Use `Establishment`, `EstablishmentGroup`, `URN`, `UID` and table names when referring to source extracts or ERDs. |
| Qualify overloaded terms | Say establishment link, group link, governance role, access-control role or workflow task rather than using link, role or task on their own. |
| Separate ownership from display | A page, tab or API response may combine data from several contexts; that does not mean one context owns all the data. |
| Avoid using service names too early | We are identifying language and boundaries before committing to service names. |

## Establishment And Organisation Alignment

We should use **establishment** as the preferred business and modelling term for the core registered entity in this registry.

The DfE Enterprise Data Model supports this. In the Education Subject Area, `Local Authority` and `Establishment` are both shown as examples of `Organisation`. We should treat an establishment as a specific kind of organisation in the education domain.

### Enterprise Data Model Education Subject Area
<img src="Enterprise%20Data%20Model%20Education%20Subject%20Area.png" alt="Enterprise Data Model Education Subject Area" width="70%" />

Where a term already exists in the controlled vocabulary, this document links the term to its canonical URI in `education-provider-registry-docs/models/education-provider-vocabulary.ttl`.

This gives us a useful hierarchy for the HLD:

| Term | How we should use it |
| --- | --- |
| Organisation | The broad enterprise concept. Local authorities and establishments can both be understood as organisations. |
| [Establishment](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/Establishment/) | The domain term for the registered education organisation or setting in this registry. This remains the core term for the bounded-context language. |

This also keeps location separate. An establishment can have a site, address and coordinates, but the establishment is not the same thing as its physical location.

## Candidate Context Language

### Establishment Registry

This is the working name for the candidate context currently described as **Establishment and Establishment Group**.

| Term | Working definition | Use this when |
| --- | --- | --- |
| [Establishment](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/Establishment/) | The broad registry term for a registered education organisation, setting or institution, including schools, academies, children's centres and other establishment types. In source data this is usually identified by `URN`. | Discussing the core registered entity across the model. |
| Organisation | The broader enterprise concept that establishments and local authorities can both align to. | Discussing EDM alignment or enterprise-level modelling. |
| Education provider | A useful external-facing term for many establishments, but not broad enough to replace establishment everywhere. | Speaking to stakeholders where the scope is clearly education provision rather than the full establishment universe. |
| [EstablishmentDetails](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/EstablishmentDetails/) | The target-system concept for a registered establishment and its core facts. | Discussing the future logical model. |
| [EstablishmentType](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/EstablishmentType/) | The classification of an establishment, such as community school, academy converter, pupil referral unit or children's centre. | Discussing field rules, display behaviour, governance expectations or access-control attributes. |
| [EstablishmentStatus](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/EstablishmentStatus/) | The operating status of the establishment, such as open, closed or proposed to open. | Discussing public display, lifecycle, access rules or read API filtering. |
| [EstablishmentGroup](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/EstablishmentGroup/) | The umbrella term for trusts, sponsors, federations and children's-centre groups identified by `UID`. | Discussing establishment group structures or referring to current group extracts, `EstablishmentGroup`, `GroupLink` or `GroupRelationsLink`. |
| [AcademyTrust](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/AcademyTrust/) | A trust responsible for one or more academies. | Discussing business semantics for MAT, SAT or SSAT group records. |
| [MultiAcademyTrust](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/MultiAcademyTrust/) | An academy trust responsible for more than one academy. | Discussing MAT-specific group and governance relationships. |
| [SingleAcademyTrust](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/SingleAcademyTrust/) | An academy trust responsible for one academy. | Discussing SAT-specific group and governance relationships. |
| [SchoolSponsor](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/SchoolSponsor/) | An organisation recorded as a school sponsor in the current group model. | Discussing sponsor relationships separately from trust membership. |
| [Federation](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/Federation/) | A group of schools with a shared governance arrangement. | Discussing maintained-school federation semantics. |
| [ChildrensCentreGroup](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/ChildrensCentreGroup/) | An establishment group for children's-centre relationships. | Discussing children's-centre group membership and lead-centre behaviour. |
| Lead centre | The linked children's centre marked as the lead within a children's-centre group. | Discussing `ccLinkType = LEAD` or `CCIsLeadCentre = true`. |

#### Establishment Registry Relationship Terms

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| Establishment link | A typed relationship from one establishment record to another establishment record. | Group link or group-to-group link. |
| Establishment link type | The lifecycle or operational meaning of an establishment link, currently `LinkType`. | `GroupLinkType`, `ccLinkType` or UI hyperlink. |
| [GroupMembership](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GroupMembership/) | A relationship between an establishment and an establishment group, currently represented by `GroupLink`. | Establishment link. |
| [GroupRelationship](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GroupRelationship/) | A relationship between two establishment groups, currently represented by `GroupRelationsLink`. | Establishment link or group link. |
| [GroupRelationshipType](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GroupRelationshipType/) | A group-to-group relationship type, currently simple values such as predecessor SAT and successor MAT. | Establishment link type. |
| Children's-centre link role | The role of an establishment within a children's-centre group link, currently `STANDARD` or `LEAD`. | Group-to-group link type. |

#### Establishment Registry Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| Establishment and establishment group may be one context or two collaborating contexts. | We need boundary tests before deciding whether establishment records and establishment groups sit in one service. |
| Establishment links and group links are different relationship models. | The target model should not introduce a generic `Link` entity that hides relationship meaning. |
| Establishment type drives behaviour. | Establishment type must be available to field rules, governance display, access control, workflow and read API. |
| Children's-centre lead centre is a role on a group link. | If children's-centre groups remain in scope, the link role should be explicit rather than hidden as a boolean. |

### Governance

Governance has enough distinct language to be treated as a candidate bounded context.

| Term | Working definition | Use this when |
| --- | --- | --- |
| [GovernanceAppointments](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernanceAppointments/) | The arrangements, roles and people responsible for oversight and accountability of an establishment or trust. | Discussing the governance domain broadly. |
| [GovernanceAppointment](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernanceAppointment/) | A record of one governance person holding one governance role for an establishment or establishment group for a period of time. | Discussing extracted governance rows, appointments or target logical model records. |
| [GovernancePerson](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernancePerson/) | A person who holds, held or is proposed to hold a governance role. | Discussing identity/person modelling without calling everyone a governor. |
| [GovernanceRoleType](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernanceRoleType/) | The business role a person holds, such as trustee, member, governor, local governor, chair or governance professional. | Discussing governance responsibilities. |
| [GovernanceAppointingBody](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernanceAppointingBody/) | The person, body or organisation responsible for appointing a governance role-holder. | Discussing role provenance and accountability. |
| [GovernanceTermEndDate](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernanceTermEndDate/) | The period for which a governance appointment applies. | Discussing appointment start and end dates. |
| [TrusteeRole](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/TrusteeRole/) | A governance role at academy trust level. | Discussing MAT/SAT trust governance. |
| [MemberRole](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/MemberRole/) | A governance role associated with academy trust membership. | Discussing trust-level governance, not school-level local governance. |
| [GovernorRole](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/GovernorRole/) | A governance role for maintained-school governance. | Discussing school-level maintained governance. |
| [LocalGovernorRole](https://dfe-digital.github.io/education-provider-registry-docs/vocabulary/LocalGovernorRole/) | A governance role for local academy governance. | Discussing academy-level local governance within a trust. |
| Governance professional | A role supporting governance administration and compliance. | Discussing clerk/governance-professional style records. |

#### Governance Scope Terms

| Term | Working definition | Business example |
| --- | --- | --- |
| Establishment-scoped governance | Governance attached to an establishment record through `URN`. | Maintained school governors and academy local governors. |
| Group-scoped governance | Governance attached to an establishment group through `UID`. | MAT trustees and members attached to the trust. |
| Trust-level governance | Governance for an academy trust as an organisation. | A MAT trustee governs the trust, not one individual academy. |
| Establishment-level governance | Governance for one establishment. | A governor linked to one maintained school. |

#### Governance Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| Governance cannot mean only "people attached to establishments". | Some governance records attach to `URN`; some attach to `UID`. |
| Governance role is not the same as access-control role. | A trustee in governance is not automatically a system role granting permissions. |
| Governance person is not necessarily a user. | A named governance person may not have a login account. |
| Governance data has privacy implications. | Person and appointment data needs access-control and audit consideration. |

### Access Control

Access Control is a cross-cutting context. Its language should be precise because many of its terms are overloaded elsewhere.

Source vocabulary: [Access Control Vocabulary](../access-control/access-control-vocabulary.md). These terms are not yet defined as canonical concepts in `education-provider-vocabulary.ttl`.

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| Actor | The person or system attempting to perform an action. | Governance person, unless that person is also acting in the system. |
| User | A human actor with an authenticated account. | Governance person or staff member. |
| System actor | A non-human actor such as an integration, job or service account. | External API consumer as an organisation. |
| Access-control role | A permission-bearing role assigned to an actor. | Governance role or staff role. |
| Capability | A named ability an actor may have, such as edit governance or approve establishment changes. | A low-level operation such as HTTP POST. |
| Permission | The allowed relationship between an actor, action and protected resource. | Governance appointment or workflow assignment. |
| Protected resource | The thing being protected, such as establishment details, governance records or group links. | API resource shape or database table. |
| Action | The thing the actor wants to do, such as view, create, edit, approve or export. | Workflow state. |
| Scope | The boundary within which an actor may act, such as local authority, trust, establishment or national. | Establishment group membership. |
| Policy | A rule set used to make access decisions. | Workflow rule or validation rule. |
| Access decision | The outcome of evaluating policy for an actor, action and resource. | Workflow approval decision. |

#### Access Control Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| Access Control evaluates facts; it should not own the domain facts. | Establishment status, group membership and governance appointment data should remain owned by their domain contexts. |
| Workflow state can be a policy attribute. | Access Control may need to know that a change request is awaiting approval. |
| Scope must be explicit. | A user may be scoped to a trust, local authority or establishment. |
| Access-control audit is separate from domain history. | We need to know why access was allowed or denied, not only what data changed. |

### Data Stewardship Workflow

Data Stewardship Workflow is the language for controlled application-data change. It is not IT service change management.

Source vocabulary: [Data Stewardship Vocabulary](../data-stewardship/data-stewardship-vocabulary.md). These terms are not yet defined as canonical concepts in `education-provider-vocabulary.ttl`.

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| Data stewardship workflow | The managed process for proposing, reviewing, approving, applying and auditing application data changes. | Deployment workflow or IT service change. |
| Change request | A request to change application data. | Pull request, incident or support ticket. |
| Proposed value | A value submitted for review before it becomes authoritative. | Current value. |
| Current value | The authoritative value currently held by the owning domain service. | Proposed value. |
| Accepted value | A proposed value that has been approved. | Applied value. |
| Applied value | A value written to the authoritative domain record. | Accepted value before persistence. |
| Workflow state | The state of the change request, such as draft, submitted, reviewed, approved, applied or closed. | Establishment status or governance role status. |
| Review task | A task requiring a steward, reviewer or approver to act. | Access-control permission. |
| Decision | The workflow outcome recorded by a reviewer or approver. | Access decision. |
| Steward | A person or role responsible for reviewing and progressing data quality or data changes. | Data owner or system administrator. |
| Evidence | Supporting information used to justify or review a data change. | Audit log. |

#### Data Stewardship Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| Workflow coordinates change; it should not own authoritative establishment or governance records. | The workflow may hold proposed values, but the domain service applies approved changes. |
| Workflow decision is not the same as access decision. | A user may be allowed to approve, but still choose to reject the proposed change. |
| Workflow history is not the same as domain change history. | We need both the review journey and the final data change record. |
| Proposed values need structure. | Free-text change descriptions are not enough if services must validate and apply changes safely. |

### External Read API

External Read API is the language for consumer-facing read contracts. It is not the same thing as the internal read model.

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| External Read API | The consumer-facing API product for reading establishment registry data. | Frontend backend API or database read model. |
| API consumer | A person, system or organisation that consumes the API. | End user of the public website. |
| API resource | A named resource exposed by the API, such as establishment, governance summary or establishment group. | Database table. |
| API representation | The JSON or documented shape returned for an API resource. | Domain entity. |
| API contract | The stable agreement with consumers about resources, fields, behaviour and versioning. | Internal service interface. |
| API version | A managed version of the API contract. | Application release version. |
| Read model | A query-optimised data product used to serve frontend or API needs. | External API contract. |
| Exposure rule | A rule determining which data can be exposed to which consumer. | Domain validation rule. |

#### External Read API Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| The API can expose combined data without owning the transactional records. | Establishment, establishment group and governance data may be composed into one response. |
| API resource language may differ from internal domain language. | Consumers may see a resource named for public understanding, but the internal model should still use `Establishment` for the core registered entity. |
| Public and restricted reads may have different exposure rules. | Access Control needs to be part of read API design. |
| API versioning is part of the product boundary. | Internal model changes should not automatically break consumers. |

### Reference Data

Reference Data is a candidate language area whose ownership and boundary remain open. Its terms describe governed values used by other contexts; they do not imply that one service must own every code list.

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| Reference dataset | A governed collection of values used to classify, validate, describe or constrain domain data. | An arbitrary database lookup table. |
| Reference value | One governed entry within a reference dataset. | A free-text domain value or transactional entity. |
| Code | A stable machine-readable identifier for a reference value. | Database primary key or display label. |
| Label | Human-readable wording used to present a reference value. | The value's stable code or full definition. |
| Definition | The agreed business meaning of a reference value. | UI help text alone. |
| Classification | Assignment of a domain concept to a defined category or type. | Presentation grouping. |
| Reference-data version | An identifiable published state of a dataset or value set. | Application release version or API version. |
| Effective period | The period during which a reference value is valid for use. | The lifecycle of a record classified by that value. |
| Supersession | A relationship indicating that one reference value replaces another. | Renaming a label without changing meaning. |
| Retirement | Withdrawal of a reference value from new use while preserving historic interpretation. | Physical deletion of values already referenced by records. |
| Reference-data owner | The accountable business authority for meaning, lifecycle and change decisions for a dataset. | Technical database owner or consuming-context owner. |
| Published reference contract | A versioned representation through which consuming contexts obtain governed reference values. | Direct shared-table access. |

#### Reference Data Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| A common table shape does not establish common ownership. | Establishment status, governance role and access-control metadata may belong to different business owners. |
| Code, label and definition are different concepts. | Labels can change without forcing identifier changes; definitions need governance. |
| Retirement must preserve historical meaning. | Existing records may continue to reference values no longer available for new use. |
| Shared use does not automatically make a dataset centrally owned. | Stage 3 and Stage 4 must test ownership dataset by dataset. |
| Published contracts should hide persistence details. | Consumers should not depend on a shared database schema merely because they use the same values. |

### Editorial Content

Editorial Content is the candidate language area for authored material presented by the service. It covers news, frontend editorial banners, FAQs, documents, content pages and glossary entries.

It excludes provider-event triggers, outbound delivery, publication attempts, retry/removal processing and delivery history. Those terms belong to a separate operational communication concern or to orphaned legacy evidence that we are not carrying into later DDD stages.

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| Editorial item | An authored item intended for presentation, such as an article, banner, FAQ, document, content page or glossary entry. | Outbound communication or message-delivery record. |
| News article | Time-relevant editorial content presented as service news. | Frontend notification banner or outbound notification. |
| Editorial banner | Runtime-managed content displayed prominently within the frontend. | Outbound notification or delivery attempt. |
| FAQ item | An authored question-and-answer item presented to readers. | Support case or user-submitted question. |
| FAQ display group | A heading or presentation grouping for FAQ items. | User group, access-control group or legacy FAQ audience. |
| Editorial document | An uploaded file plus the metadata needed to classify, present, restrict and retain it. | Database content page or API document. |
| Content page | Authored page content composed of one or more sections. | Application screen or external web page merely linking to the service. |
| Content section | An ordered portion of a content page. | Documentation taxonomy or frontend page component. |
| Glossary entry | An authored term and explanation presented to readers. | Reference value or canonical domain definition. |
| Publication state | The editorial state controlling whether content is draft, reviewed, published, expired or archived. | Operational message processing state. |
| Effective period | The time window in which an editorial item is eligible for presentation. | Reference-value validity or establishment lifecycle dates. |
| Editorial grouping | A subject, section or display grouping used to organise editorial items. | Establishment group, user group or access-control scope. |
| Presentation audience | The readers for whom editorial content is eligible to be shown. | Recipient list or outbound-message audience. |
| Editorial author | A person permitted to create or change editorial content. | Data steward changing provider facts. |
| Editorial reviewer | A person accountable for reviewing or approving content for publication. | Workflow approver for provider-data changes. |
| Editorial audit | The history of editorial creation, review, publication and change. | Access-decision audit or message-delivery history. |

#### Editorial Content Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| Editorial publication means making content eligible for presentation. | It must not be used for outbound message delivery attempts. |
| Similar terms do not prove equivalent models. | Legacy FAQ groups and frontend FAQ display groups have different evidenced behaviour. |
| Presentation audience does not own identity or policy. | Editorial Content may use Access Control decisions but should not become the permission authority. |
| Glossary entry is not automatically Reference Data. | Reader-facing explanatory content and governed classification values have different ownership and lifecycle concerns. |
| Runtime-managed content is not assumed for every item. | Some pages, FAQs or glossary entries may be source-controlled or externally published. |
| Editorial audit is separate from provider-data workflow history. | Editorial review and publication do not change authoritative establishment or governance facts. |

### Outbound Communication

Outbound Communication is the candidate language area for messages emitted by the service to users, contacts, helpdesk recipients, operational teams or external communication channels.

It includes GOV.UK Notify email notifications, reminder emails, data-owner workflow emails, change-request emails, operational alert emails and notification history where the service needs to record that a message was generated, sent, skipped, suppressed or failed.

It does not include frontend notification banners or news articles. Those belong to Editorial Content. Orphaned legacy publication records should stay in the evidence base only where they explain the as-is system; they are not Stage 2 vocabulary that we carry into later DDD stages.

| Term | Working definition | Do not confuse with |
| --- | --- | --- |
| Outbound communication | A message emitted by the service to a user, contact, organisation mailbox, helpdesk, operational team or external communication channel. | Editorial content presented on a page. |
| Outbound notification | A specific outbound communication generated because a workflow state, reminder, event or operational condition requires someone to be told. | Frontend notification banner. |
| Notification intent | The reason the service is generating a notification, such as password reset, data-owner action, reminder, review request or operational alert. | GOV.UK Notify template ID. |
| Notification trigger | The event, workflow state, schedule or rule that makes a notification eligible to be sent. | Delivery channel. |
| Recipient | The person, mailbox or configured address that should receive an outbound communication. | Presentation audience. |
| Recipient resolution | The process of deciding which recipient or fallback recipient should receive a message. | Access-control decision, although access attributes may contribute evidence. |
| Delivery channel | The mechanism used to send a message, such as GOV.UK Notify email. | Notification intent. |
| Delivery attempt | One attempt to send or publish a message through a delivery channel. | Workflow decision or editorial publication. |
| Notification template | Reusable message content or template selection used to generate an outbound notification. | Editorial page template or frontend banner template. |
| Notification history | A record that a notification was generated, sent, skipped, suppressed, failed or retried. | Editorial audit or domain change history. |
| Reminder | A prompt with its own lifecycle that may result in one or more outbound notifications. | Notification delivery attempt. |
| Operational alert | An outbound communication to operational/support recipients about service failure, batch failure or other operational condition. | User-facing service message. |

#### Outbound Communication Modelling Notes

| Language point | Modelling impact |
| --- | --- |
| GOV.UK Notify is a delivery channel, not the whole capability. | The service still needs language for intent, trigger, recipient resolution, template selection and history where those are in scope. |
| Notification is overloaded in the legacy estate. | We should say outbound notification, frontend notification banner, reminder or operational alert rather than using notification on its own. |
| Reminders are not just emails. | A reminder can exist before any delivery attempt and may have completion, suppression or repeat rules. |
| Recipient is not the same as presentation audience. | Editorial content may be visible to an audience, while outbound communication is sent or published through a channel. |
| Operational alerts may belong with live-service operations. | Not every outbound communication belongs in the provider-domain model. |

## Overloaded Terms To Control

| Term | Ambiguity | Stage 2 rule |
| --- | --- | --- |
| Establishment | Domain term for the registered entity; also the source-system term. | Use `establishment` as the broad modelling term for the registered entity. |
| Establishment group | Umbrella term for trusts, sponsors, federations and children's-centre groups. | Use `establishment group` or the specific real-world type when known. |
| Group | Could mean establishment group, user group, workflow group or publication audience. | Never use unqualified `group` in design decisions. |
| Link | Could mean establishment link, group link, group-to-group link, UI hyperlink or integration link. | Always qualify the link type by relationship model. |
| Link type | Could mean `LinkType`, `GroupLinkType`, `ccLinkType` or `linkType`. | Name the owning relationship model. |
| Role | Could mean governance role, access-control role, workflow role or staff role. | Always qualify the role type. |
| Person | Could mean governance person, user account, staff member or contact. | Say which kind of person is meant. |
| User | Could mean public website visitor, authenticated internal user, API consumer or system actor. | Use actor/user/system actor/API consumer deliberately. |
| Workflow | Could mean data stewardship, deployment, support, access provisioning or business process. | In this HLD work, say data stewardship workflow when we mean application-data change. |
| Decision | Could mean access decision, workflow decision or business approval. | Qualify by context. |
| Read model | Could mean query store, API representation or public website data shape. | Keep read model as data product/persistence; keep API representation as contract shape. |
| Code | Could mean a reference-data identifier, application source code or database key. | Say reference code, source code or database key. |
| Version | Could mean reference-data version, API version, policy version, content version or application release. | Always qualify the version type. |
| Effective period | Could apply to a reference value, editorial item, governance appointment or establishment lifecycle. | Qualify the owning concept. |
| Publication | Could mean making editorial content visible or publishing other legacy records. | Use editorial publication only for content presentation; treat orphaned legacy publication records as as-is evidence rather than target vocabulary. |
| Audience | Could mean editorial presentation audience, document access group, API consumer population or outbound-message recipients. | Qualify the capability and do not assume one identifier model. |
| Section | Could mean a content-page section, document taxonomy, UI section or document heading. | Use content section, documentation section, UI section or document section. |
| Notification | Could mean GOV.UK Notify email, frontend notification banner, reminder email or operational alert. | Use outbound notification, notification banner, reminder or operational alert as appropriate. |
| Reminder | Could mean a reminder record, a scheduled job, an email, a data-freshness prompt or a governance/staff prompt. | Say reminder record, reminder rule, reminder email or data-freshness reminder. |
| Recipient | Could mean email recipient, helpdesk fallback, data owner, user or operational mailbox. | Qualify by delivery channel and resolution rule. |
| Template | Could mean GOV.UK Notify template, legacy email template, content template or frontend banner template. | Qualify the template type and owning capability. |

## Terms That Need Further Business Agreement

| Term | Why It Needs Agreement | Current Working Position |
| --- | --- | --- |
| Education provider | Business-friendly for many establishments, but narrower than the full establishment scope. | Use where it is clearly correct for the audience and scope, not as the universal replacement for establishment. |
| Governance person | Practical neutral term, but may overlap with identity and user-account modelling. | Use for governance role-holder identity until person modelling is tested. |
| Data steward | Useful workflow term, but specific stewardship roles are not yet designed. | Use as a placeholder for people responsible for reviewing and progressing data changes. |
| External Read API | Strong contract boundary, but not yet confirmed as a bounded context. | Treat as a product/API boundary candidate until Stage 4. |
| Reference-data owner | Ownership may differ by dataset even where values use a common technical store. | Discover accountable ownership per dataset before proposing a shared context. |
| Editorial item | Useful umbrella language, but the capabilities may not share enough rules to justify one model. | Use for discovery while retaining specific terms such as article, FAQ, banner, document and glossary entry. |
| Presentation audience | Current implementations use several grouping and access patterns. | Treat as a candidate term until reader eligibility and Access Control integration are agreed. |
| Outbound Communication | Evidence shows a broad legacy notification catalogue, but target ownership and beta scope are not yet confirmed. | Use as a candidate language area until Stage 3 and Stage 4 decide whether it is a supporting bounded context, thin application service or set of domain-owned rules. |
| Notification history | Some legacy flows have explicit history and suppression state; others only log delivery attempts. | Use as a candidate term where the service needs proof of generated, skipped, suppressed, failed or retried messages. |

## Stage 2 Output

The Stage 2 language work gives us the following rules for the next stage:

1. We should test bounded contexts using qualified terms, especially for `group`, `link`, `role`, `person`, `workflow`, `decision`, `notification` and `publication`.
2. We should treat Establishment Registry, Governance, Access Control, Data Stewardship Workflow, External Read API, Reference Data, Editorial Content and Outbound Communication as language areas with different concepts.
3. We should not force one global meaning onto overloaded terms.
4. We should use business-facing terms in Confluence where possible, but keep source-system terms when referencing extracts, ERDs and legacy implementation evidence.
5. We should carry unresolved language choices into Stage 3 and Stage 4 as boundary tests, not hide them in generic wording.
6. We should keep editorial publication language separate from operational message-delivery language.
7. We should not treat reader-facing glossary entries as reference values without evidence that their ownership, purpose and lifecycle are the same.
8. We should treat GOV.UK Notify as a delivery channel unless later stages prove that EPR needs a fuller owned notification model.

## Stage 2 Conclusion

The language work supports the Stage 1 candidate boundaries.

The clearest language separation is:

| Language area | Why it looks separate |
| --- | --- |
| Establishment Registry | Owns establishment records, establishment types, statuses, establishment groups and establishment relationships. |
| Governance | Owns governance people, appointments, governance roles and establishment-scoped or group-scoped governance. |
| Access Control | Owns actors, policies, protected resources, actions, scopes and access decisions. |
| Data Stewardship Workflow | Owns change requests, proposed values, workflow states, tasks, workflow decisions and workflow history. |
| External Read API | Owns consumer-facing resources, representations, API contracts, versions and exposure rules. |
| Reference Data | Describes governed datasets, values, codes, labels, definitions, versions, effective periods, supersession, retirement and published contracts; ownership remains to be tested. |
| Editorial Content | Describes authored articles, banners, FAQs, documents, pages, sections and glossary entries with editorial publication, presentation and archival lifecycles. Operational message delivery is excluded. |
| Outbound Communication | Describes outbound notifications, notification intent, triggers, recipients, recipient resolution, delivery channels, delivery attempts, templates, reminders, operational alerts and notification history. Frontend banners and news articles are excluded. |

The next stage should use this language to identify and classify subdomains.
