# Stage 1: Gather And Normalise Evidence

## Purpose

We need to identify and test the bounded contexts for the transformed Education Provider Registry before we draw the high-level design.

We are using this stage to gather and normalise the evidence we already have. The next stages will use this evidence to define the ubiquitous language, classify subdomains, propose bounded contexts and test the boundaries before we draw the high-level design.

## Current Stage

| Stage | Status | Output |
| --- | --- | --- |
| Stage 1: Gather and normalise evidence | Complete as an initial draft | Evidence grouped by candidate bounded context, terminology conflicts, assumptions and open questions. |
| Stage 2: Define the ubiquitous language | Not started | Context-specific language, lifecycle terms and overloaded terms. |
| Stage 3: Identify and classify subdomains | Not started | Subdomain classification and rationale. |
| Stage 4: Propose bounded contexts | Not started | Proposed context catalogue and context map. |
| Stage 5: Test the boundaries | Not started | Scenario-based boundary test results. |
| Stage 6: Produce the high-level design | Not started | High-level design with C4 diagrams. |

## Methodology

We are using domain-driven design strategic design techniques to work from evidence towards boundaries:

- We start with business capabilities and language, not service names.
- We identify where concepts have different meanings in different parts of the domain.
- We identify who owns the rules and data for each area.
- We separate domain ownership from cross-cutting capabilities such as access control and workflow.
- We test candidate boundaries against real change and read scenarios before treating them as service boundaries.

For Stage 1, most evidence was gathered from existing analysis and extract validation work rather than by re-running live extraction. The links work is an exception: the establishment-links analysis includes a fresh public Links-tab scrape, and the group-links analysis includes derived evidence from the June 2026 group-link extracts.

## Stage 1 Evidence Sources

| Evidence Source | Internal Source Reference | Published Analysis | Evidence Used |
| --- | --- | --- | --- |
| Establishment type extract analysis | `docs/data/extract-data/establishment-fields/establishment-type-analysis.md` | [Establishment Type Population Analysis](../analysis/establishment-type-population-analysis.md) | Establishment population, 41 observed active establishment types out of 46 ERD-defined types, sample establishment per type and establishment identifiers. |
| Establishment Details tab field analysis | `docs/data/extract-data/establishment-fields/establishment-details-tab-fields-by-type.md` | [Establishment Details Field Variation Analysis](../analysis/establishment-details-field-variation-analysis.md) | Details-tab field variation by establishment type, display-policy caveats, field metadata, rendered-page behaviour and record-specific relationship effects. |
| Establishment Location tab field analysis | `docs/data/extract-data/location/location-fields-by-establishment-type.md` | [Establishment Location Field Analysis](../analysis/establishment-location-field-analysis.md) | Location-tab evidence across 41 sampled establishment types, showing an 11-field common location set for 40 types with specific exceptions. |
| Establishment links analysis | `docs/data/extract-data/links/establishment-links-analysis.md` | [Establishment Links Analysis](../analysis/establishment-links-analysis.md) | Establishment-to-establishment relationship evidence from 220 public Links-tab page calls; 52 source establishments with links, 59 de-duplicated link rows and a rich `LinkType` lifecycle vocabulary. |
| Establishment group type extract analysis | `docs/data/extract-data/groups/group-type-analysis.md` | [Establishment Group Type Analysis](../analysis/establishment-group-type-analysis.md) | Establishment group population, 9 observed group types out of 11 ERD-defined group types, group status and group membership evidence. |
| Establishment group field analysis | `docs/data/extract-data/groups/group-fields-by-type.md` | [Establishment Group Field Analysis](../analysis/establishment-group-fields-analysis.md) | Group field population by group type, group identifiers, Companies House number, UKPRN, address fields and head-of-group fields. |
| Group links analysis | `docs/data/extract-data/links/group-links-analysis.md` | [Group Links Analysis](../analysis/group-links-analysis.md) | Establishment-to-group relationship evidence from 7,172 group records and 24,369 group-link rows; trust/sponsor pairing, `GroupLink`, `ccLinkType` lead-centre semantics and `GroupRelationsLink` distinctions. |
| Governance role extract analysis | `docs/data/extract-data/governors/governance-role-analysis.md` | [Governance Role Analysis](../analysis/governance-role-analysis.md) | Governance role counts, LA/academy/MAT split, establishment-scoped and group-scoped governance identifiers, role and appointing-body evidence. |
| Public governance page validation | `docs/data/extract-data/governors/governance-live-page-validation.md` | [Public Governance Tab Validation](../analysis/public-governance-tab-validation.md) | Public governance page evidence for 41 sampled establishment types, including visible governance sections and role-section patterns. |
| Reference-data schema analysis | `docs/data/investigation/reference-data-analysis.md` | Not separately published | Schema-wide catalogue of 129 active reference and controlled-metadata tables, their business meanings, application usage, production-activity evidence and documentation gaps. |
| Reference data by UI tab | `docs/data/investigation/reference-data-by-ui-tab.md` | Not separately published | Product-facing evidence showing how reference datasets support Establishment Details, Governance, Links and Location, plus Group Details, Academies and Governance. |
| Beta UI reference-data impact | `docs/transformation/analysis/beta-ui-reference-data-impact.md` | Not separately published | Beta planning evidence identifying direct and supporting reference-data dependencies for the Establishment Details, Governance and Location journeys. |
| Reference-data ownership analysis | `docs/transformation/high-level/domain-driven-design/reference-data-ownership-analysis.md` | Not separately published | Initial ownership hypotheses and shared-data risks to carry into the DDD process; treated as evidence rather than a final bounded-context decision. |
| Reference data bounded-context usage matrix | `docs/transformation/high-level/analysis/reference-data-bounded-context-usage-matrix.md` | Not separately published | Item-level evidence showing whether each categorised reference-data item is used by Establishment Registry, Governance or both. Identifies six cross-context reference values and distinguishes shared consumption from replicated ownership; validation rules are excluded as bounded-context behaviour/configuration rather than reference data. It does not propose a separate Reference Data bounded context. |
| Editorial content current-state analysis | `docs/transformation/high-level/analysis/editorial-content-candidate-bounded-context-analysis.md` | Not separately published | As-is evidence for news, frontend editorial banners, FAQs, documents, content pages and glossary implementations, including storage patterns, editorial lifecycles, audience/grouping semantics, activity evidence and unresolved source-of-truth questions. Secure Access announcements and operational message processing are excluded. |
| News and announcements code analysis | `docs/transformation/high-level/analysis/news-and-announcements-code-analysis.md` | Not separately published | Code-led evidence distinguishing Java legacy news stories, Java Secure Access announcements, C# frontend news articles and C# notification banners. Shows that news and banners are mainly editorial/presentation content, Secure Access announcements are operational external publication, and only the news review email is an outbound notification. |
| Legacy notification catalogue | `docs/transformation/high-level/analysis/legacy-notification-catalogue.md` | Not separately published | Plain as-is catalogue of Java GOV.UK Notify template keys and `NotificationSender` methods, grouped by legacy notification purpose without DDD classification. Useful as the concrete inventory behind later retention, retirement or redesign decisions. |
| Outbound notification code analysis | `docs/transformation/high-level/analysis/outbound-notification-code-analysis.md` | Not separately published | Code-led evidence for the Java outbound notification implementation, including GOV.UK Notify configuration, business-named sender methods, change-request and data-owner workflow notifications, general reminders, the 60-day data-freshness reminder, recipient fallback, suppression and DDD implications. |
| Access-control standards initial analysis | `docs/transformation/access-control/access-control-standards-initial-analysis.md` | Not separately published | Standards-informed evidence for RBAC plus ABAC, policy decision and enforcement responsibilities, policy administration, attribute supply and decision audit. |
| Access-control approach options | `docs/transformation/access-control/access-control-approach-options.md` | Not separately published | BAU-derived permission requirements, target options and the reasons access policy must work across organisation, record, field and workflow scopes. |
| Access-control conceptual model | `docs/transformation/access-control/access-control-conceptual-model.md` | Not separately published | Candidate concepts and relationships for actors, roles, capabilities, scopes, protected resources, policies, decisions, policy versions and audit. |
| Access-control vocabulary | `docs/transformation/access-control/access-control-vocabulary.md` | Not separately published | Normalised access-control language for actors, subjects, roles, capabilities, protected resources, scopes, policies, decisions, enforcement, administration and audit responsibilities. |
| Data-stewardship workflow initial analysis | `docs/transformation/data-stewardship/data-stewardship-workflow-initial-analysis.md` | Not separately published | Evidence for separating proposed from authoritative data and coordinating validation, review, approval, application, verification, audit and cross-context change. |
| Data-stewardship workflow vocabulary | `docs/transformation/data-stewardship/data-stewardship-vocabulary.md` | Not separately published | Normalised language for change requests, workflow state, proposed/current/accepted/applied values, decisions, evidence and stewardship responsibilities. |
| Transformation service-boundary analysis | `docs/transformation/tech-plan/05-service-boundaries.md` | Not separately published | Existing hypotheses for frontend, frontend backend API, External Read API and read-model responsibilities, plus the unresolved service boundaries introduced by authenticated Create/Edit. |

## Candidate Responsibilities

The current candidate responsibilities are:

| Responsibility | Normalised Meaning |
| --- | --- |
| Establishment and Establishment Group transactional data | The operational ownership of establishment records, establishment group records, identifiers, classifications, statuses, memberships, relationships and business rules. |
| Governance transactional data | The operational ownership of governance people, roles, appointments, appointing bodies, terms of office and governance relationships. |
| Access Control | The cross-cutting ownership of policy, protected resources, actions, scopes, access decisions and decision audit. |
| Data Stewardship Workflow | The cross-cutting ownership of change requests, proposed values, workflow states, review tasks, decisions, evidence and workflow history. |
| External Read API | The consumer-facing ownership of stable read contracts, API resources, versions, consumer access and integration-facing representations. |
| Reference Data | The ownership, meaning, lifecycle and use of reference datasets, classifications, code sets and controlled metadata across the registry. Whether this forms a bounded context remains undecided. |
| Editorial Content | The ownership, authoring, publication, presentation and archival of news, frontend editorial banners, FAQs, documents, content pages and glossary entries. Whether EPR needs a runtime-managed bounded context remains undecided. Secure Access announcements and operational message processing are excluded. |

## Evidence Normalised By Candidate Context

### Establishment And Establishment Group

The evidence points to a provider-registry capability that owns provider records, organisation group records, classifications, statuses, membership relationships and lifecycle relationships. The key design point is that the word `link` hides several different models: provider-to-provider lifecycle links, provider-to-group membership links and group-to-group history links.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| Establishments and establishment groups are tightly related in the registry because group membership and trust relationships affect how establishments are understood. | A school may be an academy because it is part of a multi-academy trust; showing the school without its trust relationship gives an incomplete business picture. |
| Establishment type and group type are not just labels; they influence fields, relationships, governance expectations, access-control attributes and read-model/API representation. | An academy converter, a community school and a children's centre do not all need the same fields, governance wording or group relationships. |
| Establishment details, location and group membership have different field behaviour, but they still appear to sit inside a broader provider-registry capability. | A provider's name and phase, its address, and its trust membership are maintained differently, but users expect them to describe the same provider record. |
| Establishment-to-establishment links and establishment-to-group links are different relationship models and should not be collapsed into a generic `Link` concept. | A predecessor school link says one provider record is historically related to another provider record; a trust link says a provider belongs to or is sponsored by an organisation group. |
| Establishment link types are a substantial lifecycle vocabulary, while group-to-group link types are much smaller and mostly about SAT/MAT history. | A school link may record predecessor, successor, merged, amalgamated, closure or sixth-form-centre meaning; a group-to-group link may simply record that a SAT became a predecessor of a MAT. |
| Children's-centre lead-centre behaviour appears to be a role on a group link, which may need explicit modelling if children's-centre groups remain in scope. | Within a children's-centre group, one linked centre may be the lead centre and the others ordinary linked centres. |
| We should test whether Establishment and Establishment Group are one bounded context or two closely collaborating bounded contexts. | Changing a trust relationship affects the provider record, the group record, public display and governance context, so we need to decide whether one service owns that whole change or two services collaborate. |
| We should avoid letting legacy terms such as `Establishment` and `Group` hide the real business language of education providers, trusts, federations and related organisations. | In business conversation we may mean school, academy trust, sponsor, federation or children's-centre group, even though the source system may call them establishment and group. |

Evidence to carry forward:

- 41 observed establishment types from the current extracts.
- 9 observed group types from the all-groups extract.
- Establishment details vary strongly by establishment type and display policy.
- Location is mostly common across establishment types.
- Establishment links are typed provider-to-provider relationships with lifecycle meaning.
- Group links are establishment-to-group relationships, especially for academy and free-school links to sponsors, MATs and SATs.
- Group-to-group link types are currently simple: `Not recorded`, `Successor MAT` and `Predecessor SAT`.
- Children's-centre group links can identify a lead centre through `ccLinkType`/`CCIsLeadCentre`.
- Group identifiers such as `Group UID`, `Group ID`, Companies House number and UKPRN have distinct meanings and population patterns.

### Reference Data

Source evidence:

- `docs/data/investigation/reference-data-analysis.md`
- `docs/data/investigation/reference-data-by-ui-tab.md`
- `docs/transformation/analysis/beta-ui-reference-data-impact.md`
- `docs/transformation/high-level/domain-driven-design/reference-data-ownership-analysis.md`

The evidence shows that reference data is a substantial part of the current domain rather than a small collection of technical lookups. It includes establishment and group classifications, geography, governance roles, field metadata, validation rules, permission metadata and operational code lists.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| Reference Data must be considered as a candidate bounded context rather than assigned to another context before the DDD process is complete. | Establishment type, local authority, governance role and validation-rule data have different meanings, owners and change triggers that need to be discovered. |
| A shared table shape does not prove that all reference data belongs to one business capability. | `EstablishmentStatus` and `StaffRole` are both code lists, but one describes an establishment lifecycle and the other a governance role. |
| Reference-data lifecycle is a business concern where codes are introduced, renamed, superseded, archived or retired. | Retiring an establishment type or governance role can affect validation, display, extracts, permissions and external consumers. |
| Reuse across UI tabs and candidate contexts creates relationships that Stage 4 and Stage 5 must make explicit. | `LocalAuthority` is displayed on establishment records and may also be used for search, organisation scope and policy decisions. |

Evidence to carry forward:

- 129 unique active reference and controlled-metadata tables are catalogued in the schema-wide analysis.
- Reference data supports Establishment, Group and Governance journeys as well as validation, permissions and operational behaviour.
- Some datasets are externally shaped, including geography and administrative classifications.
- Some reference-like tables are legacy, inactive or operational and should not automatically become target-domain concepts.
- The existing ownership analysis is an input hypothesis, not a completed bounded-context decision.

### Governance

Source evidence:

- `docs/data/extract-data/governors/governance-role-analysis.md`
- `docs/data/extract-data/governors/governance-live-page-validation.md`

The governance evidence is strong enough to treat governance as a serious candidate bounded context.

The governance extract analysis covers 270,736 governance rows. The all-governance extract partitions exactly into LA, academy and MAT extracts by `GID`. This gives us evidence that governance data is structured across multiple governance scopes rather than only as a field on an establishment.

The identifier pattern is important:

| Governance extract | Scope identifier | Meaning |
| --- | --- | --- |
| LA governance rows | `URN` | The governance record belongs to a specific establishment, for example a maintained school. |
| Academy governance rows | `URN` | The governance record belongs to a specific academy establishment, often local governance for that academy. |
| MAT governance rows | `UID` | The governance record belongs to a trust/group, not to one individual academy. |

That is why governance cannot be modelled only as "people attached to establishments". Some governance is attached to an establishment, and some is attached to a group/trust.

Companies House number is almost entirely a MAT/group-level identifier in this extract.

The role evidence is also domain-specific. It includes governors, local governors, trustees, members, accounting officers, chief financial officers, chairs, governance professionals and shared governance roles. The live page validation shows distinct presentation patterns for maintained school governance, academy local governing bodies, single-academy trust governance and legal-duty-only pages.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| Governance has its own language: role, appointment, appointing body, term of office, governance professional, trustee, member, local governor and shared governance. | Calling everyone a governor would be misleading because an academy trust member, a trustee, a local governor and a governance professional have different responsibilities. |
| Governance records can attach to either an establishment or a group/trust. A model that forces all governance onto establishments would be wrong. | A maintained school governing body is linked to a school, but MAT trustees are linked to the trust rather than to one academy. |
| Governance is privacy-sensitive because the extracts contain person-name fields, even though the analysis deliberately avoids reproducing personal names. | A public page may show some role-holder names, but the system still needs careful controls around who can view, change or audit governance-person data. |
| Governance has its own lifecycle and rules, especially around appointment, term end, historical roles and role-specific presentation. | A trustee can have a start date, end date, appointing body and historical status; that is more than a simple contact field on a provider. |
| Governance should be tested as its own bounded context and likely as its own service boundary. | Changing a MAT trustee should not require the Establishment service to understand all trust-governance role rules. |

Evidence to carry forward:

- 270,736 governance rows across all governance extracts.
- Exact partition between LA, academy and MAT governance extracts.
- Establishment-scoped governance through `URN`.
- Group-scoped governance through `UID`.
- MAT/group-level association with Companies House number.
- Role labels carry context and should not be collapsed into a single generic governor role.
- Public governance rendering depends on establishment type, status and governance pattern.

### Access Control

Source evidence:

- `docs/transformation/access-control/access-control-standards-initial-analysis.md`
- `docs/transformation/access-control/access-control-approach-options.md`
- `docs/transformation/access-control/access-control-conceptual-model.md`

The access-control evidence shows that authorisation cannot be left as an implementation detail inside each service.

The BAU-derived access-control analysis identifies requirements for roles, organisation scope, field-level permissions, ownership rules, trusted-source rules, workflow-aware decisions, report/extract visibility and audit. The conceptual model separates actors, roles, capabilities, scopes, resource types, data attributes, policy documents, policy versions, access decisions and decision attributes.

The standards analysis supports a combined approach:

- RBAC for broad organisational roles and coarse capabilities.
- ABAC for field-level, row-level, relationship, provider-type, provider-status and workflow-aware decisions.
- XACML-style architecture vocabulary for policy decision, enforcement, information and administration responsibilities.
- Audit and accountability as a design concern from the start.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| Access Control is a cross-cutting bounded context, not a sub-module of Establishment or Governance. | The same internal user may need permission to update provider details, governance records and group links, so access rules cannot live only inside one domain service. |
| Domain services should enforce access decisions, but the access-control bounded context should own the policy model, policy versions, decisions and decision audit. | The Governance service should ask whether a user can edit a trustee record, but the policy saying who may edit trustees should be managed in the access-control capability. |
| Establishment, Group, Governance, Workflow and Read API contexts must supply resource and state attributes needed for policy decisions. | A policy may need to know that the provider is an academy, the record is pending approval, and the user is scoped to a trust before it can allow an edit. |
| Access Control must not own domain records or workflow state. It should evaluate policy over facts supplied by the acting service or workflow context. | The access-control system should not store the school status or workflow task itself; it should use those facts to decide whether an action is allowed. |

Evidence to carry forward:

- BAU access control combines several meanings into overloaded constructs such as user groups.
- The future model needs separate concepts for actor, role, capability, scope, protected resource, action, policy and decision.
- Workflow state is an access-control attribute, but workflow is not owned by Access Control.
- Data ownership and trusted-source status affect authorisation and workflow behaviour.

### Data Stewardship Workflow

Source evidence:

- `docs/transformation/data-stewardship/data-stewardship-workflow-initial-analysis.md`
- `docs/transformation/data-stewardship/data-stewardship-vocabulary.md`

The data-stewardship evidence shows that controlled data change needs a bounded context of its own.

The workflow analysis identifies a reusable application-data workflow shape:

```text
Draft -> Submit -> Validate -> Review -> Approve -> Apply -> Verify -> Publish/Expose -> Close
```

It recommends keeping proposed data separate from accepted data until approval. It also separates workflow ownership from domain data ownership: the workflow engine owns change requests, proposed values, tasks, decisions, evidence and workflow history, while domain services own authoritative establishment, establishment group and governance records.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| Data Stewardship Workflow is a cross-cutting bounded context. | A change request may involve provider details, a group relationship or governance information, but the workflow pattern of submit, review and approve is shared. |
| It should coordinate changes across Establishment and Establishment Group and Governance without owning their authoritative records. | A workflow can hold a proposed change to an academy trust membership, but the provider/group service should still own the final approved membership record. |
| It should ask Access Control whether an actor can perform workflow actions. | A user may be allowed to draft a change but not approve it; the workflow needs an access decision at each step. |
| It should call the owning domain service to validate and apply approved changes. | When a proposed governance change is approved, the Governance service should validate and apply the appointment rather than the workflow engine writing directly to governance tables. |
| It needs enough audit and provenance to explain who requested, reviewed, approved, applied and verified a change. | If a school name changes, we need to know who proposed it, who approved it, when it was applied and what evidence supported it. |

Evidence to carry forward:

- Proposed/current/accepted/applied value separation is a central pattern.
- Maker-checker is required for higher-risk changes.
- Workflow history is separate from domain change history, although they must be linked.
- Workflow needs to support establishment changes, group relationship changes, governance changes and potentially reference-data changes.

### External Read API

Source evidence:

- `docs/transformation/tech-plan/05-service-boundaries.md`

The tech-plan evidence treats the read API as a separate API product for system integration and data consumers.

The read API should not become a frontend convenience endpoint and should not leak internal database implementation details. It needs stable resources, OpenAPI documentation where appropriate, versioning, authentication, authorisation, monitoring and API lifecycle management.

The read model is related but distinct. The read model is a governed data product shaped for frontend and API consumption. The read API is the consumer-facing contract over appropriate data.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| External Read API is a candidate bounded context or at least a distinct contract boundary. | A consuming system should have a stable provider API contract even if the internal Establishment or Governance services change. |
| It should not own transactional establishment, group or governance data. | The API can expose a trust relationship, but it should not be the system that changes that relationship. |
| It should own API resource shapes, versions, consumer contracts, exposure rules and read-facing representations. | The API may expose a clean `educationProvider` resource even if the source model uses establishment, group and governance tables internally. |
| It needs to collaborate with Access Control for restricted read access. | A public user may see open provider data, while an authenticated internal user may see additional restricted fields through the same API product family. |
| It may read from a read model rather than directly from domain transactional stores. | A public search endpoint can read from a denormalised provider read model built from establishment, group and governance data. |

Evidence to carry forward:

- Frontend backend API and read API have different users, contracts and assurance needs.
- Read API needs consumer-oriented resources and lifecycle management.
- The read API boundary affects API management, security, documentation, support and versioning.
- Read API scope and consumers remain open questions in the tech plan.

### Editorial Content

Source evidence:

- `docs/transformation/high-level/analysis/editorial-content-candidate-bounded-context-analysis.md`
- `docs/data/erd/publication/news-announcements-and-notifications.md`, using only its news and frontend-banner evidence
- `docs/data/erd/publication/faqs-and-feedback.md`, using only its FAQ evidence
- `docs/data/erd/publication/documents-and-content.md`

The evidence identifies an authored editorial capability covering news, frontend editorial banners, FAQs, documents, database-managed content pages and glossary entries. These capabilities share publication concerns, but they do not use one uniform implementation or proven source of truth.

News, FAQs and glossary entries have separate legacy and frontend storage shapes. Documents and content pages have legacy implementations with no evidenced frontend equivalent. Frontend banners are runtime-managed content presented inside the service. Some legacy content tables have little or no activity in the reviewed window, but limited activity evidence is not sufficient to conclude that they can be retired.

Secure Access announcements are not part of this candidate responsibility. Event triggers, external publication/removal, delivery attempts, retry state and publication history belong to the separate operational communication concern covered by the announcement-subdomain investigation.

Normalised DDD implications:

| DDD implication | Business example |
| --- | --- |
| Editorial Content has language and lifecycles distinct from provider records. | An article may be drafted, reviewed, published, expired and archived independently of an establishment's lifecycle. |
| Similar-looking legacy and frontend tables do not prove one is authoritative or that both implement the same rules. | The frontend FAQ model is simpler than the legacy FAQ model and does not evidence its sign-off and audience workflow. |
| Runtime-managed content should not be assumed for every editorial family. | Static guidance or glossary content may be source-controlled or externally published, while a service banner may require immediate administration. |
| Audience and grouping concepts must be qualified by capability. | A legacy FAQ group, news audience, document user group and frontend FAQ display group do not necessarily mean the same thing. |
| Editorial Content should not own provider facts, identity or permission policy. | A banner may be shown to an authorised audience, but the editorial model should not become the authority for user roles. |
| The candidate boundary must be tested against ownership and consistency needs rather than the shared BAU database. | Publishing an FAQ and archiving a secure document may have different owners, controls and transaction requirements. |

Evidence to carry forward:

- News, FAQs and glossary each have distinct legacy and frontend storage patterns.
- Documents and content pages are evidenced only in legacy storage and require live-journey confirmation.
- Frontend editorial banners have current C# administration and presentation behaviour.
- Source-of-truth and content-parity decisions remain open for news, FAQs and glossary.
- Legacy approval, sign-off, audience and audit requirements must be confirmed rather than automatically migrated.
- Editorial content spans relational SQL, frontend/table-storage entities, bridge tables and document file pointers.
- Secure Access announcements and operational messaging are explicitly outside this candidate boundary.

## Normalised Candidate Bounded Contexts

| Candidate bounded context | Evidence strength | Current interpretation |
| --- | --- | --- |
| Establishment and Establishment Group | Strong | Likely core provider-registry context, but we still need to test whether establishments and groups are one context or two closely related contexts. |
| Governance | Strong | Likely separate bounded context because it has its own model, roles, lifecycle, identifiers and privacy considerations. |
| Access Control | Strong | Cross-cutting bounded context that owns policy and decisions across domain services and API boundaries. |
| Data Stewardship Workflow | Strong | Cross-cutting bounded context that owns proposed-change lifecycle across domain services. |
| External Read API | Medium to strong | Separate API contract boundary; we need to decide whether to describe it as a bounded context, a supporting context, or a product boundary over read models. |
| Reference Data | Strong evidence of a distinct area requiring DDD analysis | Candidate bounded context whose language, ownership, lifecycle, rules and relationships must be tested before its boundary is decided. |
| Editorial Content | Medium | Candidate responsibility with distinct editorial language and publication lifecycles, but current ownership, source-of-truth, runtime-management need and internal cohesion still require testing. |

## Terminology Conflicts To Resolve

| Term | Conflict Or Risk | Initial Resolution |
| --- | --- | --- |
| Establishment | This is legacy/GIAS terminology, but it remains deeply embedded in extracts, identifiers and existing field analysis. | Use it when referring to source evidence. In business-facing language, consider whether `education provider` is the better term. |
| Establishment Group | This is also GIAS terminology and can hide different real-world concepts such as trusts, federations, sponsors and children's centre groups. | Treat it as a source-system umbrella term until the business vocabulary is agreed. |
| Group | Can mean establishment group, user group, organisation scope, workflow participant group or publication audience. | Avoid using `group` without a qualifier. |
| Link | Can mean establishment-to-establishment link, establishment-to-group link, group-to-group link, UI hyperlink or integration link. | Always qualify as establishment link, group link, group-to-group link or hyperlink. |
| Link type | Can mean `LinkType` for `EstablishmentLink`, `GroupLinkType` for `GroupRelationsLink`, or `ccLinkType`/`linkType` on `GroupLink`. | Avoid using `link type` without the owning relationship model. |
| Governance person | Candidate term for a person participating in governance, but it may overlap with person identity, staff records or public role-holder presentation. | Keep as a working term until the governance ubiquitous language is agreed. |
| Role | Can mean staff/governance role, access-control role, workflow role or job responsibility. | Always qualify: governance role, access-control role, workflow responsibility. |
| Data owner | Can mean business accountability, access-control policy attribute or workflow routing target. | Treat as a relationship that can influence both access control and workflow. |
| Trusted source | Can be an access-control attribute, workflow shortcut or data-quality concept. | Treat it as a policy attribute that may affect workflow route, not as a blanket bypass. |
| Read model | Can be confused with the read API. | Keep read model as data product/persistence boundary; read API as consumer contract. |
| Workflow | Can mean application data stewardship, user access provisioning, or IT/service change. | In this document, workflow means application data stewardship unless explicitly qualified. |
| Publication | Can mean making editorial content visible or externally delivering an operational announcement. | Use `editorial publication` for content visibility. Keep operational announcement publication outside the Editorial Content candidate. |
| Audience | Can mean a news readership, document access group, banner presentation scope or an outbound-message recipient population. | Qualify the editorial capability and do not treat these as one identifier or policy model. |

## Initial Assumptions

- We are currently considering an Establishment and Establishment Group service and a Governance service as the main domain service candidates.
- Access Control and Data Stewardship Workflow need to work across those service boundaries.
- Access Control should own policy and decisions, not establishment or governance data.
- Data Stewardship Workflow should own change-request lifecycle, not authoritative domain records.
- External Read API should remain separate from frontend backend concerns.
- Reference Data is an undecided candidate bounded context and must follow the same DDD process as the other candidates.
- Editorial Content is an undecided candidate responsibility and must be tested using the as-is evidence before it is treated as a bounded context or service.
- Secure Access announcements and operational message processing remain outside Editorial Content.
- The public beta remains read-oriented; authenticated Create/Edit introduces the harder workflow, access-control and source-of-truth problems.
- Legacy extract and UI evidence is useful for discovering rules, but it should not define the target bounded contexts by itself.

## Initial Open Questions

| Question | Why It Matters |
| --- | --- |
| Should Establishment and Establishment Group be one bounded context or two? | Group membership and trust relationships are central, but groups may have their own lifecycle, identifiers and rules. |
| Should location be part of the Establishment context or a supporting reference/geography capability? | Location fields are mostly common, but they depend on geographic reference data and special cases. |
| Does Reference Data have the coherent language, ownership, lifecycle, rules and change patterns needed to form a bounded context? | Reference data appears throughout establishment, group, governance, access-control and workflow rules, but widespread use alone does not determine its boundary. |
| Which editorial capabilities still require runtime management, and which should be source-controlled, externally published, archived or retired? | This determines whether EPR needs an Editorial Content persistence and administration capability. |
| Do the retained editorial capabilities share sufficiently coherent ownership, lifecycle and consistency rules to form one bounded context? | Shared database location and general publication language do not by themselves establish a boundary. |
| Which legacy or frontend store is authoritative for news, FAQs and glossary content? | Source-of-truth and parity decisions are needed before migration scope can be defined. |
| How should editorial authorisation and presentation audiences use Access Control without transferring policy ownership? | Editorial administration and targeted presentation may need policy decisions while Access Control remains authoritative. |
| Is External Read API a bounded context or a product/API boundary over the read model? | This affects how we describe ownership in the high-level design and C4 diagrams. |
| What is the minimum workflow capability needed for the first authenticated write journey? | This affects whether Workflow must be a standalone service early or can start as a bounded component. |
| Which policy attributes must each domain service expose to Access Control? | This determines the cross-context contract between domain services and Access Control. |
| Which events or commands should Workflow use to apply approved changes? | This determines synchronous versus asynchronous boundaries and consistency expectations. |
| How do we represent governance that is group-scoped rather than establishment-scoped? | This is essential because MAT governance rows use `UID`, not `URN`. |
| Which read API consumers are in scope for the first release? | This determines API resources, authentication, authorisation and versioning needs. |

## Stage 1 Conclusion

Stage 1 gives us enough evidence to proceed to ubiquitous-language work.

The current evidence supports seven candidate boundaries:

1. Establishment and Establishment Group.
2. Governance.
3. Access Control.
4. Data Stewardship Workflow.
5. External Read API.
6. Reference Data.
7. Editorial Content.

The strongest immediate design pressure is that Access Control and Data Stewardship Workflow must operate across the Establishment and Establishment Group and Governance service boundaries without taking ownership of their domain data.

The next stage should define the ubiquitous language for each candidate context and make the overloaded terms explicit before we propose final bounded contexts. Editorial language must remain separate from Secure Access announcement and operational delivery language.
