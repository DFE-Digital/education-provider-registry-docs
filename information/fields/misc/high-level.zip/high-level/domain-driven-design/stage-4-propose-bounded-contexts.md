# Stage 4: Propose Bounded Contexts

## Purpose

This document executes **Stage 4: Propose Bounded Contexts** for the high-level design work.

We use this stage to turn the evidence, language and subdomain classification from Stages 1 to 3 into a proposed bounded-context model. This is still a design proposal, not the final service map. Stage 5 should test these boundaries against real change, read, access-control and workflow scenarios before we treat them as settled service boundaries.

## Stage 4 Method

We should propose bounded contexts by looking for places where the model, language, lifecycle and ownership need to be internally consistent.

For each proposed bounded context, we capture:

| Item | Meaning |
| --- | --- |
| Purpose | Why the context exists. |
| Business capability | The business capability the context supports. |
| Owned model | The concepts and rules that should be internally consistent inside the context. |
| Owned data | The authoritative data the context should own. |
| Key rules | The important rules the context should enforce. |
| Public contracts | Commands, queries, events or APIs that other contexts can depend on. |
| Dependencies | Other contexts this context needs to work with. |
| Explicit non-ownership | Things the context must not own, even if it needs to read or reference them. |

## Proposed Contexts

| Proposed bounded context | Classification from Stage 3 | Proposed role |
| --- | --- | --- |
| Establishment Registry | Core | Owns establishments, establishment groups, identifiers, establishment/group reference data, classifications, statuses, locations and establishment/group relationships. |
| Governance | Core | Owns governance people, appointments, governance reference data, roles, appointing bodies and governance relationships. |
| Access Control | Generic with EPR-specific policy | Owns policy, protected resources, access decisions, policy versions, access-control reference data and decision audit. |
| Data Stewardship Workflow | Supporting using generic workflow patterns | Owns change requests, proposed values, review tasks, decisions, workflow states and workflow history. |
| External Read API | Supporting product/API subdomain | Owns external read contracts, published representations, versioning and consumer-facing read resources. |
| Editorial Content | Generic or supporting, to be confirmed | Candidate context for retained runtime-managed news, editorial banners, FAQs, documents, content pages and glossary entries. Secure Access announcements are excluded. |

Reference Data is not proposed as a bounded context. The decision in [Reference Data Delivery Options](reference-data-delivery-options.md) is that each business bounded context owns the reference data supporting its rules. A small number of static, bounded lists may be duplicated deliberately with explicit ownership and parity controls.

## Context Map

This is the proposed context map to take into Stage 5 boundary testing.

```mermaid
flowchart LR
    establishment["Establishment Registry\nbounded context"]
    governance["Governance\nbounded context"]
    access["Access Control\nbounded context"]
    workflow["Data Stewardship Workflow\nbounded context"]
    readapi["External Read API\nbounded context"]
    editorial["Editorial Content\ncandidate bounded context"]

    workflow -->|submits proposed changes for validation and apply| establishment
    workflow -->|submits proposed changes for validation and apply| governance
    workflow -->|asks whether workflow actions are allowed| access

    establishment -->|asks whether protected establishment actions are allowed| access
    governance -->|asks whether protected governance actions are allowed| access

    readapi -->|reads governed establishment and group representations| establishment
    readapi -->|reads governed governance representations| governance
    readapi -->|asks whether read actions are allowed| access

    governance -->|references establishment and group identity| establishment
    access -->|uses domain attributes for policy decisions| establishment
    access -->|uses governance attributes for policy decisions| governance

    editorial -->|asks whether authoring and presentation are allowed| access
    editorial -.->|uses domain-owned classifications where required| establishment
```

The arrows show dependency direction, not necessarily synchronous calls. Reference data is contained within its owning business context and therefore is not drawn as a context node. Editorial Content contains no Secure Access announcement or operational delivery flow. Stage 5 should decide which interactions must be synchronous and which can be event-based or read-model based.

## Establishment Registry

### Purpose

The Establishment Registry context owns the authoritative model for establishments and establishment groups.

For this proposal, we keep establishments and establishment groups in one bounded context. This reflects the current evidence that establishment type, group membership, trust relationships, lifecycle links and public interpretation are tightly related. Stage 5 should still test whether groups need to split into a separate bounded context later.

### Business Capability

Maintain the authoritative registry of establishments, establishment groups and their relationships.

### Owned Model

| Concept | Meaning |
| --- | --- |
| Establishment | A registered education organisation, setting or institution, usually identified by `URN`. |
| Establishment type | The classification of an establishment, such as community school, academy converter or children's centre. |
| Establishment status | The operating or lifecycle status of an establishment. |
| Establishment identifiers | Identifiers such as `URN`, local authority code, establishment number, UKPRN and UPRN where applicable. |
| Establishment details | Core facts about the establishment, including type-sensitive fields. |
| Establishment location | Address, coordinates and administrative geography. |
| Establishment link | A typed establishment-to-establishment relationship, such as predecessor, successor or merged. |
| Establishment group | A trust, sponsor, federation, children's-centre group or related organisation group, usually identified by `UID`. |
| Group membership | An establishment-to-group relationship, including trust, sponsor, federation and children's-centre group links. |
| Group relationship | A group-to-group relationship, such as SAT/MAT predecessor-successor history. |
| Children's-centre lead-centre role | The role of a linked children's centre within a children's-centre group. |

### Owned Data

- Establishment identity and lifecycle data.
- Establishment type, status, phase and classification data.
- Establishment and establishment-group reference data, including type, status, phase, link types, group types, location/geography classifications and establishment-facing legacy classifications.
- Establishment details and field applicability rules.
- Location and administrative geography values associated with an establishment.
- Establishment-to-establishment links and link types.
- Establishment group records, group types, group status and group identifiers.
- Establishment-to-group memberships, joined/effective dates and children's-centre lead-centre role.
- Group-to-group relationships.

### Key Rules

| Rule area | Rule |
| --- | --- |
| Type-sensitive fields | Establishment type affects field applicability, display and validation. |
| Relationship semantics | Establishment links, group memberships and group-to-group relationships must remain separate concepts. |
| Group identity | `Group UID`, `Group ID`, Companies House number and UKPRN have distinct meanings and should not be collapsed. |
| Location | Location should be treated as common establishment data with special handling for overseas, Welsh and non-standard cases. |
| Children's-centre groups | Lead-centre behaviour should be explicit if children's-centre groups remain in scope. |

### Public Contracts

| Contract | Purpose |
| --- | --- |
| Validate establishment change | Let workflow test whether proposed establishment changes are valid. |
| Apply establishment change | Let workflow apply an approved establishment change. |
| Validate group change | Let workflow test whether proposed group or membership changes are valid. |
| Apply group change | Let workflow apply an approved group or membership change. |
| Establishment read representation | Provide governed establishment data to the External Read API. |
| Group read representation | Provide governed group and membership data to the External Read API. |
| Domain events | Publish establishment, group, membership and relationship changes where downstream contexts need eventual consistency. |

### Dependencies

- Uses Access Control decisions before protected commands are performed.
- Receives workflow-coordinated change requests from Data Stewardship Workflow.
- Supplies identity and relationship facts to Governance, Access Control and External Read API.

### Explicit Non-Ownership

The Establishment Registry does not own:

- Governance people, appointments, roles or appointing bodies.
- Access-control policy or access decisions.
- Workflow lifecycle and approval tasks.
- External API versioning or consumer contracts.

## Governance

### Purpose

The Governance context owns the authoritative model for governance appointments and the people, roles and appointment metadata that support governance accountability.

### Business Capability

Maintain governance data for establishments and establishment groups.

### Owned Model

| Concept | Meaning |
| --- | --- |
| Governance person | A person who holds, held or is proposed to hold a governance role. |
| Governance appointment | A person holding a governance role for an establishment or group for a period of time. |
| Governance role type | A role such as trustee, member, governor, local governor, chair, accounting officer, chief financial officer or governance professional. |
| Appointing body | The person, body or organisation responsible for appointing a governance role-holder. |
| Term of office | The appointment period, including start and end dates. |
| Establishment-scoped governance | Governance attached to an establishment through `URN`. |
| Group-scoped governance | Governance attached to an establishment group through `UID`. |
| Shared governance | Governance roles shared across establishments or groups. |

### Owned Data

- Governance people and identity data needed for governance records.
- Governance appointments, roles, appointing bodies and terms of office.
- Governance reference data, including governance roles, appointing bodies, staff/governance role types and governance-field metadata.
- Historical governance appointment data.
- Establishment-scoped and group-scoped governance relationships.
- Governance-specific validation and privacy-sensitive metadata.

### Key Rules

| Rule area | Rule |
| --- | --- |
| Scope | Governance can be attached to an establishment or to a group/trust. |
| Role specificity | Trustee, member, governor and local governor are different role types and should not be collapsed. |
| Appointment lifecycle | Governance appointments need start, end, historical and appointing-body metadata. |
| Privacy | Governance person data is privacy-sensitive and needs careful access and audit treatment. |
| Public presentation | Public governance page labels are presentation concerns, not the whole governance model. |

### Public Contracts

| Contract | Purpose |
| --- | --- |
| Validate governance change | Let workflow test whether a proposed governance change is valid. |
| Apply governance change | Let workflow apply an approved governance change. |
| Governance read representation | Provide governed governance data to the External Read API. |
| Governance subject lookup | Let other contexts understand whether governance is establishment-scoped or group-scoped. |
| Domain events | Publish governance appointment changes where downstream contexts need eventual consistency. |

### Dependencies

- References Establishment Registry identifiers, especially `URN`, `UID` and Companies House number where needed.
- Uses Access Control decisions before protected governance commands are performed.
- Receives workflow-coordinated change requests from Data Stewardship Workflow.

### Explicit Non-Ownership

Governance does not own:

- Establishment lifecycle, establishment type or establishment group lifecycle.
- Access-control policy.
- Workflow lifecycle and approval tasks.
- External API contract versioning.

## Access Control

### Purpose

The Access Control context owns policy-driven authorisation decisions across the Education Provider Registry.

### Business Capability

Decide whether an actor can perform an action on a protected resource in a particular scope.

### Owned Model

| Concept | Meaning |
| --- | --- |
| Actor | A user or system attempting an action. |
| Access-control role | A permission-bearing role assigned to an actor. |
| Protected resource | A domain resource being protected, such as establishment details, group membership or governance appointments. |
| Action | The requested operation, such as view, create, edit, approve or export. |
| Scope | The boundary within which access applies, such as national, local authority, trust, group or establishment. |
| Policy | A versioned rule set used to evaluate access. |
| Access decision | The allow, deny or conditional outcome of policy evaluation. |
| Decision audit | The record of what was decided and why. |

### Owned Data

- Policy documents and policy versions.
- Protected resource vocabulary.
- Action vocabulary.
- Access-control roles, assignments and scopes.
- Access-control reference data, including authorities, tools and policy-facing role/capability values.
- Access decisions and decision audit.

### Key Rules

| Rule area | Rule |
| --- | --- |
| Domain facts | Access Control evaluates domain facts but does not own them. |
| Policy versioning | Policy changes must be versioned and auditable. |
| Decision audit | Decisions should record the actor, action, resource, policy version and relevant attributes. |
| Cross-context consistency | The same policy model should work across Establishment Registry, Governance, Workflow and Read API. |

### Public Contracts

| Contract | Purpose |
| --- | --- |
| Evaluate access | Return an access decision for actor, action, resource and context attributes. |
| Publish policy version | Make a policy version active without requiring a domain-service release. |
| Retrieve policy history | Show old versions of policy documents and when they were active. |
| Decision audit query | Support audit and investigation of access decisions. |

### Dependencies

- Uses attributes from Establishment Registry, Governance, Workflow and Read API contexts.
- May integrate with identity providers for authenticated user and group claims.

### Explicit Non-Ownership

Access Control does not own:

- Establishment, group or governance domain records.
- Data stewardship workflow state, except as an input attribute.
- External API representations.

## Data Stewardship Workflow

### Purpose

The Data Stewardship Workflow context owns the process of proposing, reviewing, approving, applying and auditing application-data changes.

### Business Capability

Coordinate controlled change to domain data without becoming the owner of that domain data.

### Owned Model

| Concept | Meaning |
| --- | --- |
| Change request | A request to change application data. |
| Change item | One proposed change within a change request. |
| Proposed value | A value submitted for review before it becomes authoritative. |
| Current value | The current authoritative value, held by the owning domain context. |
| Accepted value | A proposed value that has been approved. |
| Applied value | A value written to the authoritative domain record by the owning context. |
| Workflow state | The state of the change request, such as draft, submitted, reviewed, approved, applied or closed. |
| Review task | A task requiring a steward, reviewer or approver to act. |
| Decision | A workflow outcome such as approve, reject, return or cancel. |
| Evidence | Supporting information used to justify or review a data change. |

### Owned Data

- Change requests, change items and proposed values.
- Workflow states, review tasks and decisions.
- Evidence, comments and workflow history.
- References to target domain records and applied result identifiers.

### Key Rules

| Rule area | Rule |
| --- | --- |
| Domain ownership | Workflow must not become the owner of establishment, group or governance data. |
| Validation | The owning domain context validates proposed domain changes. |
| Apply | The owning domain context applies approved domain changes. |
| Audit | Workflow owns the audit trail of the change process. Domain contexts own the audit trail of authoritative data changes. |
| Cross-context change | A change request may coordinate more than one domain context, but each domain context remains authoritative for its own data. |

### Public Contracts

| Contract | Purpose |
| --- | --- |
| Create change request | Start a controlled data-change process. |
| Submit for review | Move a draft change into review. |
| Record decision | Approve, reject, return or cancel a change request. |
| Request validation | Ask a domain context whether proposed values are valid. |
| Request apply | Ask a domain context to apply approved values. |
| Workflow history query | Show the change process and decisions for audit. |

### Dependencies

- Uses Access Control to decide whether workflow actions are allowed.
- Calls Establishment Registry and Governance for validation and apply.
- May notify External Read API or read-model processes after successful application.

### Explicit Non-Ownership

Data Stewardship Workflow does not own:

- Authoritative establishment, group or governance records.
- Access-control policy.
- External API representation design.

## External Read API

### Purpose

The External Read API context owns stable read contracts for consumers.

### Business Capability

Expose governed, versioned read representations of registry data to external consumers.

### Owned Model

| Concept | Meaning |
| --- | --- |
| API resource | A consumer-facing resource such as establishment, establishment group or governance representation. |
| Representation | The shape of data exposed to consumers. |
| API version | A versioned contract for consumers. |
| Consumer | A system or organisation using the read API. |
| Read permission | The access-control decision or policy needed to read a resource. |
| Publication event | A signal that a read representation should be updated or republished. |

### Owned Data

- API contract definitions and versions.
- Consumer-facing resource shapes.
- API documentation and compatibility rules.
- Read-facing cache or projection ownership, if we decide this context owns read projections.

### Key Rules

| Rule area | Rule |
| --- | --- |
| Contract stability | External contracts should be stable and versioned. |
| Anti-corruption | API resources should not leak internal transaction models or legacy table structures. |
| Access control | Read access must be evaluated consistently. |
| Domain ownership | The read API does not own the authoritative domain data. |

### Public Contracts

| Contract | Purpose |
| --- | --- |
| Establishment read API | Expose establishment and location information. |
| Group read API | Expose establishment group and membership information. |
| Governance read API | Expose permitted governance information. |
| Consumer contract documentation | Define resources, versions and compatibility rules. |

### Dependencies

- Reads from Establishment Registry and Governance, directly or through read projections.
- Uses Access Control for protected read decisions.
- May react to domain events from Establishment Registry and Governance.

### Explicit Non-Ownership

External Read API does not own:

- Authoritative establishment, group or governance transaction records.
- Workflow process state.
- Access-control policy.

## Reference Data Ownership Decision

### Purpose

Reference Data is not a bounded context. This decision is defined in [Reference Data Delivery Options](reference-data-delivery-options.md) and supported by the [Reference Data Usage Matrix](../analysis/reference-data-bounded-context-usage-matrix.md).

The evidence shows that most reference data belongs naturally with the bounded context whose rules it supports:

- Establishment Registry owns establishment, group, relationship, status and geography reference data.
- Governance owns governance roles, appointing bodies and governance-field reference data.
- Access Control owns policy-facing capabilities and authorities.
- Validation rules are bounded-context behaviour/configuration rather than shared reference data.

### Cross-Context Values

| Value | Decision |
| --- | --- |
| `EstablishmentType`, `EstablishmentGroupType`, `GovernorsFlag` | Establishment Registry owns these important facts. Governance consumes the selected code/fact through an owning-context contract where required. |
| `LocalAuthority` | Establishment Registry owns it; compose it into governance views or policy context only where needed. |
| `Title` | Treat as presentation data; compose it in the frontend/read layer or carry the selected value with the person. |
| Legacy `Governance` classification | Keep in Establishment Registry only if a retained rule uses it; otherwise ignore or retire it. |

### Delivery Rules

| Rule | Meaning |
| --- | --- |
| Domain ownership | Each bounded context owns the reference data supporting its rules. |
| Cross-context facts | Supply current domain facts through owning-context contracts rather than shared database access. |
| Deliberate duplication | Tiny, bounded and rarely changed lists may be copied into two contexts when this avoids unnecessary runtime coupling. |
| Duplication controls | Name one authority, compare copies with parity tests, coordinate changes and preserve historic compatibility. |
| Large/changeable datasets | Do not manually duplicate geography or other externally sourced data; publish or project it from its owner. |

The slight cost of maintaining a few static lists in two places is accepted. It is lower than the operational and coupling cost of a central Reference Data service.

## Editorial Content

### Purpose

The Editorial Content candidate owns retained runtime-managed content presented by EPR and its editorial lifecycle.

### Business Capability

Author, review, organise, publish, schedule, expire, archive and audit news, frontend editorial banners, FAQs, documents, content pages and glossary entries where runtime management remains justified.

### Owned Model

| Concept | Meaning |
| --- | --- |
| Editorial item | An authored article, banner, FAQ, document, content page or glossary entry. |
| Publication state | Draft, reviewed, published, expired, archived or deleted state. |
| Effective period | When an item is eligible for presentation. |
| Editorial grouping | A subject, section or display grouping. |
| Presentation audience | The readers for whom content is eligible to be shown. |
| Editorial author/reviewer | Actors responsible for creating and reviewing content. |
| Editorial audit | History of authoring, review, publication and change. |

### Owned Data

Subject to Stage 5 and build/buy/delegate decisions, the candidate may own:

- retained runtime-managed editorial content and metadata
- publication state and effective periods
- editorial grouping and presentation configuration
- references to presentation audiences
- editorial audit history
- document metadata where in-service document management remains required

### Key Rules

| Rule | Meaning |
| --- | --- |
| Editorial lifecycle | Only appropriately authorised and reviewed content can become visible. |
| Effective presentation | Scheduled and expired content is presented according to its effective period. |
| Audience reference | Audience eligibility uses Access Control contracts and does not redefine permission authority. |
| Accessibility | Published content and documents meet agreed accessibility controls. |
| Content safety | Editable markup and uploaded files are validated and handled safely. |
| Source-of-truth | Each content family has one agreed authoritative source before migration. |

### Public Contracts

| Contract | Purpose |
| --- | --- |
| Editorial administration commands | Create, revise, review, publish, expire, archive or delete content. |
| Published-content query | Supply eligible editorial items to the frontend. |
| Content-change event | Refresh presentation caches or downstream publication views where needed. |
| Editorial audit query | Show authoring and publication history. |

### Dependencies

- Uses Access Control for editorial-administration and presentation-audience decisions.
- May use classifications owned by Establishment Registry, Governance or another applicable business context.
- May delegate storage or publication to an approved content/document platform.
- Supplies published editorial content to the EPR frontend.

### Explicit Non-Ownership

Editorial Content does not own:

- Secure Access announcements, announcement templates or operational communication records
- provider-event triggers, outbound delivery attempts, retries, removals or delivery history
- establishment, group or governance facts
- user identity, roles or access-control policy
- reference values merely because a glossary entry describes similar language
- source-controlled or externally published content assigned to another owner

## Boundary Decisions Proposed For Stage 5

| Decision | Proposed Stage 4 position | Stage 5 test |
| --- | --- | --- |
| Establishments and groups | Keep the two core subdomains in one Establishment Registry bounded context for now. | Test whether establishment details, group identity, memberships, trust/sponsor changes and children's-centre lead-centre rules remain cohesive or require collaborating contexts. |
| Governance | Treat the Governance core subdomain as a separate bounded context. | Test adding, ending and publishing establishment-scoped and group-scoped governance appointments. |
| Access Control | Treat as a separate cross-cutting context. | Test field-level, scope-level and workflow-action access decisions without duplicating domain data. |
| Data Stewardship Workflow | Treat as a separate cross-cutting context. | Test maker-checker changes across Establishment Registry and Governance without workflow owning domain records. |
| External Read API | Treat as a separate read-contract context. | Test public and protected read resources without leaking internal transaction models. |
| Reference data ownership | Do not create a Reference Data bounded context. Keep values with their business context and permit controlled duplication of tiny static lists. | Test an owning-context contract for an important fact and a parity-controlled duplicated list without introducing a central runtime dependency. |
| Editorial Content | Carry as a candidate context for retained runtime-managed editorial material. | Test source-of-truth, author/reviewer ownership, publication lifecycle, audience presentation and archive/retirement scenarios. Exclude operational announcements. |

## Integration Style Assumptions

| Interaction | Likely style | Reason |
| --- | --- | --- |
| Workflow to domain validation | Synchronous command/query | A reviewer needs immediate validation feedback before approval. |
| Workflow to domain apply | Synchronous command with domain audit, or reliable asynchronous command where needed | Applying approved changes must be reliable and auditable. |
| Domain to External Read API | Event-driven projection or controlled read-model refresh | Read contracts should not depend directly on transaction persistence details. |
| Domain to Access Control | Synchronous decision request for protected actions | A protected action needs an access decision before it proceeds. |
| External Read API to Access Control | Synchronous decision request for protected reads | Read access needs to be enforced at request time or through precomputed entitlement decisions. |
| Governance to Establishment Registry | Query or cached reference | Governance needs establishment and group identity, but should not own it. |
| Consumer to reference-data owner | Owning-context contract, cache/projection, or deliberate static duplication | The mechanism depends on materiality and change frequency; no central Reference Data context is involved. |
| Editorial Content to Access Control | Synchronous decision request | Authoring, publication and audience-specific presentation require policy decisions. |
| Editorial Content to frontend | Query/API with appropriate caching | The frontend needs eligible published content without owning editorial lifecycle state. |

## Open Questions

| Question | Why it matters |
| --- | --- |
| Should Establishment Groups eventually split from Establishment Registry? | Trusts, sponsors, federations and children's-centre groups may develop enough independent rules to justify their own context. |
| Which small static lists should be duplicated rather than consumed through a runtime contract? | Duplication can reduce coupling but needs explicit ownership, parity testing and coordinated change. |
| Which editorial content still needs runtime management? | Content may instead be source-controlled, externally published, archived or retired. |
| Do retained editorial capabilities share one owner and consistency boundary? | News, banners, FAQs, documents, pages and glossary entries may not form one cohesive model. |
| Should External Read API own read projections or only expose projections owned elsewhere? | This affects data ownership, operational support and versioning responsibilities. |
| How should policy attributes be supplied to Access Control? | We need access decisions without duplicating domain facts into the policy engine. |
| How should cross-context change requests be applied? | Some changes may touch establishment, group and governance data together, but each context should remain authoritative for its own records. |
| Which interactions must be synchronous for private beta? | This affects delivery scope, resilience and user experience. |

## Output

The Stage 4 proposal is:

- Establishment Registry is the core bounded context for establishments, establishment groups and their relationships.
- Governance is a separate bounded context for governance people, roles, appointments and governance relationships.
- Access Control is a separate cross-cutting bounded context for policy and decisions.
- Data Stewardship Workflow is a separate cross-cutting bounded context for change process and audit.
- External Read API is a separate context for consumer-facing read contracts and representations.
- Reference Data is not a bounded context. Establishment Registry, Governance and Access Control own their reference data; cross-context facts use owner contracts and a few static lists may be duplicated with controls.
- Editorial Content remains a candidate context for retained runtime-managed editorial material; Secure Access announcements and operational messaging are excluded.

Stage 5 should now test these proposed boundaries against realistic scenarios before they are treated as service boundaries in the high-level design.
